/* ============================================================
   学習ダッシュボード メインスクリプト
   - タブ切替 / 時計 / カレンダー
   - フォント・背景・文字サイズのカスタマイズ（localStorage保存）
   - MP3プレイヤー / ToDo / 学習時間測定 / ポモドーロ
   オフラインで完結（外部API・CDN不使用）
   ============================================================ */

'use strict';

/* ---------- ユーティリティ ---------- */
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

const pad2 = (n) => String(n).padStart(2, '0');
const pad3 = (n) => String(n).padStart(3, '0');

function fmtHMS(totalSec) {
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  return `${pad2(h)}:${pad2(m)}:${pad2(s)}`;
}

function fmtHMSSec(totalSec) {
  const s = Math.floor(totalSec);
  return `${fmtHMS(s)}.${pad3(Math.floor((totalSec - s) * 1000))}`;
}

function todayKey(d = new Date()) {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

/* ============================================================
   タブ切替
   ============================================================ */
function initTabs() {
  $$('.tab-btn').forEach((btn) => {
    // data-tab を持たないボタン（テーマ切替など）はタブ切替の対象外
    if (!btn.dataset.tab) return;
    btn.addEventListener('click', () => {
      $$('.tab-btn').forEach((b) => b.classList.remove('active'));
      $$('.tab-panel').forEach((p) => p.classList.remove('active'));
      btn.classList.add('active');
      const panel = $('#tab-' + btn.dataset.tab);
      if (panel) panel.classList.add('active');
      // 表示の鮮度を保つため、切替時に最新化する
      if (btn.dataset.tab === 'clock' && typeof renderTodaySchedule === 'function') renderTodaySchedule();
      if (btn.dataset.tab === 'cards' && typeof renderDecks === 'function') {
        renderDecks();
        if (typeof renderFcStats === 'function') renderFcStats();
      }
    });
  });
}

/* ============================================================
   時計
   ============================================================ */
function updateClock() {
  const now = new Date();
  $('#clockTime').textContent =
    `${pad2(now.getHours())}:${pad2(now.getMinutes())}:${pad2(now.getSeconds())}`;
  const week = ['日', '月', '火', '水', '木', '金', '土'];
  $('#clockDate').textContent =
    `${now.getFullYear()}年${now.getMonth() + 1}月${now.getDate()}日（${week[now.getDay()]}）`;
}

/* ============================================================
   カレンダー
   ============================================================ */
const calendarState = { year: new Date().getFullYear(), month: new Date().getMonth() };

// ---- 予定（localStorage保存） ----
const EVENTS_KEY = 'dashboard_events';
let events = loadEvents(); // { "2026-09-25": [{ id, text, start, end }] }

function loadEvents() {
  try {
    const raw = localStorage.getItem(EVENTS_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch (e) {
    return {};
  }
}

function saveEvents() {
  try {
    localStorage.setItem(EVENTS_KEY, JSON.stringify(events));
  } catch (e) { /* 容量超過時は無視 */ }
}

// その日の予定を返す（毎週繰り返しの予定も当日分を materialize して含める）
function getEventsForDay(key) {
  const list = (events[key] || []).slice();
  const target = new Date(key + 'T00:00:00').getTime();
  // 繰り返し予定を全走査して、当日に該当するものを追加
  for (const dk in events) {
    if (dk === key) continue;
    (events[dk] || []).forEach((ev) => {
      if (ev.repeat === 'weekly') {
        const base = new Date(dk + 'T00:00:00').getTime();
        const diffDays = Math.round((target - base) / 86400000);
        if (diffDays > 0 && diffDays % 7 === 0) {
          list.push({ ...ev, virtual: true, baseDate: dk });
        }
      }
    });
  }
  list.sort((a, b) => ((a.start || '') < (b.start || '') ? -1 : 1));
  return list;
}

function renderCalendar() {
  const { year, month } = calendarState;
  const firstDay = new Date(year, month, 1);
  const startWeekday = firstDay.getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const daysPrev = new Date(year, month, 0).getDate();
  const today = new Date();

  $('#calendarTitle').textContent = `${year}年 ${month + 1}月`;

  let html = '';
  // 前月の余白
  for (let i = startWeekday - 1; i >= 0; i--) {
    const d = daysPrev - i;
    html += `<div class="day other">${d}</div>`;
  }
  // 当月
  for (let d = 1; d <= daysInMonth; d++) {
    const isToday =
      year === today.getFullYear() && month === today.getMonth() && d === today.getDate();
    const cls = isToday ? 'day today' : 'day';
    const key = `${year}-${pad2(month + 1)}-${pad2(d)}`;
    const dayEvents = getEventsForDay(key);
    // ToDoの期日バッジ（未完了タスクの数）
    const dueTodos = todos.filter((t) => !t.done && t.due === key).length;
    const badge = dayEvents.length > 0
      ? `<span class="day-badge" title="予定${dayEvents.length}件">${dayEvents.length}</span>`
      : '';
    const dueBadge = dueTodos > 0
      ? `<span class="day-badge due-badge" title="期限のToDo${dueTodos}件">${dueTodos}</span>`
      : '';
    html += `<div class="${cls}" data-date="${key}">${d}${badge}${dueBadge}</div>`;
  }
  // 翌月の余白（7の倍数に揃える）
  const cells = startWeekday + daysInMonth;
  const nextCount = (7 - (cells % 7)) % 7;
  for (let d = 1; d <= nextCount; d++) {
    html += `<div class="day other">${d}</div>`;
  }

  $('#calendarDays').innerHTML = html;
}

// ---- 予定モーダル ----
let eventModalDate = null; // 開いている日付キー "YYYY-MM-DD"

function openEventModal(key) {
  eventModalDate = key;
  const d = new Date(key + 'T00:00:00');
  const week = ['日', '月', '火', '水', '木', '金', '土'];
  $('#eventModalTitle').textContent = '📅 予定';
  $('#eventModalDate').textContent =
    `${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日（${week[d.getDay()]}）`;
  renderEventList();
  $('#eventModal').classList.remove('hidden');
}

function renderEventList() {
  const list = $('#eventList');
  const dayEvents = eventModalDate ? getEventsForDay(eventModalDate) : [];
  if (dayEvents.length === 0) {
    list.innerHTML = '<p class="hint">予定はありません</p>';
    return;
  }
  const CAT_LABEL = { study: '📖 学習', school: '🏫 学校・仕事', private: '🏠 プライベート', other: '📌 その他' };
  list.innerHTML = '';
  dayEvents.forEach((ev) => {
    const item = document.createElement('div');
    item.className = 'event-item cat-' + (ev.category || 'study');
    const time = ev.start
      ? `<span class="event-time">${ev.start}${ev.end ? ' - ' + ev.end : ''}</span>`
      : '';
    const rep = ev.repeat === 'weekly' ? '<span class="event-repeat">🔁 毎週</span>' : '';
    const cat = `<span class="event-cat">${CAT_LABEL[ev.category || 'study'] || ''}</span>`;
    item.innerHTML = `<span class="event-text"></span>${cat}${rep}${time}`;
    item.querySelector('.event-text').textContent = ev.text;
    // 削除（仮想の繰り返し予定は元の日付から削除）
    const del = document.createElement('button');
    del.className = 'event-delete';
    del.textContent = '✕';
    del.title = '削除';
    del.addEventListener('click', () => {
      const baseKey = ev.baseDate || eventModalDate;
      const arr = events[baseKey] || [];
      const idx = arr.findIndex((x) => x.id === ev.id);
      if (idx >= 0) arr.splice(idx, 1);
      if (arr.length === 0) delete events[baseKey];
      saveEvents();
      renderEventList();
      renderCalendar();
      renderTodaySchedule();
    });
    item.appendChild(del);
    list.appendChild(item);
  });
}

function addEvent() {
  if (!eventModalDate) return;
  const input = $('#eventInput');
  const text = input.value.trim();
  if (!text) return;
  const start = $('#eventStartTime').value || '';
  const end = $('#eventEndTime').value || '';
  const repeat = $('#eventRepeat').checked ? 'weekly' : null;
  const category = $('#eventCategory').value || 'study';
  if (!events[eventModalDate]) events[eventModalDate] = [];
  events[eventModalDate].push({ id: Date.now() + Math.random(), text, start, end, repeat, category });
  saveEvents();
  input.value = '';
  $('#eventRepeat').checked = false;
  renderEventList();
  renderCalendar();
  renderTodaySchedule();
}

function initEvents() {
  // 日付セルをクリックで予定モーダルを開く
  $('#calendarDays').addEventListener('click', (e) => {
    const cell = e.target.closest('.day[data-date]');
    if (cell) openEventModal(cell.dataset.date);
  });

  $('#eventAdd').addEventListener('click', addEvent);
  $('#eventInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') addEvent();
  });
  $('#eventClose').addEventListener('click', () => {
    $('#eventModal').classList.add('hidden');
    eventModalDate = null;
  });
  $('#eventModal').addEventListener('click', (e) => {
    if (e.target === $('#eventModal')) {
      $('#eventModal').classList.add('hidden');
      eventModalDate = null;
    }
  });
}

/* ============================================================
   カスタマイズ：フォント / 背景 / 文字サイズ
   ============================================================ */
const SETTINGS_KEY = 'dashboard_settings';

const PRESET_BGS = [
  { name: '夜のブルー', css: "linear-gradient(135deg,#1a1a2e 0%,#16213e 50%,#0f3460 100%)" },
  { name: '朝焼け',     css: "linear-gradient(135deg,#2c3e50 0%,#4a4e69 50%,#9a8c98 100%)" },
  { name: 'フォレスト', css: "linear-gradient(135deg,#0f2027 0%,#203a43 50%,#2c5364 100%)" },
  { name: 'ラベンダー', css: "linear-gradient(135deg,#232526 0%,#414345 50%,#66545e 100%)" },
  { name: 'シー',       css: "linear-gradient(135deg,#000428 0%,#004e92 100%)" },
  { name: 'サンセット', css: "linear-gradient(135deg,#1a1a2e 0%,#533483 50%,#e94560 100%)" },
];

const FONTS = [
  { name: 'ゴシック',    value: "'Yu Gothic','Hiragino Kaku Gothic ProN','Meiryo',sans-serif" },
  { name: '明朝',        value: "'Yu Mincho','Hiragino Mincho ProN','MS PMincho',serif" },
  { name: '丸ゴシック',  value: "'Hiragino Maru Gothic ProN','Yu Gothic UI','Meiryo',sans-serif" },
  { name: '手書き風',    value: "'Zen Kurenaido','Hachi Maru Pop','Yu Mincho',sans-serif" },
  { name: 'モノスペース', value: "'Courier New','MS Gothic',monospace" },
  { name: 'セリフ',      value: "'Georgia','Times New Roman',serif" },
  { name: 'インパクト',  value: "'Impact','Arial Black',sans-serif" },
];

// テーマごとの既定背景
const DARK_BG = PRESET_BGS[0].css;
const LIGHT_BG = "linear-gradient(135deg,#eef2ff 0%,#e7edff 50%,#dfe8ff 100%)";

const DEFAULT_SETTINGS = {
  font: FONTS[0].value,
  bg: PRESET_BGS[0].css,
  bgImage: null,          // DataURL（永続）または null
  bgCustom: false,        // 背景をユーザーが明示的に選んだか（false ならテーマ既定）
  fontSize: 16,
  textColor: '#f0f2ff',   // 文字色
  textColorCustom: false, // 文字色をユーザーが変更したか
  theme: 'dark',          // 'dark' | 'light'
  showFrames: false,      // カードの枠・背景・影を表示するか
  notifEnabled: false,    // ブラウザ通知
  chimeEnabled: true,     // タイマー音（チャイム）
  chimeVolume: 40,        // チャイム音量（0-100）
  ambientVolume: 40,      // 環境音の音量（0-100）
  focusMode: false,       // 集中モード（ポモドーロ作業中に他タブを隠す）
  deckSubjectSync: true,  // デッキ名を科目として自動登録
  memoAutoCard: false,    // 学習メモから自動でカード作成
  fcShuffle: false,       // フラッシュカード学習時にシャッフルする
  fcSessionLimit: 20,     // フラッシュカード1回の学習枚数（0 で無制限）
};

let settings = loadSettings();

function loadSettings() {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return { ...DEFAULT_SETTINGS };
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch (e) {
    return { ...DEFAULT_SETTINGS };
  }
}

function saveSettings() {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (e) {
    alert('設定の保存に失敗しました（ストレージ容量超過の可能性があります）。');
  }
}

function applySettings() {
  const isLight = settings.theme === 'light';
  // フォント
  document.documentElement.style.setProperty('--font-main', settings.font);
  // 文字サイズ
  document.documentElement.style.setProperty('--font-size-base', settings.fontSize + 'px');
  // テーマ
  document.body.classList.toggle('light', isLight);
  // 文字色（未カスタムならテーマに応じた既定色）
  const effectiveText = settings.textColorCustom
    ? settings.textColor
    : (isLight ? '#16192b' : '#f0f2ff');
  document.documentElement.style.setProperty('--text-main', effectiveText);
  // カードの枠（ON のときだけ .glass の背景・ボーダー・影を表示）
  document.body.classList.toggle('show-frames', !!settings.showFrames);
  // 背景：アップロード画像 > ユーザー選択 > テーマ既定
  if (settings.bgImage) {
    document.body.style.background = `url("${settings.bgImage}") center / cover fixed`;
  } else if (settings.bgCustom) {
    document.body.style.background = settings.bg;
  } else {
    document.body.style.background = isLight ? LIGHT_BG : DARK_BG;
  }
  // フォントボタンのアクティブ表示
  $$('.font-btn').forEach((b) => {
    b.classList.toggle('active', b.dataset.font === settings.font);
  });
  // スウォッチのアクティブ表示
  $$('.bg-swatch').forEach((s) => {
    s.classList.toggle('active', s.dataset.css === settings.bg && !settings.bgImage && settings.bgCustom);
  });
  $('#fontSizeRange').value = settings.fontSize;
  $('#fontSizeLabel').textContent = settings.fontSize + 'px';
  $('#textColorInput').value = effectiveText;
  $('#textColorLabel').textContent = effectiveText.toUpperCase();
  $('#showFrames').checked = !!settings.showFrames;
  // 新設定のUI反映（通知 / チャイム / 集中モード / 環境音）
  $('#notifToggle').checked = !!settings.notifEnabled;
  $('#chimeToggle').checked = !!settings.chimeEnabled;
  $('#chimeVolume').value = settings.chimeVolume;
  $('#chimeVolumeLabel').textContent = settings.chimeVolume + '%';
  $('#focusModeToggle').checked = !!settings.focusMode;
  // フラッシュカード学習の設定（1回の枚数・シャッフル）をUIへ反映
  const limModal = $('#fcSessionLimit');
  if (limModal) limModal.value = (typeof settings.fcSessionLimit === 'number' ? settings.fcSessionLimit : 20);
  const shufModal = $('#fcShuffleToggle');
  if (shufModal) shufModal.checked = !!settings.fcShuffle;
  const limDeck = $('#deckStudyLimit');
  if (limDeck) limDeck.value = (typeof settings.fcSessionLimit === 'number' ? settings.fcSessionLimit : 20);
  const av = $('#ambientVolume');
  if (av) {
    av.value = settings.ambientVolume;
    $('#ambientVolumeLabel').textContent = settings.ambientVolume + '%';
  }
  // テーマ切替ボタン表示
  const tq = $('#themeQuick');
  if (tq) tq.textContent = isLight ? '☀️' : '🌙';
  applyFocusModeUI();
}

function initCustomize() {
  // フォントボタン生成
  const fontBox = $('#fontButtons');
  FONTS.forEach((f) => {
    const b = document.createElement('button');
    b.className = 'font-btn';
    b.textContent = f.name;
    b.style.fontFamily = f.value;
    b.dataset.font = f.value;
    b.addEventListener('click', () => {
      settings.font = f.value;
      applySettings();
    });
    fontBox.appendChild(b);
  });

  // 背景プリセット生成
  const bgBox = $('#bgPalette');
  PRESET_BGS.forEach((bg) => {
    const s = document.createElement('div');
    s.className = 'bg-swatch';
    s.title = bg.name;
    s.style.background = bg.css;
    s.dataset.css = bg.css;
    s.addEventListener('click', () => {
      settings.bg = bg.css;
      settings.bgImage = null;
      settings.bgCustom = true;
      applySettings();
    });
    bgBox.appendChild(s);
  });

  // 背景画像アップロード
  $('#bgImageInput').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      settings.bgImage = reader.result;
      settings.bgCustom = true;
      applySettings();
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  });

  $('#bgReset').addEventListener('click', () => {
    settings.bgImage = null;
    settings.bg = DEFAULT_SETTINGS.bg;
    settings.bgCustom = false;
    applySettings();
  });

  // 文字サイズスライダー
  $('#fontSizeRange').addEventListener('input', (e) => {
    settings.fontSize = Number(e.target.value);
    applySettings();
  });

  // 文字色
  $('#textColorInput').addEventListener('input', (e) => {
    settings.textColor = e.target.value;
    settings.textColorCustom = true;
    applySettings();
  });
  $('#textColorReset').addEventListener('click', () => {
    settings.textColor = DEFAULT_SETTINGS.textColor;
    settings.textColorCustom = false;
    applySettings();
  });

  // テーマ切替（設定パネル）
  $('#themeDarkBtn').addEventListener('click', () => setTheme('dark'));
  $('#themeLightBtn').addEventListener('click', () => setTheme('light'));
  // テーマ切替（ナビのクイックボタン）
  $('#themeQuick').addEventListener('click', () => {
    setTheme(settings.theme === 'light' ? 'dark' : 'light');
  });

  // カードの枠の表示/非表示
  $('#showFrames').addEventListener('change', (e) => {
    settings.showFrames = e.target.checked;
    applySettings();
  });

  // ブラウザ通知
  $('#notifToggle').addEventListener('change', async (e) => {
    if (e.target.checked) {
      const ok = await requestNotificationPermission();
      if (!ok) {
        alert('ブラウザ通知が許可されていません。ブラウザの設定から許可してください。');
        settings.notifEnabled = false;
        e.target.checked = false;
      } else {
        settings.notifEnabled = true;
      }
    } else {
      settings.notifEnabled = false;
    }
    saveSettings();
  });

  // タイマー音（チャイム）
  $('#chimeToggle').addEventListener('change', (e) => {
    settings.chimeEnabled = e.target.checked;
    saveSettings();
  });
  $('#chimeVolume').addEventListener('input', (e) => {
    settings.chimeVolume = Number(e.target.value);
    $('#chimeVolumeLabel').textContent = settings.chimeVolume + '%';
    saveSettings();
    // 音量プレビュー（テスト音）
    playChime();
  });

  // 環境音の音量
  $('#ambientVolume').addEventListener('input', (e) => {
    settings.ambientVolume = Number(e.target.value);
    $('#ambientVolumeLabel').textContent = settings.ambientVolume + '%';
    saveSettings();
    setAmbientVolume(settings.ambientVolume);
  });

  // 集中モード
  $('#focusModeToggle').addEventListener('change', (e) => {
    settings.focusMode = e.target.checked;
    saveSettings();
    applyFocusModeUI();
  });

  // 背景のカスタムカラー（選択と同時に反映）
  $('#bgCustomColor').addEventListener('input', (e) => {
    settings.bg = e.target.value;
    settings.bgImage = null;
    settings.bgCustom = true;
    applySettings();
  });

  // 科目の管理
  $('#newSubjectAdd').addEventListener('click', () => {
    const inp = $('#newSubjectInput');
    const name = inp.value.trim();
    if (!name) return;
    if (subjects.includes(name)) { alert('同じ科目がすでにあります。'); return; }
    subjects.push(name);
    saveSubjects();
    inp.value = '';
    renderSubjectManage();
    populateSubjectSelects();
  });
  $('#newSubjectInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') $('#newSubjectAdd').click();
  });

  // 設定モーダル開閉
  $('#settingsFab').addEventListener('click', () => $('#settingsModal').classList.remove('hidden'));
  $('#settingsClose').addEventListener('click', () => $('#settingsModal').classList.add('hidden'));
  $('#settingsModal').addEventListener('click', (e) => {
    if (e.target === $('#settingsModal')) $('#settingsModal').classList.add('hidden');
  });

  // 保存 / 全リセット
  $('#settingsSave').addEventListener('click', () => {
    saveSettings();
    alert('設定を保存しました。');
    $('#settingsModal').classList.add('hidden');
  });
  $('#settingsResetAll').addEventListener('click', () => {
    settings = { ...DEFAULT_SETTINGS };
    applySettings();
    saveSettings();
    // 目標もリセット
    goals.daily = 0; goals.weekly = 0; goals.monthly = 0;
    saveGoals();
    renderGoals();
  });

  renderSubjectManage();
  applySettings();
}

// テーマを設定して保存
function setTheme(theme) {
  settings.theme = theme === 'light' ? 'light' : 'dark';
  saveSettings();
  applySettings();
}

/* ============================================================
   科目（サブジェクト）管理
   - 学習記録・円グラフ・復習で共通利用
   ============================================================ */
const SUBJECTS_KEY = 'dashboard_subjects';
const DEFAULT_SUBJECTS = ['英語', '数学', '国語', '理科', '社会', '資格勉強', 'プログラミング'];

let subjects = loadSubjects();

function loadSubjects() {
  try {
    const raw = localStorage.getItem(SUBJECTS_KEY);
    if (!raw) return [...DEFAULT_SUBJECTS];
    const arr = JSON.parse(raw);
    return Array.isArray(arr) && arr.length ? arr : [...DEFAULT_SUBJECTS];
  } catch (e) {
    return [...DEFAULT_SUBJECTS];
  }
}

function saveSubjects() {
  try {
    localStorage.setItem(SUBJECTS_KEY, JSON.stringify(subjects));
  } catch (e) { /* 無視 */ }
}

// 科目セレクト（学習記録・ポモドーロ・復習）を最新化
function populateSubjectSelects() {
  const fills = ['#studySubject', '#pomoSubject', '#reviewSubject'];
  fills.forEach((sel) => {
    const el = $(sel);
    if (!el) return;
    const prev = el.value;
    el.innerHTML = '';
    subjects.forEach((s) => {
      const o = document.createElement('option');
      o.value = s;
      o.textContent = s;
      el.appendChild(o);
    });
    if (subjects.includes(prev)) el.value = prev;
  });
}

function renderSubjectManage() {
  const box = $('#subjectManageList');
  if (!box) return;
  box.innerHTML = '';
  subjects.forEach((s, i) => {
    const chip = document.createElement('span');
    chip.className = 'subject-chip';
    const label = document.createElement('span');
    label.textContent = s;
    const del = document.createElement('button');
    del.textContent = '✕';
    del.title = '削除';
    del.addEventListener('click', () => {
      if (subjects.length <= 1) { alert('最低1つの科目が必要です。'); return; }
      subjects.splice(i, 1);
      saveSubjects();
      renderSubjectManage();
      populateSubjectSelects();
    });
    chip.appendChild(label);
    chip.appendChild(del);
    box.appendChild(chip);
  });
}

/* ============================================================
   音楽プレイヤー（MP3）
   選択したファイルはオブジェクトURLとして再生（ブラウザ内のみ）
   ============================================================ */
// 対応する音声ファイルの拡張子（ブラウザの <audio> で再生可能な形式）
const AUDIO_EXTS = ['mp3', 'wav', 'ogg', 'oga', 'm4a', 'aac', 'flac', 'webm'];

const musicState = {
  tracks: [],          // { id, name, url }
  currentIndex: -1,
};

function initMusicPlayer() {
  const input = $('#audioInput');
  const queueEl = $('#musicQueue');
  const audio = $('#audioPlayer');

  function renderQueue() {
    if (musicState.tracks.length === 0) {
      queueEl.innerHTML = '<p style="color:var(--text-dim);font-size:0.9rem;">音声ファイル（MP3 / WAV / OGG / M4A / FLAC）を選択するとここに一覧が表示されます</p>';
      return;
    }
    queueEl.innerHTML = '';
    musicState.tracks.forEach((track, i) => {
      const item = document.createElement('div');
      item.className = 'queue-item' + (i === musicState.currentIndex ? ' playing' : '');
      item.innerHTML = `<span class="track-icon">🎵</span><span class="track-name"></span><span style="font-size:0.8rem;color:var(--text-dim);">${i === musicState.currentIndex ? '再生中' : ''}</span>`;
      item.querySelector('.track-name').textContent = track.name;
      item.addEventListener('click', () => playTrack(i));
      queueEl.appendChild(item);
    });
  }

  function playTrack(i) {
    if (i < 0 || i >= musicState.tracks.length) return;
    musicState.currentIndex = i;
    const track = musicState.tracks[i];
    audio.src = track.url;
    audio.play().catch(() => {});
    renderQueue();
  }

  function playNext() {
    if (musicState.tracks.length === 0) return;
    playTrack((musicState.currentIndex + 1) % musicState.tracks.length);
  }

  function playPrev() {
    if (musicState.tracks.length === 0) return;
    const prev = (musicState.currentIndex - 1 + musicState.tracks.length) % musicState.tracks.length;
    playTrack(prev);
  }

  input.addEventListener('change', (e) => {
    const files = Array.from(e.target.files || []);
    const skipped = [];
    files.forEach((file) => {
      const ext = file.name.toLowerCase().split('.').pop();
      const okByType = file.type.startsWith('audio/');
      const okByExt = AUDIO_EXTS.includes(ext);
      if (!okByType && !okByExt) {
        skipped.push(file.name);
        return;
      }
      const url = URL.createObjectURL(file);
      musicState.tracks.push({ id: crypto.randomUUID ? crypto.randomUUID() : Date.now() + Math.random(), name: file.name, url });
    });
    if (skipped.length > 0) {
      alert('対応していない形式のファイルはスキップしました:\n' + skipped.join('\n'));
    }
    if (musicState.currentIndex === -1 && musicState.tracks.length > 0) {
      playTrack(0);
    } else {
      renderQueue();
    }
    input.value = '';
  });

  // 曲が終わったら次の曲へ（最後まで行ったら先頭に戻る）
  audio.addEventListener('ended', playNext);
  // 次の曲 / 前の曲ボタン
  $('#audioNext').addEventListener('click', playNext);
  $('#audioPrev').addEventListener('click', playPrev);
}

/* ============================================================
   ToDoリスト（localStorage保存）
   - 優先度 / 検索 / 並べ替え / ドラッグ&ドロップ
   ============================================================ */
const TODO_KEY = 'dashboard_todos';
let todos = loadTodos();

const PRIO_LABEL = { high: '高', mid: '中', low: '低' };
const PRIO_ORDER = { high: 0, mid: 1, low: 2 };

function loadTodos() {
  try {
    const raw = localStorage.getItem(TODO_KEY);
    const arr = raw ? JSON.parse(raw) : [];
    // 優先度の既定値を補完
    return (Array.isArray(arr) ? arr : []).map((t) => ({ priority: 'mid', ...t }));
  } catch (e) {
    return [];
  }
}

function saveTodos() {
  try {
    localStorage.setItem(TODO_KEY, JSON.stringify(todos));
  } catch (e) { /* 容量超過時は無視 */ }
}

// 表示対象のインデックス配列を（検索・並べ替えを適用して）返す
function getVisibleTodoIndices() {
  const q = ($('#todoSearch') ? $('#todoSearch').value : '').trim().toLowerCase();
  const sort = ($('#todoSort') ? $('#todoSort').value : 'manual');
  let idx = todos.map((_, i) => i);
  if (q) idx = idx.filter((i) => (todos[i].text || '').toLowerCase().includes(q));
  if (sort !== 'manual') {
    idx.sort((a, b) => {
      const ta = todos[a], tb = todos[b];
      if (sort === 'priority') return (PRIO_ORDER[ta.priority] ?? 1) - (PRIO_ORDER[tb.priority] ?? 1);
      if (sort === 'due') {
        const da = ta.due || '9999-99-99', db = tb.due || '9999-99-99';
        return da < db ? -1 : da > db ? 1 : 0;
      }
      if (sort === 'created') return (ta.createdAt || 0) - (tb.createdAt || 0);
      return 0;
    });
  }
  return idx;
}

function renderTodos() {
  const list = $('#todoList');
  list.innerHTML = '';
  const sort = ($('#todoSort') ? $('#todoSort').value : 'manual');
  const draggable = sort === 'manual';
  const visible = getVisibleTodoIndices();

  visible.forEach((i) => {
    const todo = todos[i];
    const li = document.createElement('li');
    li.className = 'todo-item' + (todo.done ? ' is-done' : '');
    li.draggable = draggable;
    li.dataset.index = i;

    // 期限の強調表示
    const due = todo.due || null;
    let dueCls = '', dueLabel = '';
    if (due && !todo.done) {
      const today = todayKey();
      if (due < today) { dueCls = 'due-overdue'; dueLabel = '期限切れ'; }
      else if (due === today) { dueCls = 'due-today'; dueLabel = '今日'; }
      else { dueCls = 'due-future'; dueLabel = due.replace(/-/g, '/'); }
    } else if (due) {
      dueCls = 'due-done';
      dueLabel = due.replace(/-/g, '/');
    }

    // ドラッグハンドル
    const handle = document.createElement('span');
    handle.className = 'drag-handle';
    handle.textContent = draggable ? '⋮⋮' : '';
    handle.title = draggable ? 'ドラッグして並べ替え' : '';

    const check = document.createElement('input');
    check.type = 'checkbox';
    check.className = 'todo-check';
    check.checked = todo.done;
    check.addEventListener('change', () => {
      todos[i].done = check.checked;
      saveTodos();
      renderTodos();
    });

    const text = document.createElement('span');
    text.className = 'todo-text' + (todo.done ? ' done' : '');
    text.textContent = todo.text;
    text.title = 'クリックで完了/未完了';
    text.addEventListener('click', () => {
      todos[i].done = !todos[i].done;
      saveTodos();
      renderTodos();
    });

    // 優先度バッジ
    const prio = document.createElement('span');
    prio.className = 'todo-prio ' + (todo.priority || 'mid');
    prio.textContent = PRIO_LABEL[todo.priority || 'mid'];

    const dueSpan = document.createElement('span');
    dueSpan.className = 'todo-due ' + dueCls;
    dueSpan.textContent = due ? dueLabel : '';
    dueSpan.title = due ? '締め切り: ' + due : '';

    const del = document.createElement('button');
    del.className = 'todo-delete';
    del.textContent = '✕';
    del.title = '削除';
    del.addEventListener('click', () => {
      todos.splice(i, 1);
      saveTodos();
      renderTodos();
    });

    li.appendChild(handle);
    li.appendChild(check);
    li.appendChild(prio);
    li.appendChild(text);
    li.appendChild(dueSpan);
    li.appendChild(del);

    // ドラッグ&ドロップ
    if (draggable) {
      li.addEventListener('dragstart', (e) => {
        dragSrcIndex = i;
        li.classList.add('dragging');
        e.dataTransfer.effectAllowed = 'move';
      });
      li.addEventListener('dragend', () => li.classList.remove('dragging'));
      li.addEventListener('dragover', (e) => {
        e.preventDefault();
        li.classList.add('drag-over');
      });
      li.addEventListener('dragleave', () => li.classList.remove('drag-over'));
      li.addEventListener('drop', (e) => {
        e.preventDefault();
        li.classList.remove('drag-over');
        if (dragSrcIndex === null || dragSrcIndex === i) return;
        const moved = todos.splice(dragSrcIndex, 1)[0];
        todos.splice(i, 0, moved);
        saveTodos();
        dragSrcIndex = null;
        renderTodos();
      });
    }

    list.appendChild(li);
  });

  if (visible.length === 0) {
    list.innerHTML = '<li class="hint" style="padding:10px 4px;">該当するタスクがありません</li>';
  }

  const remaining = todos.filter((t) => !t.done).length;
  $('#todoRemaining').textContent = `${remaining}件の残り（全${todos.length}件）`;
  renderTodaySchedule();
}

let dragSrcIndex = null;

function initTodo() {
  $('#todoAdd').addEventListener('click', addTodo);
  $('#todoInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') addTodo(); });
  $('#todoClearDone').addEventListener('click', () => {
    todos = todos.filter((t) => !t.done);
    saveTodos();
    renderTodos();
  });
  $('#todoSearch').addEventListener('input', renderTodos);
  $('#todoSort').addEventListener('change', renderTodos);
  renderTodos();
}

function addTodo() {
  const input = $('#todoInput');
  const text = input.value.trim();
  if (!text) return;
  const due = $('#todoDue').value || null; // YYYY-MM-DD（空なら期限なし）
  const priority = $('#todoPriority').value || 'mid';
  todos.unshift({ text, done: false, createdAt: Date.now(), due, priority });
  saveTodos();
  renderTodos();
  input.value = '';
  $('#todoDue').value = '';
  input.focus();
}

/* ============================================================
   学習時間の測定
   - 開始〜終了を秒単位で計測し、日付ごとに加算（localStorage）
   - タブを閉じても累計は保持。計測中データは監視で保存
   ============================================================ */
const STUDY_KEY = 'dashboard_study';

let study = loadStudy(); // { byDate: {"2026-09-25": 1234}, bySubject: {"英語": 600}, sessions: [...] }

function loadStudy() {
  try {
    const raw = localStorage.getItem(STUDY_KEY);
    if (!raw) return { byDate: {}, bySubject: {}, sessions: [] };
    const d = JSON.parse(raw);
    return {
      byDate: d.byDate || {},
      bySubject: d.bySubject || {},
      sessions: Array.isArray(d.sessions) ? d.sessions : [],
    };
  } catch (e) {
    return { byDate: {}, bySubject: {}, sessions: [] };
  }
}

function saveStudy() {
  try {
    localStorage.setItem(STUDY_KEY, JSON.stringify(study));
  } catch (e) { /* 無視 */ }
}

// 学習時間を1件記録する（科目タグ付き）。日別・科目別の両方に加算。
function recordStudy(sec, subject, memo, src) {
  if (!(sec > 0)) return;
  const key = todayKey();
  study.byDate[key] = (study.byDate[key] || 0) + sec;
  const subj = subject || '未分類';
  study.bySubject[subj] = (study.bySubject[subj] || 0) + sec;
  study.sessions.push({ date: key, sec, at: Date.now(), subject: subj, memo: memo || '', src: src || 'manual' });
  saveStudy();
}

const studyState = {
  running: false,
  startedAt: null,   // Date
  accMs: 0,          // 一時停止分までの累積（ms）
};

let studyTimer = null;

function getStudySecondsToday() {
  return study.byDate[todayKey()] || 0;
}

function renderStudy() {
  const base = getStudySecondsToday();
  let extra = 0;
  if (studyState.running) {
    extra = (Date.now() - studyState.startedAt) + studyState.accMs;
  }
  $('#studyToday').textContent = fmtHMS(base + Math.floor(extra / 1000));

  const status = $('#studyStatus');
  if (studyState.running) {
    status.textContent = '📖 計測中...（このタブを閉じるか停止するまで加算されます）';
    status.style.color = '#9df0cd';
  } else {
    status.textContent = '計測していません';
    status.style.color = 'var(--text-dim)';
  }
  renderWeekBars();
  renderGoals();
  renderPieChart();
}

function renderWeekBars() {
  const now = new Date();
  const dayOfWeek = now.getDay(); // 0=日
  const container = $('#weekBars');
  const week = ['日', '月', '火', '水', '木', '金', '土'];
  const maxSec = Math.max(
    3600,
    ...Object.keys(study.byDate)
      .filter((k) => {
        const d = new Date(k + 'T00:00:00');
        const diff = (now - d) / 86400000;
        return diff >= 0 && diff < 7;
    })
      .map((k) => study.byDate[k])
  );

  let html = '';
  for (let i = 0; i < 7; i++) {
    const d = new Date(now);
    d.setDate(now.getDate() - (dayOfWeek - i));
    const key = todayKey(d);
    const sec = study.byDate[key] || 0;
    const pct = Math.max(3, Math.round((sec / maxSec) * 100));
    const label =
      sec >= 3600
        ? `${(sec / 3600).toFixed(1)}h`
        : sec >= 60
        ? `${Math.floor(sec / 60)}m`
        : `${sec}s`;
    const isToday = i === dayOfWeek;
    html += `
      <div class="bar-col${isToday ? ' today' : ''}">
        <div class="bar" style="height:${pct}%" title="${week[i]}: ${label}"></div>
        <div class="bar-label">${week[i]}<br>${isToday ? '今日' : ''}</div>
      </div>`;
  }
  container.innerHTML = html;
}

function studyTick() {
  renderStudy();
}

function initStudy() {
  $('#studyStart').addEventListener('click', () => {
    if (studyState.running) return;
    studyState.running = true;
    studyState.startedAt = Date.now();
    studyState.accMs = 0;
    if (!studyTimer) {
      studyTimer = setInterval(studyTick, 500);
    }
    renderStudy();
  });

  $('#studyPause').addEventListener('click', () => {
    if (!studyState.running) return;
    studyState.accMs += Date.now() - studyState.startedAt;
    studyState.running = false;
    clearInterval(studyTimer);
    studyTimer = null;
    renderStudy();
  });

  $('#studyStop').addEventListener('click', () => {
    let addSec = 0;
    if (studyState.running) {
      addSec = Math.floor((Date.now() - studyState.startedAt + studyState.accMs) / 1000);
    } else {
      addSec = Math.floor(studyState.accMs / 1000);
    }
    if (addSec > 0) {
      const subject = $('#studySubject').value || '未分類';
      const memo = $('#studyMemo').value.trim();
      recordStudy(addSec, subject, memo, 'manual');
      saveStudy();
      updateStreak();
      renderHeatmap();
      renderReports();
      // メモがあれば復習項目として自動登録（設定ON時）
      if (memo && $('#reviewAutoFromMemo').checked) {
        addReviewFromMemo(memo, subject, addSec);
      }
      // メモがあればフラッシュカードも自動作成（設定ON時／連動③）
      if (memo && settings.memoAutoCard) {
        const deck = fcGetOrCreateDeckByName(subject);
        const now = Date.now();
        deck.cards.push({ id: fcUid(), front: memo, back: '', note: '', createdAt: now, srs: fcNewSrs(now), history: [] });
        saveFlashcards();
        renderDecks();
      }
      $('#studyMemo').value = '';
    }
    studyState.running = false;
    studyState.accMs = 0;
    clearInterval(studyTimer);
    studyTimer = null;
    renderStudy();
    alert(`${fmtHMS(addSec)} を今日の記録に追加しました。`);
  });

  // タブが閉じられる直前に計測中データを仮保存（ページ更新・移動時に活用）
  window.addEventListener('pagehide', () => {
    if (studyState.running) {
      const addSec = Math.floor((Date.now() - studyState.startedAt + studyState.accMs) / 1000);
      if (addSec > 0) {
        recordStudy(addSec, $('#studySubject').value || '未分類', $('#studyMemo').value.trim(), 'manual');
      }
    }
  });

  // 学習記録のエクスポート（日別）
  $('#studyExport').addEventListener('click', () => {
    const lines = ['日付,学習時間(秒),時間(hh:mm:ss)'];
    Object.keys(study.byDate)
      .sort()
      .forEach((k) => {
        lines.push(`${k},${study.byDate[k]},${fmtHMS(study.byDate[k])}`);
    });
    const blob = new Blob(['\uFEFF' + lines.join('\n')], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `study_record_${todayKey()}.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
  });

  // 円グラフの集計期間
  $('#pieRange').addEventListener('change', renderPieChart);

  renderStudy();
}

/* ============================================================
   ポモドーロタイマー
   作業 / 短休憩 / 長休憩 を設定に応じて自動巡回
   ============================================================ */
const pomoState = {
  mode: 'work',        // work | short | long
  remaining: 25 * 60,  // 秒
  running: false,
  workCount: 0,
  timer: null,
};

function getPomoDuration() {
  const m = Number($('#workMin').value) || 25;
  const s = Number($('#shortMin').value) || 5;
  const l = Number($('#longMin').value) || 15;
  return { work: m * 60, short: s * 60, long: l * 60 };
}

function renderPomodoro() {
  const modeLabel = { work: '作業', short: '短休憩', long: '長休憩' };
  const modeEl = $('#pomodoroMode');
  modeEl.textContent = modeLabel[pomoState.mode];
  modeEl.classList.toggle('break', pomoState.mode !== 'work');

  const m = Math.floor(pomoState.remaining / 60);
  const s = pomoState.remaining % 60;
  $('#pomodoroTime').textContent = `${pad2(m)}:${pad2(s)}`;

  $('#pomodoroCount').textContent = pomoState.workCount;
  $('#pomodoroTarget').textContent = $('#roundsBeforeLong').value;
  document.title = `🍅 ${pad2(m)}:${pad2(s)} - 学習ダッシュボード`;
  applyFocusModeUI();
}

function pomoTick() {
  if (!pomoState.running) return;
  pomoState.remaining--;
  if (pomoState.remaining <= 0) {
    finishPomodoroPhase();
  }
  renderPomodoro();
}

function finishPomodoroPhase() {
  const dur = getPomoDuration();
  const target = Number($('#roundsBeforeLong').value) || 4;
  playChime();

  if (pomoState.mode === 'work') {
    pomoState.workCount++;
    // 作業1セットを学習時間として自動記録
    addPomodoroStudySeconds(dur.work);
    notify('🍅 ポモドーロ作業が終了しました', `作業セット ${pomoState.workCount} 回目完了！休憩しましょう。`);
    if (pomoState.workCount % target === 0) {
      pomoState.mode = 'long';
    } else {
      pomoState.mode = 'short';
    }
    pomoState.remaining = dur[pomoState.mode];
  } else {
    // 休憩終了 → 作業へ
    pomoState.mode = 'work';
    pomoState.remaining = dur.work;
    notify('☕ 休憩が終了しました', '次の作業セットを始めましょう！');
  }
  renderPomodoro();
}

// ポモドーロ作業1セットを学習時間に加算（セットごとに丸ごと加算）
function addPomodoroStudySeconds(sec) {
  try {
    const subject = $('#pomoSubject').value || '未分類';
    recordStudy(sec, subject, '', 'pomodoro');
    renderStudy();
    updateStreak();
    renderHeatmap();
    renderReports();
  } catch (e) { /* 無視 */ }
}

function playChime() {
  // タイマー音（チャイム）: OFF のときは鳴らさない / 音量は設定に連動
  if (settings.chimeEnabled === false) return;
  const vol = Math.max(0.02, (settings.chimeVolume || 40) / 100) * 0.6;
  try {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    const playTone = (freq, start, dur, v) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(v, ctx.currentTime + start);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + start + dur);
      osc.connect(gain).connect(ctx.destination);
      osc.start(ctx.currentTime + start);
      osc.stop(ctx.currentTime + start + dur + 0.05);
    };
    playTone(880, 0, 0.25, vol);
    playTone(880, 0.3, 0.25, vol);
    playTone(1320, 0.6, 0.5, vol);
  } catch (e) { /* 音が鳴らない環境では無視 */ }
}

// ---- ブラウザ通知 ----
function isNotificationSupported() {
  return 'Notification' in window;
}

function requestNotificationPermission() {
  return new Promise((resolve) => {
    if (!isNotificationSupported()) return resolve(false);
    if (Notification.permission === 'granted') return resolve(true);
    if (Notification.permission === 'denied') return resolve(false);
    Notification.requestPermission().then((p) => resolve(p === 'granted')).catch(() => resolve(false));
  });
}

function notify(title, body) {
  if (!settings.notifEnabled) return;
  if (!isNotificationSupported()) return;
  if (Notification.permission !== 'granted') return;
  try {
    const n = new Notification(title, { body, icon: undefined, tag: 'dashboard-notif' });
    n.onclick = () => { window.focus(); n.close(); };
    setTimeout(() => n.close(), 15000);
  } catch (e) { /* 無視 */ }
}

// ---- 集中モード ----
function applyFocusModeUI() {
  const active = !!(settings.focusMode && pomoState.mode === 'work' && pomoState.running);
  document.body.classList.toggle('focus-mode', active);
}

function initPomodoro() {
  const btn = $('#pomodoroStart');

  btn.addEventListener('click', () => {
    if (!pomoState.running) {
      // 開始時に設定値を反映（カウントダウン中に設定を変えても即変更）
      const dur = getPomoDuration();
      if (pomoState.remaining === dur[pomoState.mode] || pomoState.remaining <= 0) {
        pomoState.remaining = dur[pomoState.mode];
    }
      pomoState.running = true;
      btn.textContent = '⏸ 一時停止';
      if (!pomoState.timer) {
        pomoState.timer = setInterval(pomoTick, 1000);
    }
    } else {
      pomoState.running = false;
      btn.textContent = '▶ 再開';
    }
    renderPomodoro();
  });

  $('#pomodoroReset').addEventListener('click', () => {
    pomoState.running = false;
    clearInterval(pomoState.timer);
    pomoState.timer = null;
    pomoState.mode = 'work';
    pomoState.remaining = getPomoDuration().work;
    btn.textContent = '▶ スタート';
    renderPomodoro();
  });

  // 設定変更時、未開始なら即反映
  ['workMin', 'shortMin', 'longMin', 'roundsBeforeLong'].forEach((id) => {
    $('#' + id).addEventListener('change', () => {
      if (!pomoState.running) {
        pomoState.remaining = getPomoDuration()[pomoState.mode];
    }
      renderPomodoro();
    });
  });

  // 集中モードのオン/オフ連動（ポモドーロ開始/停止で反映）
  btn.addEventListener('click', applyFocusModeUI);

  renderPomodoro();
}

/* ============================================================
   目標設定と進捗バー（今日 / 今週 / 今月）
   ============================================================ */
const GOALS_KEY = 'dashboard_goals'; // 分単位 {daily, weekly, monthly}

// 旧キーからの移行も考慮して読み込む
let goals = loadGoals();

function loadGoals() {
  let g = { daily: 0, weekly: 0, monthly: 0 };
  try {
    const raw = localStorage.getItem(GOALS_KEY);
    if (raw) {
      const d = JSON.parse(raw);
      g.daily = Number(d.daily) || 0;
      g.weekly = Number(d.weekly) || 0;
      g.monthly = Number(d.monthly) || 0;
    } else {
      // 旧 dailyGoal キーからの移行
      const old = localStorage.getItem('dashboard_goal');
      if (old) g.daily = Number(old) || 0;
    }
  } catch (e) { /* 無視 */ }
  return g;
}

function saveGoals() {
  try {
    localStorage.setItem(GOALS_KEY, JSON.stringify(goals));
  } catch (e) { /* 無視 */ }
}

// 指定範囲（日数）の学習時間合計（分）
function studyMinutesInLastDays(days) {
  let sec = 0;
  for (let i = 0; i < days; i++) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    sec += study.byDate[todayKey(d)] || 0;
  }
  return Math.floor(sec / 60);
}

function renderProgressBar(fillSel, statusSel, currentMin, goalMin, label) {
  const fill = $(fillSel);
  const status = $(statusSel);
  if (!fill || !status) return;
  if (!goalMin || goalMin <= 0) {
    fill.style.width = '0%';
    fill.classList.remove('reached');
    status.textContent = `${label}目標が未設定です`;
    status.classList.remove('done');
    return;
  }
  const pct = Math.min(100, Math.round((currentMin / goalMin) * 100));
  fill.style.width = pct + '%';
  fill.classList.toggle('reached', pct >= 100);
  if (pct >= 100) {
    status.textContent = `🎉 ${label}目標達成！${goalMin} 分に対して ${currentMin} 分`;
    status.classList.add('done');
  } else {
    status.textContent = `📈 ${currentMin} / ${goalMin} 分（${pct}%）・あと ${goalMin - currentMin} 分`;
    status.classList.remove('done');
  }
}

function renderGoals() {
  const iD = $('#goalMin'), iW = $('#goalWeekMin'), iM = $('#goalMonthMin');
  if (iD) iD.value = goals.daily || '';
  if (iW) iW.value = goals.weekly || '';
  if (iM) iM.value = goals.monthly || '';

  renderProgressBar('#goalProgress', '#goalStatus', studyMinutesInLastDays(1), goals.daily, '今日');
  renderProgressBar('#goalWeekProgress', '#goalWeekStatus', studyMinutesInLastDays(7), goals.weekly, '今週');
  renderProgressBar('#goalMonthProgress', '#goalMonthStatus', studyMinutesInLastDays(30), goals.monthly, '今月');
}

function initGoals() {
  const setup = (btnSel, inputSel, key) => {
    const set = () => {
      goals[key] = Math.max(0, Number($(inputSel).value) || 0);
      saveGoals();
      renderGoals();
    };
    $(btnSel).addEventListener('click', set);
    $(inputSel).addEventListener('keydown', (e) => { if (e.key === 'Enter') set(); });
  };
  setup('#goalSet', '#goalMin', 'daily');
  setup('#goalWeekSet', '#goalWeekMin', 'weekly');
  setup('#goalMonthSet', '#goalMonthMin', 'monthly');
  renderGoals();
}

/* ============================================================
   科目別 円グラフ（SVGを自前で描画 / 外部ライブラリ不要）
   ============================================================ */
const PIE_COLORS = ['#6c8cff', '#ffb86c', '#50d4a0', '#e9709a', '#b58cff', '#5ad0e0', '#f2d45c', '#ff8b6b', '#8cd0ff', '#c0e07a'];

// 期間（日数 or 'all'）で科目別の秒数を集計
function aggregateBySubject(range) {
  const totals = {};
  if (range === 'all') {
    for (const k in study.bySubject) totals[k] = (totals[k] || 0) + (study.bySubject[k] || 0);
    // 旧データ（bySubject がない）へのフォールバック
    if (Object.keys(totals).length === 0) {
      study.sessions.forEach((s) => {
        const subj = s.subject || '未分類';
        totals[subj] = (totals[subj] || 0) + (s.sec || 0);
      });
    }
    return totals;
  }
  const days = Number(range) || 30;
  const from = new Date();
  from.setDate(from.getDate() - (days - 1));
  from.setHours(0, 0, 0, 0);
  study.sessions.forEach((s) => {
    const d = new Date(s.date + 'T00:00:00');
    if (d >= from) {
      const subj = s.subject || '未分類';
      totals[subj] = (totals[subj] || 0) + (s.sec || 0);
    }
  });
  return totals;
}

function renderPieChart() {
  const chartEl = $('#pieChart');
  const legendEl = $('#pieLegend');
  if (!chartEl || !legendEl) return;
  const range = $('#pieRange') ? $('#pieRange').value : '30';
  const totals = aggregateBySubject(range);
  const entries = Object.entries(totals).filter(([, v]) => v > 0).sort((a, b) => b[1] - a[1]);
  const total = entries.reduce((a, [, v]) => a + v, 0);

  if (total <= 0) {
    chartEl.innerHTML = '';
    legendEl.innerHTML = '<p class="hint">まだ学習記録がありません</p>';
    return;
  }

  // SVG 円グラフ
  const cx = 95, cy = 95, r = 85;
  let angle = -Math.PI / 2; // 12時から
  let paths = '';
  entries.forEach(([, v], i) => {
    const frac = v / total;
    const a2 = angle + frac * Math.PI * 2;
    const large = frac > 0.5 ? 1 : 0;
    const x1 = cx + r * Math.cos(angle), y1 = cy + r * Math.sin(angle);
    const x2 = cx + r * Math.cos(a2), y2 = cy + r * Math.sin(a2);
    const color = PIE_COLORS[i % PIE_COLORS.length];
    if (frac >= 0.9999) {
      // 全円
      paths += `<circle cx="${cx}" cy="${cy}" r="${r}" fill="${color}"></circle>`;
    } else {
      paths += `<path d="M ${cx} ${cy} L ${x1.toFixed(2)} ${y1.toFixed(2)} A ${r} ${r} 0 ${large} 1 ${x2.toFixed(2)} ${y2.toFixed(2)} Z" fill="${color}"></path>`;
    }
    angle = a2;
  });
  // 中央に合計時間
  const totalH = Math.floor(total / 3600);
  const totalM = Math.floor((total % 3600) / 60);
  chartEl.innerHTML =
    `<svg viewBox="0 0 190 190" role="img" aria-label="科目別の時間配分">
       ${paths}
       <circle cx="${cx}" cy="${cy}" r="48" fill="rgba(0,0,0,0.35)"></circle>
       <text x="${cx}" y="${cy - 4}" text-anchor="middle" fill="#fff" font-size="15" font-weight="700">${totalH}h${totalM}m</text>
       <text x="${cx}" y="${cy + 14}" text-anchor="middle" fill="#c9d2ff" font-size="10">合計</text>
     </svg>`;

  // 凡例
  legendEl.innerHTML = '';
  entries.forEach(([name, v], i) => {
    const pct = Math.round((v / total) * 100);
    const h = Math.floor(v / 3600);
    const m = Math.floor((v % 3600) / 60);
    const item = document.createElement('div');
    item.className = 'pie-legend-item';
    item.innerHTML = `<span class="pie-dot" style="background:${PIE_COLORS[i % PIE_COLORS.length]}"></span>
      <span class="pie-legend-label"></span>
      <span class="pie-legend-value">${h}h${m}m（${pct}%）</span>`;
    item.querySelector('.pie-legend-label').textContent = name;
    legendEl.appendChild(item);
  });
}

/* ============================================================
   学習統計（ストリーク / ヒートマップ / 今日の予定）
   ============================================================ */
const STREAK_KEY = 'dashboard_streak';

function loadStreak() {
  try {
    const raw = localStorage.getItem(STREAK_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch (e) {
    return {};
  }
}

function saveStreak() {
  try {
    localStorage.setItem(STREAK_KEY, JSON.stringify(streak));
  } catch (e) { /* 無視 */ }
}

let streak = loadStreak(); // { current: n, best: n, lastStudyDate: "YYYY-MM-DD" }

// 学習記録が指定日に存在するか（ポモドーロ自動記録・手動計測の両方を含む）
function hasStudyOnDate(key) {
  return (study.byDate[key] || 0) > 0;
}

function updateStreak() {
  const today = todayKey();
  const yesterday = todayKey(new Date(Date.now() - 86400000));
  const studiedToday = hasStudyOnDate(today);
  const studiedYesterday = hasStudyOnDate(yesterday);

  if (!streak.lastStudyDate) {
    // 初回
    streak.current = studiedToday ? 1 : 0;
  } else if (streak.lastStudyDate === today) {
    // 今日すでに記録済み（そのまま）
  } else if (streak.lastStudyDate === yesterday) {
    // 昨日勉強した → 今日も勉強していれば継続
    streak.current = studiedToday ? streak.current + 1 : streak.current;
  } else {
    // ブランクあり → リセット
    streak.current = studiedToday ? 1 : 0;
  }
  if (studiedToday) streak.lastStudyDate = today;
  streak.best = Math.max(streak.best || 0, streak.current);
  saveStreak();
  renderStats();
}

function renderStats() {
  // 統計カード（連続日数 / 累計 / 最高 / 週平均）
  const elStreak = $('#statStreak');
  if (elStreak) elStreak.textContent = `${streak.current}日`;

  const totalSec = Object.values(study.byDate).reduce((a, b) => a + (b || 0), 0);
  const elTotal = $('#statTotal');
  if (elTotal) elTotal.textContent = fmtH(totalSec);

  const bestSec = Object.values(study.byDate).reduce((a, b) => Math.max(a, b || 0), 0);
  const elBest = $('#statBest');
  if (elBest) elBest.textContent = fmtH(bestSec);

  let weekSec = 0;
  for (let i = 0; i < 7; i++) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    weekSec += study.byDate[todayKey(d)] || 0;
  }
  const elAvg = $('#statAvg');
  if (elAvg) elAvg.textContent = fmtH(Math.round(weekSec / 7));
}

// 秒を「h」または「m」表記にするヘルパー
function fmtH(sec) {
  const h = sec / 3600;
  if (h >= 10) return Math.round(h) + 'h';
  if (h >= 1) return h.toFixed(1) + 'h';
  return Math.round(sec / 60) + 'm';
}

// GitHub風ヒートマップ（過去52週 = 1年間）
function renderHeatmap() {
  const wrap = $('#heatmap');
  if (!wrap) return;
  const now = new Date();
  const weeks = 52;
  // 52週前の日曜日を開始日にする
  const start = new Date(now);
  start.setDate(now.getDate() - now.getDay() - (weeks - 1) * 7);

  const days = [];
  for (let i = 0; i < weeks * 7; i++) {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    days.push({
      key: todayKey(d),
      date: d,
      sec: study.byDate[todayKey(d)] || 0,
    });
  }

  const maxSec = Math.max(1, ...days.map((x) => x.sec));
  const todayStr = todayKey();

  let html = '';
  for (const day of days) {
    const sec = day.sec;
    const level = sec === 0 ? 0 : Math.min(4, Math.max(1, Math.ceil((sec / maxSec) * 4)));
    const isToday = day.key === todayStr;
    const dateStr = `${day.date.getFullYear()}/${day.date.getMonth() + 1}/${day.date.getDate()}`;
    const title = `${dateStr}: ${sec > 0 ? fmtHMS(sec) + '（' + Math.floor(sec / 60) + '分）' : '学習記録なし'}`;
    html += `<div class="heat-cell lv${level}${isToday ? ' today-cell' : ''}" title="${title}"></div>`;
  }
  wrap.innerHTML = html;
}

// 今日の予定（今日のカレンダー予定 + 期限切れ・今日締切のToDo）
function renderTodaySchedule() {
  const eventsEl = $('#todayEvents');
  const todosEl = $('#todayTodos');
  const today = todayKey();

  // 今日の予定（カレンダーイベント）
  const todayEvents = events[today] || [];
  if (eventsEl) {
    if (todayEvents.length === 0) {
      eventsEl.innerHTML = '<p class="hint">今日の予定はありません</p>';
    } else {
      eventsEl.innerHTML = '';
      todayEvents.forEach((ev) => {
        const div = document.createElement('div');
        div.className = 'today-item';
        const time = ev.start ? ev.start + (ev.end ? ' - ' + ev.end : '') : '';
        div.innerHTML = '<span class="today-text"></span>';
        if (time) div.insertAdjacentHTML('beforeend', `<span class="today-time">${time}</span>`);
        div.querySelector('.today-text').textContent = ev.text;
        eventsEl.appendChild(div);
      });
    }
  }

  // 期限切れ・今日締切の未完了ToDo
  const dueTodos = todos.filter((t) => !t.done && t.due && t.due <= today);
  dueTodos.sort((a, b) => (a.due < b.due ? -1 : 1));
  if (todosEl) {
    if (dueTodos.length === 0) {
      todosEl.innerHTML = '<p class="hint">期限が近い ToDo はありません</p>';
    } else {
      todosEl.innerHTML = '';
      dueTodos.forEach((t) => {
        const div = document.createElement('div');
        div.className = 'today-item' + (t.due < today ? ' overdue' : '');
        const label = t.due < today ? '期限切れ' : '今日締切';
        div.innerHTML = '<span class="today-text"></span>';
        div.insertAdjacentHTML('beforeend', `<span class="today-due">${label}（${t.due.replace(/-/g, '/')}）</span>`);
        div.querySelector('.today-text').textContent = t.text;
        todosEl.appendChild(div);
      });
    }
  }

  // 今日の復習
  const revEl = $('#todayReviews');
  if (revEl) {
    const due = reviews.filter((r) => !r.done && r.nextDate && r.nextDate <= today);
    if (due.length === 0) {
      revEl.innerHTML = '<p class="hint">今日の復習はありません</p>';
    } else {
      revEl.innerHTML = '';
      due.forEach((r) => {
        const div = document.createElement('div');
        div.className = 'today-item' + (r.nextDate < today ? ' overdue' : '');
        div.innerHTML = '<span class="today-text"></span>';
        div.insertAdjacentHTML('beforeend', `<span class="review-subject-tag">${escapeHtml(r.subject || '未分類')}</span>`);
        div.querySelector('.today-text').textContent = r.text;
        revEl.appendChild(div);
      });
    }
  }

  // 今日の習慣
  const habEl = $('#todayHabits');
  if (habEl) {
    const active = habits.filter((h) => !h.archived);
    if (active.length === 0) {
      habEl.innerHTML = '<p class="hint">習慣が登録されていません</p>';
    } else {
      habEl.innerHTML = '';
      active.forEach((h) => {
        const doneToday = !!(h.history && h.history[today]);
        const div = document.createElement('div');
        div.className = 'today-item' + (doneToday ? '' : ' overdue');
        div.innerHTML = '<span class="today-text"></span>';
        div.insertAdjacentHTML('beforeend', `<span class="today-due">${doneToday ? '✅ 達成' : '⬜ 未達成'}</span>`);
        div.querySelector('.today-text').textContent = h.name;
        habEl.appendChild(div);
      });
    }

    // 復習期限のフラッシュカード（連動②）
    if (typeof renderTodayCards === 'function') renderTodayCards();
  }
}

// 簡易HTMLエスケープ
function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function initStats() {
  updateStreak();
  renderHeatmap();
  renderStats();
  renderTodaySchedule();
  renderPieChart();
  // 1分ごとに自動更新（学習時間変動を反映）
  setInterval(() => {
    updateStreak();
    renderHeatmap();
    renderStats();
    renderTodaySchedule();
    renderPieChart();
  }, 60000);
}

/* ============================================================
   データのバックアップ / 復元（JSON一括エクスポート/インポート）
   ============================================================ */
const BACKUP_VERSION = 1;

function collectAllData() {
  return {
    app: 'learning_dashboard',
    version: BACKUP_VERSION,
    exportedAt: new Date().toISOString(),
    settings,
    todos,
    study,
    events,
    streak,
    goals,
    subjects,
    reviews,
    habits,
    flashcards,
    goalMin: goals.daily, // 旧形式との互換
  };
}

function initBackup() {
  // エクスポート
  $('#backupExport').addEventListener('click', () => {
    const data = collectAllData();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `dashboard_backup_${todayKey()}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
  });

  // インポート
  $('#backupImportBtn').addEventListener('click', () => {
    $('#backupImport').click();
  });
  $('#backupImport').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        if (!data || typeof data !== 'object') throw new Error('形式不正');
        // フラッシュカードPWAの書き出しJSONなら、カードとして取り込む
        if (data.app === 'offline-flashcards' || (Array.isArray(data.decks) && !data.study && !data.todos)) {
          const n = importFlashcardsData(data);
          if (n > 0) alert(`フラッシュカードとして ${n} 枚を取り込みました。`);
          return;
        }
        if (data.app && data.app !== 'learning_dashboard') throw new Error('対象外のファイル');
        if (confirm('現在のデータをすべてバックアップファイルの内容で置き換えます。よろしいですか？')) {
          applyBackupData(data);
          alert('復元が完了しました。画面を再読み込みします。');
          location.reload();
        }
      } catch (err) {
        alert('バックアップファイルを読み込めませんでした: ' + err.message);
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  });
}

function applyBackupData(data) {
  // 各ストレージを上書き（存在するキーのみ）
  if (data.settings && typeof data.settings === 'object') {
    settings = { ...DEFAULT_SETTINGS, ...data.settings };
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  }
  if (Array.isArray(data.todos)) {
    todos = data.todos;
    localStorage.setItem(TODO_KEY, JSON.stringify(todos));
  }
  if (data.study && typeof data.study === 'object') {
    study = {
      byDate: data.study.byDate || {},
      bySubject: data.study.bySubject || {},
      sessions: Array.isArray(data.study.sessions) ? data.study.sessions : [],
    };
    localStorage.setItem(STUDY_KEY, JSON.stringify(study));
  }
  if (data.events && typeof data.events === 'object') {
    events = data.events;
    localStorage.setItem(EVENTS_KEY, JSON.stringify(events));
  }
  if (data.streak && typeof data.streak === 'object') {
    streak = {
      current: data.streak.current || 0,
      best: data.streak.best || 0,
      lastStudyDate: data.streak.lastStudyDate || null,
    };
    localStorage.setItem(STREAK_KEY, JSON.stringify(streak));
  }
  // 目標（新形式 / 旧形式の両対応）
  if (data.goals && typeof data.goals === 'object') {
    goals = {
      daily: Number(data.goals.daily) || 0,
      weekly: Number(data.goals.weekly) || 0,
      monthly: Number(data.goals.monthly) || 0,
    };
  } else if (data.goalMin !== undefined) {
    goals.daily = Number(data.goalMin) || 0;
  }
  localStorage.setItem(GOALS_KEY, JSON.stringify(goals));
  // 科目
  if (Array.isArray(data.subjects) && data.subjects.length) {
    subjects = data.subjects;
    localStorage.setItem(SUBJECTS_KEY, JSON.stringify(subjects));
  }
  // 復習
  if (Array.isArray(data.reviews)) {
    reviews = data.reviews;
    localStorage.setItem(REVIEWS_KEY, JSON.stringify(reviews));
  }
  // 習慣
  if (Array.isArray(data.habits)) {
    habits = data.habits;
    localStorage.setItem(HABITS_KEY, JSON.stringify(habits));
  }
  // フラッシュカード
  if (data.flashcards && typeof data.flashcards === 'object' && Array.isArray(data.flashcards.decks)) {
    flashcards = data.flashcards;
    localStorage.setItem(CARDS_KEY, JSON.stringify(flashcards));
  }
}

/* ============================================================
   キーボードショートカット
   - スペース / P: ポモドーロ 開始・一時停止
   - ESC: 集中モードを解除
   ============================================================ */
function initShortcuts() {
  document.addEventListener('keydown', (e) => {
    // 入力欄にフォーカス中のときは無効
    const tag = (e.target.tagName || '').toLowerCase();
    if (tag === 'input' || tag === 'textarea' || tag === 'select' || e.target.isContentEditable) return;

    // ESC: 集中モード解除
    if (e.key === 'Escape' && document.body.classList.contains('focus-mode')) {
      document.body.classList.remove('focus-mode');
      return;
    }

    // フラッシュカード学習中のショートカット
    const inCardStudy = typeof fcStudy !== 'undefined' && !!fcStudy.deckId
      && !$('#cardStudy').classList.contains('hidden')
      && $('#sessionDone').classList.contains('hidden');
    if (inCardStudy) {
      if (e.key === 'Escape') { e.preventDefault(); exitStudy(); return; }
      if (e.code === 'Space' || e.key === 'Enter') {
        e.preventDefault();
        if (!fcStudy.flipped) flipCard(); else gradeCard('good');
        return;
      }
      if (fcStudy.flipped) {
        if (e.key === '1' || e.key === 'ArrowLeft' || e.key === 'f' || e.key === 'F') { e.preventDefault(); gradeCard('again'); return; }
        if (e.key === '2' || e.key === 'ArrowRight' || e.key === 'j' || e.key === 'J') { e.preventDefault(); gradeCard('good'); return; }
        if (e.key === '3' || e.key === 'ArrowUp') { e.preventDefault(); gradeCard('easy'); return; }
      }
      return;
    }

    if (e.code === 'Space' || e.key === 'p' || e.key === 'P') {
      e.preventDefault();
      $('#pomodoroStart').click();
    }
  });
}

/* ============================================================
   復習リマインダー（間隔反復 / 忘却曲線）
   ============================================================ */
const REVIEWS_KEY = 'dashboard_reviews';
const REVIEW_INTERVALS = [1, 3, 7, 14]; // 学習日からの経過日数

let reviews = loadReviews();

function loadReviews() {
  try {
    const raw = localStorage.getItem(REVIEWS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    return [];
  }
}

function saveReviews() {
  try {
    localStorage.setItem(REVIEWS_KEY, JSON.stringify(reviews));
  } catch (e) { /* 無視 */ }
}

// 経過日数を加算した日付キーを返す
function dateKeyPlus(baseKey, days) {
  const d = new Date(baseKey + 'T00:00:00');
  d.setDate(d.getDate() + days);
  return todayKey(d);
}

function addReviewItem(text, subject, baseDate) {
  const base = baseDate || todayKey();
  reviews.unshift({
    id: Date.now() + Math.random(),
    text: text.trim(),
    subject: subject || '未分類',
    createdDate: base,
    stage: 0,
    nextDate: dateKeyPlus(base, REVIEW_INTERVALS[0]),
    done: false,
  });
}

function addReviewFromMemo(memo, subject) {
  addReviewItem(memo, subject, todayKey());
  saveReviews();
  renderReviews();
  renderTodaySchedule();
}

function renderReviews() {
  const today = todayKey();
  const todayEl = $('#reviewToday');
  const upEl = $('#reviewUpcoming');
  const allEl = $('#reviewAll');
  if (!todayEl) return;

  const dueToday = reviews.filter((r) => !r.done && r.nextDate && r.nextDate <= today)
    .sort((a, b) => (a.nextDate < b.nextDate ? -1 : 1));
  const upcoming = reviews.filter((r) => !r.done && r.nextDate && r.nextDate > today)
    .sort((a, b) => (a.nextDate < b.nextDate ? -1 : 1));

  const makeRow = (r, isDue) => {
    const div = document.createElement('div');
    div.className = 'review-item' + (isDue && r.nextDate <= today ? ' due-now' : '') + (r.done ? ' done' : '');
    const info = document.createElement('div');
    info.style.flex = '1';
    info.innerHTML = '<div class="review-text"></div>';
    info.querySelector('.review-text').textContent = r.text;
    const meta = document.createElement('div');
    meta.className = 'review-meta';
    const stageNo = Math.min(r.stage + 1, REVIEW_INTERVALS.length);
    meta.textContent = `復習 ${stageNo}/${REVIEW_INTERVALS.length}・次回 ${r.nextDate ? r.nextDate.replace(/-/g, '/') : '—'}`;
    info.appendChild(meta);

    const tag = document.createElement('span');
    tag.className = 'review-subject-tag';
    tag.textContent = r.subject || '未分類';

    div.appendChild(tag);
    div.appendChild(info);

    if (!r.done) {
      const doBtn = document.createElement('button');
      doBtn.className = 'review-do-btn';
      doBtn.textContent = '✔ 復習した';
      doBtn.addEventListener('click', () => completeReview(r.id));
      div.appendChild(doBtn);

      // フラッシュカード化（連動③）
      const cardBtn = document.createElement('button');
      cardBtn.className = 'review-do-btn';
      cardBtn.textContent = '🃏 カード化';
      cardBtn.title = 'フラッシュカードとして登録';
      cardBtn.addEventListener('click', () => reviewToCard(r));
      div.appendChild(cardBtn);
    }

    const del = document.createElement('button');
    del.className = 'todo-delete';
    del.textContent = '✕';
    del.title = '削除';
    del.addEventListener('click', () => {
      reviews = reviews.filter((x) => x.id !== r.id);
      saveReviews();
      renderReviews();
      renderTodaySchedule();
    });
    div.appendChild(del);
    return div;
  };

  todayEl.innerHTML = '';
  if (dueToday.length === 0) {
    todayEl.innerHTML = '<p class="hint">今日の復習はありません</p>';
  } else {
    dueToday.forEach((r) => todayEl.appendChild(makeRow(r, true)));
  }

  upEl.innerHTML = '';
  if (upcoming.length === 0) {
    upEl.innerHTML = '<p class="hint">予定はありません</p>';
  } else {
    upcoming.slice(0, 7).forEach((r) => upEl.appendChild(makeRow(r, false)));
  }

  allEl.innerHTML = '';
  if (reviews.length === 0) {
    allEl.innerHTML = '<p class="hint">項目がありません</p>';
  } else {
    reviews.forEach((r) => allEl.appendChild(makeRow(r, false)));
  }
}

// 復習完了 → 次の間隔へ進める（最後まで終えたら完了）
function completeReview(id) {
  const r = reviews.find((x) => x.id === id);
  if (!r) return;
  r.stage++;
  if (r.stage >= REVIEW_INTERVALS.length) {
    r.done = true;
    r.nextDate = null;
  } else {
    r.nextDate = dateKeyPlus(todayKey(), REVIEW_INTERVALS[r.stage]);
  }
  saveReviews();
  renderReviews();
  renderTodaySchedule();
}

function initReviews() {
  if (!$('#reviewAdd')) return;
  $('#reviewAdd').addEventListener('click', () => {
    const inp = $('#reviewInput');
    const text = inp.value.trim();
    if (!text) return;
    addReviewItem(text, $('#reviewSubject').value, todayKey());
    saveReviews();
    inp.value = '';
    renderReviews();
    renderTodaySchedule();
  });
  $('#reviewInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('#reviewAdd').click(); });
  $('#reviewClearDone').addEventListener('click', () => {
    reviews = reviews.filter((r) => !r.done);
    saveReviews();
    renderReviews();
    renderTodaySchedule();
  });

  // 起動時に今日の復習があれば通知
  const dueCount = reviews.filter((r) => !r.done && r.nextDate && r.nextDate <= todayKey()).length;
  if (dueCount > 0) {
    setTimeout(() => notify('🔁 今日の復習があります', `${dueCount} 件の復習が待っています。`), 3000);
  }

  renderReviews();
}

/* ============================================================
   習慣トラッカー（繰り返しタスク）
   ============================================================ */
const HABITS_KEY = 'dashboard_habits';
let habits = loadHabits();

function loadHabits() {
  try {
    const raw = localStorage.getItem(HABITS_KEY);
    const arr = raw ? JSON.parse(raw) : [];
    return (Array.isArray(arr) ? arr : []).map((h) => ({ history: {}, archived: false, ...h }));
  } catch (e) {
    return [];
  }
}

function saveHabits() {
  try {
    localStorage.setItem(HABITS_KEY, JSON.stringify(habits));
  } catch (e) { /* 無視 */ }
}

// 今日を起点とした連続達成日数
function habitStreak(h) {
  let n = 0;
  const d = new Date();
  if (!h.history[todayKey(d)]) d.setDate(d.getDate() - 1);
  while (h.history[todayKey(d)]) {
    n++;
    d.setDate(d.getDate() - 1);
  }
  return n;
}

function renderHabits() {
  const todayEl = $('#habitToday');
  const listEl = $('#habitList');
  if (!todayEl) return;
  const today = todayKey();
  const active = habits.filter((h) => !h.archived);

  todayEl.innerHTML = '';
  if (active.length === 0) {
    todayEl.innerHTML = '<p class="hint">習慣が登録されていません</p>';
  } else {
    active.forEach((h) => {
      const row = document.createElement('label');
      row.className = 'habit-check-row' + (h.history[today] ? ' checked' : '');
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.checked = !!h.history[today];
      cb.addEventListener('change', () => {
        if (cb.checked) h.history[today] = true;
        else delete h.history[today];
        saveHabits();
        renderHabits();
        renderTodaySchedule();
      });
      const name = document.createElement('span');
      name.textContent = h.name;
      name.style.flex = '1';
      const streak = document.createElement('span');
      streak.className = 'habit-item-streak';
      streak.textContent = `🔥 ${habitStreak(h)}日`;
      row.appendChild(cb);
      row.appendChild(name);
      row.appendChild(streak);
      todayEl.appendChild(row);
    });
  }

  listEl.innerHTML = '';
  habits.forEach((h) => {
    const card = document.createElement('div');
    card.className = 'habit-item';
    const head = document.createElement('div');
    head.className = 'habit-item-head';
    const nm = document.createElement('span');
    nm.className = 'habit-item-name';
    nm.textContent = h.name + (h.archived ? '（アーカイブ）' : '');
    const st = document.createElement('span');
    st.className = 'habit-item-streak';
    st.textContent = `🔥 ${habitStreak(h)}日`;
    const del = document.createElement('button');
    del.className = 'habit-edit-btn';
    del.textContent = '✕';
    del.title = '削除';
    del.addEventListener('click', () => {
      if (confirm(`「${h.name}」を削除しますか？`)) {
        habits = habits.filter((x) => x.id !== h.id);
        saveHabits();
        renderHabits();
        renderTodaySchedule();
      }
    });
    head.appendChild(nm);
    head.appendChild(st);
    head.appendChild(del);

    const grid = document.createElement('div');
    grid.className = 'habit-grid';
    for (let i = 27; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const k = todayKey(d);
      const cell = document.createElement('span');
      cell.className = 'habit-cell' + (h.history[k] ? ' on' : '');
      cell.title = `${k.replace(/-/g, '/')}: ${h.history[k] ? '達成' : '未達成'}`;
      grid.appendChild(cell);
    }

    card.appendChild(head);
    card.appendChild(grid);
    listEl.appendChild(card);
  });
}

function initHabits() {
  if (!$('#habitAdd')) return;
  $('#habitAdd').addEventListener('click', () => {
    const inp = $('#habitInput');
    const name = inp.value.trim();
    if (!name) return;
    habits.push({ id: Date.now() + Math.random(), name, history: {}, archived: false, createdAt: Date.now() });
    saveHabits();
    inp.value = '';
    renderHabits();
    renderTodaySchedule();
  });
  $('#habitInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('#habitAdd').click(); });
  renderHabits();
}

/* ============================================================
   月間 / 年間レポート（＋CSV / PDF出力）
   ============================================================ */
function renderReports() {
  const yearSel = $('#reportYear');
  const monthSel = $('#reportMonth');
  if (!yearSel || !monthSel) return;

  // 年の選択肢（記録のある年 + 今年）
  const years = new Set([new Date().getFullYear()]);
  Object.keys(study.byDate).forEach((k) => years.add(Number(k.slice(0, 4))));
  const yearArr = [...years].sort((a, b) => b - a);
  const curY = yearSel.value ? Number(yearSel.value) : yearArr[0];
  yearSel.innerHTML = '';
  yearArr.forEach((y) => {
    const o = document.createElement('option');
    o.value = y;
    o.textContent = y;
    if (y === curY) o.selected = true;
    yearSel.appendChild(o);
  });

  // 月の選択肢（1-12）
  const curM = Number(monthSel.value) || (new Date().getMonth() + 1);
  monthSel.innerHTML = '';
  for (let m = 1; m <= 12; m++) {
    const o = document.createElement('option');
    o.value = m;
    o.textContent = m + '月';
    if (m === curM) o.selected = true;
    monthSel.appendChild(o);
  }

  const year = Number(yearSel.value) || new Date().getFullYear();
  const month = Number(monthSel.value) || (new Date().getMonth() + 1);
  const yearLabel = $('#reportYearLabel');
  if (yearLabel) yearLabel.textContent = year;

  // 月間の日別
  const daysInMonth = new Date(year, month, 0).getDate();
  let monthTotalSec = 0;
  const dayVals = [];
  for (let d = 1; d <= daysInMonth; d++) {
    const k = `${year}-${pad2(month)}-${pad2(d)}`;
    const sec = study.byDate[k] || 0;
    monthTotalSec += sec;
    dayVals.push({ day: d, sec });
  }
  const maxDay = Math.max(60, ...dayVals.map((x) => x.sec));
  let mHtml = '';
  const todayStr = todayKey();
  dayVals.forEach((x) => {
    const pct = Math.max(2, Math.round((x.sec / maxDay) * 100));
    const k = `${year}-${pad2(month)}-${pad2(x.day)}`;
    const isToday = k === todayStr;
    const label = x.day % 5 === 0 ? x.day : '';
    mHtml += `<div class="month-bar-col">
      <div class="month-bar${isToday ? ' today' : ''}" style="height:${pct}%" title="${x.day}日: ${fmtHMS(x.sec)}"></div>
      <div class="month-bar-label">${label}</div>
    </div>`;
  });
  $('#reportMonthChart').innerHTML = mHtml;

  // 年間の月別
  let yearTotalSec = 0;
  const monthVals = [];
  for (let m = 1; m <= 12; m++) {
    let s = 0;
    for (let d = 1; d <= 31; d++) {
      const k = `${year}-${pad2(m)}-${pad2(d)}`;
      s += study.byDate[k] || 0;
    }
    yearTotalSec += s;
    monthVals.push({ m, sec: s });
  }
  const maxMonth = Math.max(3600, ...monthVals.map((x) => x.sec));
  let yHtml = '';
  const curMonthNow = new Date().getFullYear() === year ? (new Date().getMonth() + 1) : -1;
  monthVals.forEach((x) => {
    const pct = Math.max(2, Math.round((x.sec / maxMonth) * 100));
    const isCur = x.m === curMonthNow;
    yHtml += `<div class="year-bar-col">
      <div class="year-bar${isCur ? ' current' : ''}" style="height:${pct}%" title="${x.m}月: ${fmtHMS(x.sec)}"></div>
      <div class="year-bar-label">${x.m}</div>
    </div>`;
  });
  $('#reportYearChart').innerHTML = yHtml;

  // サマリー
  const monthDays = dayVals.filter((x) => x.sec > 0).length;
  const monthAvg = monthDays > 0 ? Math.round(monthTotalSec / monthDays) : 0;
  $('#reportSummary').innerHTML = `
    <div class="stat-card"><span class="stat-value">${fmtHMS(monthTotalSec)}</span><span class="stat-label">${year}年${month}月の合計</span></div>
    <div class="stat-card"><span class="stat-value">${monthDays}日</span><span class="stat-label">学習した日数</span></div>
    <div class="stat-card"><span class="stat-value">${fmtHMS(monthAvg)}</span><span class="stat-label">学習日の平均</span></div>
    <div class="stat-card"><span class="stat-value">${fmtHMS(yearTotalSec)}</span><span class="stat-label">${year}年の合計</span></div>`;

  return { year, month, monthTotalSec, yearTotalSec, dayVals, monthVals };
}

function initReports() {
  if (!$('#reportYear') || !$('#reportMonth')) return;
  $('#reportYear').addEventListener('change', renderReports);
  $('#reportMonth').addEventListener('change', renderReports);

  // CSV出力
  const csvBtn = $('#reportCsvBtn');
  if (csvBtn) csvBtn.addEventListener('click', () => {
    const info = renderReports();
    const lines = [];
    lines.push(`学習レポート,${info.year}年${info.month}月`);
    lines.push('');
    lines.push('【日別】');
    lines.push('日付,学習時間(秒),時間(hh:mm:ss),科目内訳');
    info.dayVals.forEach((x) => {
      const k = `${info.year}-${pad2(info.month)}-${pad2(x.day)}`;
      const subs = study.sessions.filter((s) => s.date === k);
      const breakdown = {};
      subs.forEach((s) => { const sj = s.subject || '未分類'; breakdown[sj] = (breakdown[sj] || 0) + s.sec; });
      const bd = Object.entries(breakdown).map(([n, v]) => `${n}:${fmtHMS(v)}`).join(' / ');
      lines.push(`${k},${x.sec},${fmtHMS(x.sec)},"${bd}"`);
    });
    lines.push('');
    lines.push('【月別（年間）】');
    lines.push('月,学習時間(秒),時間(hh:mm:ss)');
    info.monthVals.forEach((x) => lines.push(`${x.m}月,${x.sec},${fmtHMS(x.sec)}`));
    lines.push('');
    lines.push('【科目別（全期間）】');
    lines.push('科目,学習時間(秒),時間(hh:mm:ss)');
    Object.entries(study.bySubject).sort((a, b) => b[1] - a[1]).forEach(([n, v]) => {
      lines.push(`"${n}",${v},${fmtHMS(v)}`);
    });

    const blob = new Blob(['\uFEFF' + lines.join('\n')], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `study_report_${info.year}-${pad2(info.month)}.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
  });

  // PDF出力（印刷ダイアログ経由。学習記録タブのみ印刷されるようCSS調整済み）
  const pdfBtn = $('#reportPdfBtn');
  if (pdfBtn) pdfBtn.addEventListener('click', () => {
    showTab('study');
    setTimeout(() => window.print(), 200);
  });

  renderReports();
}

/* ============================================================
   環境音プレーヤー（Web Audio API で生成 / 外部ファイル不要）
   ============================================================ */
const AMBIENT_PRESETS = [
  { key: 'rain',   label: '🌧 雨',       type: 'pink' },
  { key: 'cafe',   label: '☕ カフェ',   type: 'brown' },
  { key: 'noise',  label: '🔊 ホワイト', type: 'white' },
  { key: 'waves',  label: '🌊 波',       type: 'brown' },
  { key: 'forest', label: '🌲 森',       type: 'pink' },
];

const ambientState = { ctx: null, nodes: null, current: null };

function ensureAudioCtx() {
  const Ctx = window.AudioContext || window.webkitAudioContext;
  if (!Ctx) return null;
  if (!ambientState.ctx) ambientState.ctx = new Ctx();
  if (ambientState.ctx.state === 'suspended') ambientState.ctx.resume();
  return ambientState.ctx;
}

// ノイズバッファ生成（white / pink / brown）
function makeNoiseBuffer(ctx, type) {
  const len = 2 * ctx.sampleRate;
  const buf = ctx.createBuffer(1, len, ctx.sampleRate);
  const data = buf.getChannelData(0);
  let last = 0;
  for (let i = 0; i < len; i++) {
    const white = Math.random() * 2 - 1;
    if (type === 'brown') {
      last = (last + 0.02 * white) / 1.02;
      data[i] = last * 3.5;
    } else if (type === 'pink') {
      last = 0.98 * last + 0.02 * white;
      data[i] = last * 3.5 + white * 0.3;
    } else {
      data[i] = white * 0.6;
    }
  }
  return buf;
}

function stopAmbient() {
  if (ambientState.nodes) {
    try { ambientState.nodes.source.stop(); } catch (e) { /* 無視 */ }
    try { ambientState.nodes.source.disconnect(); } catch (e) { /* 無視 */ }
    ambientState.nodes = null;
  }
  ambientState.current = null;
  const now = $('#ambientNow');
  if (now) now.textContent = 'なし';
  $$('.ambient-btn').forEach((b) => b.classList.remove('active'));
}

function setAmbientVolume(vol) {
  if (ambientState.nodes && ambientState.nodes.gain) {
    ambientState.nodes.gain.gain.value = (Number(vol) || 0) / 100 * 0.5;
  }
}

function startAmbient(key) {
  const ctx = ensureAudioCtx();
  if (!ctx) { alert('このブラウザは音声合成に対応していません。'); return; }
  const preset = AMBIENT_PRESETS.find((p) => p.key === key);
  if (!preset) return;
  stopAmbient();

  const src = ctx.createBufferSource();
  src.buffer = makeNoiseBuffer(ctx, preset.type);
  src.loop = true;

  const gain = ctx.createGain();
  gain.gain.value = (settings.ambientVolume || 40) / 100 * 0.5;

  const filter = ctx.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.value = preset.type === 'white' ? 8000 : (preset.key === 'rain' ? 4000 : 1200);

  src.connect(filter).connect(gain).connect(ctx.destination);
  src.start();

  ambientState.nodes = { source: src, gain, filter };
  ambientState.current = key;

  const now = $('#ambientNow');
  if (now) now.textContent = preset.label.replace(/^\S+\s/, '');
  $$('.ambient-btn').forEach((b) => b.classList.toggle('active', b.dataset.ambient === key));
}

function initAmbient() {
  const box = $('#ambientButtons');
  if (!box) return;
  box.innerHTML = '';
  AMBIENT_PRESETS.forEach((p) => {
    const btn = document.createElement('button');
    btn.className = 'ambient-btn';
    btn.dataset.ambient = p.key;
    btn.textContent = p.label;
    btn.addEventListener('click', () => {
      if (ambientState.current === p.key) stopAmbient();
      else startAmbient(p.key);
    });
    box.appendChild(btn);
  });
  const stopBtn = $('#ambientStop');
  if (stopBtn) stopBtn.addEventListener('click', stopAmbient);
  const av = $('#ambientVolume');
  if (av) {
    av.value = settings.ambientVolume || 40;
    $('#ambientVolumeLabel').textContent = (settings.ambientVolume || 40) + '%';
  }
}

/* ============================================================
   PWA（Service Worker 登録）
   - http(s) 配信時のみ有効（file:// では自動スキップ）
   ============================================================ */
function initPWA() {
  if (!('serviceWorker' in navigator)) return;
  if (location.protocol !== 'http:' && location.protocol !== 'https:') return;
  navigator.serviceWorker.register('sw.js').catch(() => { /* 無視 */ });
}

/* ============================================================
   フラッシュカード（忘却曲線SRS・学習ダッシュボードと連動）
   - データは localStorage（dashboard_flashcards）に保存
   - カード学習の時間は学習記録へ自動加算（デッキ名＝科目）
   - 復習期限カードは「今日の予定」に表示
   - 学習メモからカード作成、科目とデッキ名の同期に対応
   ============================================================ */
const CARDS_KEY = 'dashboard_flashcards';
const FC_LADDER = [0, 1, 3, 7, 14, 30, 60, 120, 240, 365, 730]; // 日
const FC_EASE_DEFAULT = 2.5;

let flashcards = loadFlashcards(); // { decks: [ { id, name, createdAt, cards: [...] } ] }

function loadFlashcards() {
  try {
    const raw = localStorage.getItem(CARDS_KEY);
    const d = raw ? JSON.parse(raw) : null;
    if (d && Array.isArray(d.decks)) return d;
  } catch (e) { /* 無視 */ }
  return { decks: [] };
}

function saveFlashcards() {
  try {
    localStorage.setItem(CARDS_KEY, JSON.stringify(flashcards));
  } catch (e) { /* 容量超過時は無視 */ }
}

function fcUid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

// ---- SRS（SM-2 ベースの軽量版） ----
function fcNewSrs(now) {
  return { box: 0, ease: FC_EASE_DEFAULT, interval: 0, due: (now || Date.now()), reps: 0, lapses: 0, streakOk: 0, lastGrade: null, lastAt: null };
}

function fcEnsure(card) {
  if (!card.srs || typeof card.srs !== 'object') card.srs = fcNewSrs(card.createdAt);
  const s = card.srs;
  if (typeof s.box !== 'number') s.box = 0;
  if (typeof s.ease !== 'number' || !isFinite(s.ease)) s.ease = FC_EASE_DEFAULT;
  if (typeof s.interval !== 'number') s.interval = 0;
  if (typeof s.due !== 'number') s.due = Date.now();
  if (typeof s.reps !== 'number') s.reps = 0;
  if (typeof s.lapses !== 'number') s.lapses = 0;
  if (typeof s.streakOk !== 'number') s.streakOk = 0;
  s.ease = Math.min(3.2, Math.max(1.3, s.ease));
  return s;
}

function fcIntervalFor(box, ease) {
  const i = Math.max(0, Math.min(FC_LADDER.length - 1, box));
  let days = FC_LADDER[i];
  if (i > 0) days = Math.max(1, Math.round(days * (ease / FC_EASE_DEFAULT)));
  return days;
}

// 採点を適用。戻り値の requeue は同セッション内での再出題位置
function fcApply(card, g, now) {
  now = now || Date.now();
  const s = fcEnsure(card);
  let requeue = 0;
  if (g === 'again') {
    s.lapses++; s.reps = 0; s.streakOk = 0; s.box = 0;
    s.ease = Math.max(1.3, s.ease - 0.2);
    s.interval = 10 / 1440; s.due = now + 10 * 60000; requeue = 3; // 約10分後
  } else if (g === 'easy') {
    s.reps++; s.streakOk++; s.ease = Math.min(3.2, s.ease + 0.15);
    s.box = Math.min(FC_LADDER.length - 1, s.box + 2);
    s.interval = fcIntervalFor(s.box, s.ease);
    s.due = now + Math.round(s.interval * 86400000);
  } else {
    s.reps++; s.streakOk++; s.ease = Math.min(3.0, s.ease + 0.05);
    s.box = Math.min(FC_LADDER.length - 1, s.box + 1);
    s.interval = fcIntervalFor(s.box, s.ease);
    s.due = now + Math.round(s.interval * 86400000);
  }
  s.lastGrade = g; s.lastAt = now;
  return { requeue };
}

function fcState(card) {
  const s = card.srs || {};
  const reps = s.reps || 0, box = s.box || 0, lapses = s.lapses || 0;
  const touched = !!s.lastAt || reps > 0 || box > 0 || lapses > 0 || (card.history && card.history.length > 0);
  if (!touched) return 'new';
  if (lapses >= 3 && box < 4) return 'leech';
  if (box >= 5) return 'mastered';
  return 'learning';
}

const FC_STATE_LABEL = { new: '新規', learning: '学習中', mastered: '覚えた', leech: '苦手' };

function fcIsDue(card, now) {
  return (card.srs ? (card.srs.due || 0) : 0) <= (now || Date.now());
}

// 次回復習の目安ラベル
function fcNextIntervalLabel(card, grade) {
  const s = fcEnsure(card);
  if (grade === 'again') return '約10分後';
  const box = grade === 'easy' ? s.box + 2 : s.box + 1;
  const ease = grade === 'easy' ? Math.min(3.2, s.ease + 0.15) : Math.min(3.0, s.ease + 0.05);
  const days = fcIntervalFor(box, ease);
  if (days <= 0) return '約10分後';
  if (days === 1) return '翌日';
  if (days < 30) return days + '日後';
  if (days < 365) return Math.round(days / 30) + 'か月後';
  return (days / 365).toFixed(1) + '年後';
}

// 配列をシャッフル（Fisher-Yates）
function shuffleArray(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

/* ---- フラッシュカード統計（日別正答率 / 日別枚数 / 忘却曲線） ---- */
// 対象デッキを返す（scope: 'all' or deckId）
function fcScopedDecks(scope) {
  if (!scope || scope === 'all') return flashcards.decks;
  const d = fcGetDeck(scope);
  return d ? [d] : [];
}

// 日別の集計を返す（古い順）: [{ key, good, again, total, rate }]
function fcDailySeries(days, scope) {
  const decks = fcScopedDecks(scope);
  const map = {};
  const out = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const k = todayKey(d);
    map[k] = { key: k, good: 0, again: 0, total: 0, rate: 0 };
    out.push(map[k]);
  }
  decks.forEach((deck) => {
    deck.cards.forEach((c) => {
      (c.history || []).forEach((h) => {
        const k = todayKey(new Date(h.t));
        if (map[k]) {
          map[k].total++;
          if (h.ok) map[k].good++; else map[k].again++;
        }
      });
    });
  });
  out.forEach((x) => { x.rate = x.total > 0 ? x.good / x.total : 0; });
  return out;
}

// 正答率の推移を折れ線で描画
function drawFcRateChart(canvas, series) {
  const ctx = fitCanvas(canvas);
  if (!ctx) return;
  const W = canvas.clientWidth, H = canvas.clientHeight;
  const padL = 36, padR = 12, padT = 14, padB = 26;
  const plotW = W - padL - padR, plotH = H - padT - padB;
  ctx.clearRect(0, 0, W, H);
  const css = getComputedStyle(document.body);
  const textDim = css.getPropertyValue('--text-dim').trim() || '#999';
  const accent = css.getPropertyValue('--accent').trim() || '#6c8cff';

  // グリッドとY軸（0/50/100%）
  ctx.strokeStyle = 'rgba(128,128,128,0.25)';
  ctx.fillStyle = textDim;
  ctx.font = '10px sans-serif';
  ctx.lineWidth = 1;
  [0, 0.5, 1].forEach((v) => {
    const y = padT + plotH * (1 - v);
    ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(W - padR, y); ctx.stroke();
    ctx.fillText(Math.round(v * 100) + '%', 6, y + 3);
  });

  const n = series.length;
  const xAt = (i) => padL + (n <= 1 ? plotW / 2 : (plotW * i) / (n - 1));
  const yAt = (r) => padT + plotH * (1 - r);

  // 目標80%ライン
  ctx.setLineDash([4, 4]);
  ctx.strokeStyle = 'rgba(80,220,160,0.6)';
  const y80 = yAt(0.8);
  ctx.beginPath(); ctx.moveTo(padL, y80); ctx.lineTo(W - padR, y80); ctx.stroke();
  ctx.setLineDash([]);

  // 折れ線（学習のあった日のみ点を打つ）
  ctx.strokeStyle = accent;
  ctx.lineWidth = 2;
  ctx.beginPath();
  let started = false;
  series.forEach((x, i) => {
    if (x.total === 0) return;
    const px = xAt(i), py = yAt(x.rate);
    if (!started) { ctx.moveTo(px, py); started = true; } else ctx.lineTo(px, py);
  });
  ctx.stroke();
  series.forEach((x, i) => {
    if (x.total === 0) return;
    ctx.fillStyle = accent;
    ctx.beginPath(); ctx.arc(xAt(i), yAt(x.rate), 3, 0, Math.PI * 2); ctx.fill();
  });

  // X軸ラベル（先頭・中間・末尾）
  ctx.fillStyle = textDim;
  [0, Math.floor((n - 1) / 2), n - 1].forEach((i) => {
    if (i < 0) return;
    const k = series[i].key.slice(5).replace('-', '/');
    const tw = ctx.measureText(k).width;
    let tx = xAt(i) - tw / 2;
    tx = Math.max(2, Math.min(W - tw - 2, tx));
    ctx.fillText(k, tx, H - 8);
  });
}

// 日別の学習枚数（積み上げ棒）を描画
function drawFcCountChart(canvas, series) {
  const ctx = fitCanvas(canvas);
  if (!ctx) return;
  const W = canvas.clientWidth, H = canvas.clientHeight;
  const padL = 30, padR = 12, padT = 14, padB = 26;
  const plotW = W - padL - padR, plotH = H - padT - padB;
  ctx.clearRect(0, 0, W, H);
  const css = getComputedStyle(document.body);
  const textDim = css.getPropertyValue('--text-dim').trim() || '#999';

  const maxTotal = Math.max(1, ...series.map((x) => x.total));
  // グリッド
  ctx.strokeStyle = 'rgba(128,128,128,0.25)';
  ctx.fillStyle = textDim;
  ctx.font = '10px sans-serif';
  ctx.beginPath(); ctx.moveTo(padL, padT); ctx.lineTo(padL, padT + plotH); ctx.lineTo(W - padR, padT + plotH); ctx.stroke();
  ctx.fillText(String(maxTotal), 4, padT + 8);
  ctx.fillText('0', 4, padT + plotH);

  const n = series.length;
  const slot = plotW / n;
  const bw = Math.max(2, Math.min(14, slot * 0.7));
  series.forEach((x, i) => {
    const cx = padL + slot * i + slot / 2;
    const x0 = cx - bw / 2;
    const hGood = (x.good / maxTotal) * plotH;
    const hAgain = (x.again / maxTotal) * plotH;
    // 覚えた（下・緑）
    ctx.fillStyle = '#50d4a0';
    ctx.fillRect(x0, padT + plotH - hGood, bw, hGood);
    // 覚えていない（上・赤）
    ctx.fillStyle = '#ff7b7b';
    ctx.fillRect(x0, padT + plotH - hGood - hAgain, bw, hAgain);
  });

  // X軸ラベル
  ctx.fillStyle = textDim;
  [0, Math.floor((n - 1) / 2), n - 1].forEach((i) => {
    if (i < 0) return;
    const k = series[i].key.slice(5).replace('-', '/');
    const tw = ctx.measureText(k).width;
    let tx = Math.max(2, Math.min(W - tw - 2, padL + slot * i + slot / 2 - tw / 2));
    ctx.fillText(k, tx, H - 8);
  });

  // 凡例
  ctx.fillStyle = '#50d4a0';
  ctx.fillRect(W - padR - 92, 4, 10, 10);
  ctx.fillStyle = textDim;
  ctx.fillText('覚えた', W - padR - 78, 13);
  ctx.fillStyle = '#ff7b7b';
  ctx.fillRect(W - padR - 40, 4, 10, 10);
  ctx.fillStyle = textDim;
  ctx.fillText('忘れ', W - padR - 26, 13);
}

// 忘却曲線（理論）を描画
function drawFcCurveChart(canvas) {
  const ctx = fitCanvas(canvas);
  if (!ctx) return;
  const W = canvas.clientWidth, H = canvas.clientHeight;
  const padL = 36, padR = 16, padT = 14, padB = 26;
  const plotW = W - padL - padR, plotH = H - padT - padB;
  ctx.clearRect(0, 0, W, H);
  const css = getComputedStyle(document.body);
  const textDim = css.getPropertyValue('--text-dim').trim() || '#999';

  // 軸
  ctx.strokeStyle = 'rgba(128,128,128,0.3)';
  ctx.fillStyle = textDim;
  ctx.font = '10px sans-serif';
  [0, 0.5, 1].forEach((v) => {
    const y = padT + plotH * (1 - v);
    ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(W - padR, y); ctx.stroke();
    ctx.fillText(Math.round(v * 100) + '%', 4, y + 3);
  });
  ctx.fillText('0日', padL - 6, H - 8);
  ctx.fillText('7日', padL + plotW * (7 / 30) - 8, H - 8);
  ctx.fillText('30日', W - padR - 16, H - 8);

  // 復習なしの忘却曲線: R = e^{-t/S} (S=3日)
  const curve = (t, S) => Math.exp(-t / S);
  const plot = (fn, S, color, dash) => {
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.setLineDash(dash || []);
    ctx.beginPath();
    for (let i = 0; i <= 100; i++) {
      const t = (30 * i) / 100;
      const r = fn(t, S);
      const x = padL + plotW * (t / 30);
      const y = padT + plotH * (1 - r);
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.stroke();
    ctx.setLineDash([]);
  };
  // 復習しない場合（急低下）
  plot(curve, 3, '#ff7b7b', [5, 4]);
  // 復習した場合（緩やか）
  plot(curve, 12, '#50d4a0', []);

  ctx.fillStyle = '#ff7b7b';
  ctx.fillText('─ 復習なし', padL + 6, padT + 12);
  ctx.fillStyle = '#50d4a0';
  ctx.fillText('─ 復習あり', padL + 6, padT + 26);
}

// canvas をDPIに合わせて調整し 2Dコンテキストを返す
function fitCanvas(canvas) {
  if (!canvas) return null;
  const dpr = window.devicePixelRatio || 1;
  const w = canvas.clientWidth || canvas.parentElement.clientWidth || 600;
  const h = canvas.clientHeight || 180;
  if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
    canvas.width = Math.round(w * dpr);
    canvas.height = Math.round(h * dpr);
  }
  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  return ctx;
}

// 統計全体を描画
function renderFcStats() {
  const scopeSel = $('#fcStatsScope');
  const rangeSel = $('#fcStatsRange');
  if (!scopeSel || !rangeSel) return;

  // デッキ選択肢を構築
  const prev = scopeSel.value;
  scopeSel.innerHTML = '';
  const allOpt = document.createElement('option');
  allOpt.value = 'all'; allOpt.textContent = '全デッキ';
  scopeSel.appendChild(allOpt);
  flashcards.decks.forEach((d) => {
    const o = document.createElement('option');
    o.value = d.id; o.textContent = d.name;
    scopeSel.appendChild(o);
  });
  if (prev && [...scopeSel.options].some((o) => o.value === prev)) scopeSel.value = prev;

  const days = Number(rangeSel.value) || 30;
  const scope = scopeSel.value || 'all';
  const series = fcDailySeries(days, scope);

  // サマリー
  const total = series.reduce((a, x) => a + x.total, 0);
  const good = series.reduce((a, x) => a + x.good, 0);
  const rate = total > 0 ? Math.round((good / total) * 100) : 0;
  const studyDays = series.filter((x) => x.total > 0).length;
  const sum = $('#fcStatsSummary');
  if (sum) {
    sum.innerHTML = `
      <span class="chip">学習枚数 ${total}</span>
      <span class="chip ok">正答率 ${rate}%</span>
      <span class="chip">学習日数 ${studyDays}日</span>`;
  }

  drawFcRateChart($('#fcRateCanvas'), series);
  drawFcCountChart($('#fcCountCanvas'), series);
  drawFcCurveChart($('#fcCurveCanvas'));
}

// ---- デッキ操作 ----
function fcGetDeck(id) {
  return flashcards.decks.find((d) => d.id === id) || null;
}

function fcDeckDueCount(deck, now) {
  now = now || Date.now();
  let n = 0;
  deck.cards.forEach((c) => { if (fcIsDue(c, now)) n++; });
  return n;
}

// 科目名でデッキを作成 or 取得
function fcGetOrCreateDeckByName(name) {
  const nm = (name || '未分類').trim() || '未分類';
  let deck = flashcards.decks.find((d) => d.name === nm);
  if (!deck) {
    deck = { id: fcUid(), name: nm, createdAt: Date.now(), cards: [] };
    flashcards.decks.push(deck);
    if (settings.deckSubjectSync) fcSyncDeckToSubject(deck.name);
  }
  return deck;
}

// デッキ名を科目として登録（連動④）
function fcSyncDeckToSubject(name) {
  if (!name) return;
  if (!subjects.includes(name)) {
    subjects.push(name);
    saveSubjects();
    renderSubjectManage();
    populateSubjectSelects();
  }
}

// 既存デッキ名と重複しない一意なデッキ名を作る（例: 「デッキ1（Q&A入替）」→「デッキ1（Q&A入替）2」）
function fcUniqueDeckName(base) {
  const b = String(base || '').trim() || 'デッキ';
  if (!flashcards.decks.some((d) => d.name === b)) return b;
  let i = 2;
  while (flashcards.decks.some((d) => d.name === `${b}${i}`)) i++;
  return `${b}${i}`;
}

// Q&A（表と裏）を入れ替えた新しいデッキを作成する
// - 元のデッキ（デッキ1）は変更しない
// - 新しいデッキ（デッキ2）に、表＝元の裏・裏＝元の表 としたカードを入れ、
//   学習状態（SRS）は初期状態（新規）から開始する
function fcSwapQAToNewDeck(deckId) {
  const src = fcGetDeck(deckId);
  if (!src) return null;
  if (!src.cards || src.cards.length === 0) {
    alert('カードがないため入れ替えできません。先にカードを追加してください。');
    return null;
  }

  const suggested = fcUniqueDeckName(`${src.name}（Q&A入替）`);
  const input = prompt('新しいデッキ名を入力してください（表と裏を入れ替えて複製します）。', suggested);
  if (input === null) return null; // キャンセル
  const name = fcUniqueDeckName((input || '').trim() || suggested);

  const now = Date.now();
  const newDeck = { id: fcUid(), name, createdAt: now, cards: [] };
  src.cards.forEach((c) => {
    // 表と裏を入れ替え。表が空だった場合は裏に入っていた内容を表へ回すため、両方を入れ替える
    newDeck.cards.push({
      id: fcUid(),
      front: String(c.back || ''),
      back: String(c.front || ''),
      note: String(c.note || ''),
      createdAt: now,
      srs: fcNewSrs(now),
      history: [],
    });
  });

  flashcards.decks.push(newDeck);
  if (settings.deckSubjectSync) fcSyncDeckToSubject(newDeck.name);
  saveFlashcards();
  return newDeck;
}

// ---- 画面描画：デッキ一覧 ----
function renderDecks() {
  const box = $('#deckList');
  if (!box) return;
  if (flashcards.decks.length === 0) {
    box.innerHTML = '<p class="hint">デッキがありません。上の入力欄から作成してください。</p>';
    return;
  }
  const now = Date.now();
  box.innerHTML = '';
  flashcards.decks.forEach((deck) => {
    const due = fcDeckDueCount(deck, now);
    const el = document.createElement('div');
    el.className = 'deck-item';
    el.innerHTML = `<div class="deck-item-head"><span class="deck-name"></span>
      <span class="deck-due-badge${due === 0 ? ' zero' : ''}">${due === 0 ? '期限なし' : due + '枚 復習'}</span></div>
      <div class="deck-meta"><span>全 ${deck.cards.length} 枚</span></div>`;
    el.querySelector('.deck-name').textContent = deck.name;
    el.addEventListener('click', () => openDeck(deck.id));
    box.appendChild(el);
  });
}

let fcOpenDeckId = null;

function openDeck(id) {
  const deck = fcGetDeck(id);
  if (!deck) return;
  fcOpenDeckId = id;
  $('#deckListCard').classList.add('hidden');
  $('#cardStudy').classList.add('hidden');
  $('#deckDetail').classList.remove('hidden');
  $('#deckDetailTitle').textContent = '🃏 ' + deck.name;
  renderDeckSummary();
  renderCardList();
}

function renderDeckSummary() {
  const deck = fcGetDeck(fcOpenDeckId);
  const box = $('#deckSummary');
  if (!deck || !box) return;
  const now = Date.now();
  let newN = 0, learning = 0, mastered = 0, leech = 0, due = 0;
  deck.cards.forEach((c) => {
    const st = fcState(c);
    if (st === 'new') newN++;
    else if (st === 'learning') learning++;
    else if (st === 'mastered') mastered++;
    else if (st === 'leech') leech++;
    if (fcIsDue(c, now)) due++;
  });
  box.innerHTML = `
    <span class="chip">全 ${deck.cards.length} 枚</span>
    <span class="chip bad">復習期限 ${due} 枚</span>
    <span class="chip">新規 ${newN}</span>
    <span class="chip">学習中 ${learning}</span>
    <span class="chip ok">覚えた ${mastered}</span>
    <span class="chip bad">苦手 ${leech}</span>`;
}

// 編集中のカードID（null なら通常表示）
let fcEditingId = null;

function renderCardList() {
  const deck = fcGetDeck(fcOpenDeckId);
  const ul = $('#cardList');
  if (!deck || !ul) return;
  ul.innerHTML = '';
  if (deck.cards.length === 0) {
    ul.innerHTML = '<li class="hint" style="padding:8px 4px;">カードがありません</li>';
    return;
  }
  const now = Date.now();
  deck.cards.forEach((card) => {
    // 編集モードの行
    if (card.id === fcEditingId) {
      ul.appendChild(buildCardEditRow(deck, card));
      return;
    }
    const st = fcState(card);
    const li = document.createElement('li');
    li.className = 'card-row';
    const front = document.createElement('span');
    front.className = 'card-front';
    front.textContent = card.front || '(表なし)';
    const back = document.createElement('span');
    back.className = 'card-back';
    back.textContent = card.back || '';
    const badge = document.createElement('span');
    badge.className = 'card-state ' + st;
    badge.textContent = FC_STATE_LABEL[st];
    const dueLbl = document.createElement('span');
    dueLbl.className = 'card-due';
    dueLbl.textContent = fcIsDue(card, now) ? '復習期限' : (card.srs && card.srs.due ? '次回 ' + todayKey(new Date(card.srs.due)) : '');

    // 編集ボタン
    const edit = document.createElement('button');
    edit.className = 'todo-delete card-edit-btn';
    edit.textContent = '✏️';
    edit.title = '編集';
    edit.addEventListener('click', () => {
      fcEditingId = card.id;
      renderCardList();
    });

    const del = document.createElement('button');
    del.className = 'todo-delete';
    del.textContent = '✕';
    del.title = '削除';
    del.addEventListener('click', () => {
      deck.cards = deck.cards.filter((c) => c.id !== card.id);
      saveFlashcards();
      renderDeckSummary();
      renderCardList();
      renderDecks();
      renderTodaySchedule();
    });
    li.appendChild(front);
    li.appendChild(back);
    li.appendChild(badge);
    li.appendChild(dueLbl);
    li.appendChild(edit);
    li.appendChild(del);
    // クリック（編集ボタン以外）でも編集モードへ
    li.addEventListener('click', (e) => {
      if (e.target.closest('button')) return;
      fcEditingId = card.id;
      renderCardList();
    });
    ul.appendChild(li);
  });
}

// カード1枚の編集行を生成
function buildCardEditRow(deck, card) {
  const li = document.createElement('li');
  li.className = 'card-row card-edit-row';

  const fIn = document.createElement('input');
  fIn.type = 'text'; fIn.className = 'memo-input card-edit-input';
  fIn.value = card.front || ''; fIn.placeholder = '表（問題）'; fIn.maxLength = 500;

  const bIn = document.createElement('input');
  bIn.type = 'text'; bIn.className = 'memo-input card-edit-input';
  bIn.value = card.back || ''; bIn.placeholder = '裏（答え）'; bIn.maxLength = 500;

  const nIn = document.createElement('input');
  nIn.type = 'text'; nIn.className = 'memo-input card-edit-note';
  nIn.value = card.note || ''; nIn.placeholder = 'メモ（任意）'; nIn.maxLength = 200;

  const save = document.createElement('button');
  save.className = 'btn btn-small btn-primary';
  save.textContent = '💾 保存';
  const cancel = document.createElement('button');
  cancel.className = 'btn btn-small';
  cancel.textContent = 'キャンセル';

  const commit = () => {
    card.front = fIn.value.trim();
    card.back = bIn.value.trim();
    card.note = nIn.value.trim();
    saveFlashcards();
    fcEditingId = null;
    renderCardList();
    renderDeckSummary();
    renderTodaySchedule();
  };
  save.addEventListener('click', commit);
  cancel.addEventListener('click', () => { fcEditingId = null; renderCardList(); });
  [fIn, bIn, nIn].forEach((inp) => {
    inp.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); commit(); }
      else if (e.key === 'Escape') { fcEditingId = null; renderCardList(); }
    });
  });

  const actions = document.createElement('div');
  actions.className = 'card-edit-actions';
  actions.appendChild(save);
  actions.appendChild(cancel);

  li.appendChild(fIn);
  li.appendChild(bIn);
  li.appendChild(nIn);
  li.appendChild(actions);

  setTimeout(() => fIn.focus(), 0);
  return li;
}

function addCardToDeck(front, back, note) {
  const deck = fcGetDeck(fcOpenDeckId);
  if (!deck) return null;
  const now = Date.now();
  const card = { id: fcUid(), front: String(front || ''), back: String(back || ''), note: String(note || ''), createdAt: now, srs: fcNewSrs(now), history: [] };
  deck.cards.push(card);
  saveFlashcards();
  return card;
}

// ---- 学習セッション ----
const fcStudy = { deckId: null, order: 'due', queue: [], index: 0, flipped: false, startedAt: 0, studyMs: 0, timer: null, counts: { again: 0, good: 0, easy: 0 }, total: 0, sessionLimit: 0, studied: new Set() };

// 「1回の枚数」設定を取得（0＝無制限）
function fcGetSessionLimit() {
  const inp = $('#deckStudyLimit');
  let v = inp ? Number(inp.value) : Number(settings.fcSessionLimit);
  if (!isFinite(v) || v < 0) v = 0;
  return Math.floor(v);
}

// 現在の出題範囲・学習済みカードを除いた対象カード一覧
function fcFilteredCards() {
  const deck = fcGetDeck(fcStudy.deckId);
  if (!deck) return [];
  const now = Date.now();
  let cards = deck.cards.filter((c) => !fcStudy.studied.has(c.id));
  if (fcStudy.order === 'due') cards = cards.filter((c) => fcIsDue(c, now));
  else if (fcStudy.order === 'weak') cards = cards.filter((c) => fcState(c) === 'leech');
  else if (fcStudy.order === 'new') cards = cards.filter((c) => fcState(c) === 'new');
  return cards;
}

// このセッションで残っている（未学習の）カード枚数
function fcRemainingCount() {
  return fcFilteredCards().length;
}

// 次のバッチ（1回の枚数ぶん）を取得
function fcNextBatch() {
  let cards = fcFilteredCards();
  const shuffleOn = ($('#deckShuffle') && $('#deckShuffle').checked) || settings.fcShuffle;
  if (shuffleOn) shuffleArray(cards);
  if (fcStudy.sessionLimit > 0) cards = cards.slice(0, fcStudy.sessionLimit);
  return cards;
}

// 学習セッションを開始（最初のバッチ）
function startStudy(deckId, order) {
  const deck = fcGetDeck(deckId);
  if (!deck) return;
  fcStudy.deckId = deckId;
  fcStudy.order = order || 'due';
  fcStudy.studied = new Set();
  fcStudy.counts = { again: 0, good: 0, easy: 0 };
  fcStudy.studyMs = 0;
  fcStudy.startedAt = Date.now();
  fcStudy.sessionLimit = fcGetSessionLimit();
  beginBatch(true);
}

// バッチ（1回の枚数）を読み込んでセッションを開始
function beginBatch(isInitial) {
  const deck = fcGetDeck(fcStudy.deckId);
  if (!deck) { exitStudy(); return; }
  const cards = fcNextBatch();
  if (cards.length === 0) {
    if (isInitial) {
      alert('該当するカードがありません。出題範囲や「1回の枚数」を変えてみてください。');
      fcStudy.deckId = null;
      fcStudy.startedAt = 0;
      return;
    }
    finishStudy();
    return;
  }

  fcStudy.queue = cards.map((c) => c.id);
  fcStudy.index = 0;
  fcStudy.flipped = false;
  fcStudy.total = fcStudy.queue.length;

  $('#deckListCard').classList.add('hidden');
  $('#deckDetail').classList.add('hidden');
  $('#cardStudy').classList.remove('hidden');
  $('#sessionDone').classList.add('hidden');
  $('#sessionContinue').classList.add('hidden');
  $('#flashcard').classList.remove('hidden');
  $('#flashHint').classList.remove('hidden');
  $('#flashFlip').classList.remove('hidden');
  $('#gradeButtons').classList.add('hidden');
  const timerLbl = $('#studyTimerLabel');
  if (timerLbl) timerLbl.textContent = '⏱ 00:00';

  startStudyTick();
  renderStudyCard();
}

// 「▶ 続けて学習」：次のバッチへ
function continueStudy() {
  if (!fcStudy.deckId) return;
  if (fcRemainingCount() === 0) { finishStudy(); return; }
  fcStudy.startedAt = Date.now(); // 次のバッチの学習時間を計測し直す
  fcStudy.studyMs = 0;
  beginBatch(false);
}

function startStudyTick() {
  if (fcStudy.timer) clearInterval(fcStudy.timer);
  fcStudy.timer = setInterval(() => {
    if (!fcStudy.startedAt) return;
    const sec = Math.floor((fcStudy.studyMs + (Date.now() - fcStudy.startedAt)) / 1000);
    const lbl = $('#studyTimerLabel');
    if (lbl) lbl.textContent = '⏱ ' + fmtHMS(sec);
  }, 500);
}

function renderStudyCard() {
  const deck = fcGetDeck(fcStudy.deckId);
  if (!deck) { exitStudy(); return; }
  const cardId = fcStudy.queue[fcStudy.index];
  const card = deck.cards.find((c) => c.id === cardId);
  if (!card) { finishStudy(); return; }

  $('#flashFront').textContent = card.front || '(表なし)';
  $('#flashBack').textContent = card.back || '(裏なし)';
  $('#flashcard').classList.remove('flipped');
  $('#gradeButtons').classList.add('hidden');
  $('#flashFlip').classList.remove('hidden');
  $('#flashHint').classList.remove('hidden');
  fcStudy.flipped = false;

  $('#studyProgress').textContent = `${fcStudy.index + 1} / ${fcStudy.queue.length}`;
  $('#gradeGoodLabel').textContent = fcNextIntervalLabel(card, 'good');
  $('#gradeEasyLabel').textContent = fcNextIntervalLabel(card, 'easy');
}

function flipCard() {
  if (fcStudy.flipped) return;
  fcStudy.flipped = true;
  $('#flashcard').classList.add('flipped');
  $('#gradeButtons').classList.remove('hidden');
  $('#flashFlip').classList.add('hidden');
  $('#flashHint').classList.add('hidden');
}

function gradeCard(grade) {
  if (!fcStudy.flipped) return;
  const deck = fcGetDeck(fcStudy.deckId);
  if (!deck) return;
  const cardId = fcStudy.queue[fcStudy.index];
  const card = deck.cards.find((c) => c.id === cardId);
  if (!card) return;

  const now = Date.now();
  const res = fcApply(card, grade, now);
  card.history.push({ t: now, ok: grade !== 'again', grade });
  fcStudy.counts[grade] = (fcStudy.counts[grade] || 0) + 1;
  fcStudy.studied.add(cardId); // このセッションで学習済みにする

  // 「覚えていない」は数枚後ろに再出題
  if (res.requeue > 0 && fcStudy.index + res.requeue < fcStudy.queue.length) {
    fcStudy.queue.splice(fcStudy.index + res.requeue, 0, cardId);
  }

  saveFlashcards();
  fcStudy.index++;
  if (fcStudy.index >= fcStudy.queue.length) {
    finishStudy();
  } else {
    renderStudyCard();
  }
}

// 学習時間を学習記録へ記録（連動①）
function fcRecordStudyTime() {
  const deck = fcGetDeck(fcStudy.deckId);
  const running = fcStudy.startedAt ? (Date.now() - fcStudy.startedAt) : 0;
  const totalMs = fcStudy.studyMs + running;
  const sec = Math.floor(totalMs / 1000);
  if (sec > 0 && deck) {
    recordStudy(sec, deck.name, '', 'flashcard');
    updateStreak();
    renderHeatmap();
    renderReports();
    renderStudy();
    renderPieChart();
  }
  fcStudy.studyMs = 0;
  fcStudy.startedAt = Date.now();
  return sec;
}

function finishStudy() {
  const sec = fcRecordStudyTime();
  if (fcStudy.timer) { clearInterval(fcStudy.timer); fcStudy.timer = null; }
  fcStudy.startedAt = 0;
  const c = fcStudy.counts;
  const deck = fcGetDeck(fcStudy.deckId);
  $('#flashcard').classList.add('hidden');
  $('#gradeButtons').classList.add('hidden');
  $('#flashFlip').classList.add('hidden');
  $('#flashHint').classList.add('hidden');
  $('#sessionDone').classList.remove('hidden');
  const remaining = fcRemainingCount();
  const continueBtn = $('#sessionContinue');
  const limitNote = fcStudy.sessionLimit > 0 ? `（1回 ${fcStudy.sessionLimit} 枚ずつ）` : '';
  $('#sessionDoneMsg').innerHTML =
    `「${deck ? escapeHtml(deck.name) : ''}」を学習しました。<br>` +
    `🙂 覚えた ${c.good} ・ 😎 簡単 ${c.easy} ・ 😵 覚えていない ${c.again}<br>` +
    `⏱ 学習時間 ${fmtHMS(sec)} を学習記録に追加しました。` +
    (remaining > 0
      ? `<br>📚 この出題範囲であと <b>${remaining}</b> 枚あります${limitNote}。「▶ 続けて学習」で続けられます。`
      : '');
  if (continueBtn) continueBtn.classList.toggle('hidden', remaining === 0);
  $('#studyProgress').textContent = '完了';
  saveFlashcards();
  renderDecks();
  renderTodaySchedule();
  renderFcStats();
}

function exitStudy() {
  if (fcStudy.deckId && fcStudy.startedAt) fcRecordStudyTime();
  if (fcStudy.timer) { clearInterval(fcStudy.timer); fcStudy.timer = null; }
  fcStudy.deckId = null;
  fcStudy.startedAt = 0;
  fcStudy.studied = new Set();
  $('#cardStudy').classList.add('hidden');
  $('#sessionDone').classList.add('hidden');
  $('#sessionContinue').classList.add('hidden');
  $('#deckListCard').classList.remove('hidden');
  $('#deckDetail').classList.add('hidden');
  renderDecks();
  renderTodaySchedule();
  renderFcStats();
}

// ---- 連動③: メモをカード化 ----
function memoToCard() {
  const memo = ($('#studyMemo') ? $('#studyMemo').value.trim() : '');
  if (!memo) { alert('先に学習内容メモを入力してください。'); return; }
  const subject = $('#studySubject') ? ($('#studySubject').value || '未分類') : '未分類';
  const deck = fcGetOrCreateDeckByName(subject);
  const now = Date.now();
  deck.cards.push({ id: fcUid(), front: memo, back: '', note: '', createdAt: now, srs: fcNewSrs(now), history: [] });
  saveFlashcards();
  if ($('#studyMemo')) $('#studyMemo').value = '';
  renderDecks();
  renderTodaySchedule();
  alert(`「${subject}」デッキにカードを追加しました。\n裏面（答え）はカードタブで入力できます。`);
}

// 復習項目をカード化（復習タブ用）
function reviewToCard(r) {
  const deck = fcGetOrCreateDeckByName(r.subject || '未分類');
  const now = Date.now();
  deck.cards.push({ id: fcUid(), front: r.text, back: '', note: '', createdAt: now, srs: fcNewSrs(now), history: [] });
  saveFlashcards();
  renderDecks();
  renderTodaySchedule();
  showTab('cards');
  openDeck(deck.id);
}

// ---- 連動②: 期限カードを「今日の予定」に表示 ----
function renderTodayCards() {
  const el = $('#todayCards');
  if (!el) return;
  const now = Date.now();
  const dueDecks = flashcards.decks
    .map((d) => ({ deck: d, due: fcDeckDueCount(d, now) }))
    .filter((x) => x.due > 0);
  if (dueDecks.length === 0) {
    el.innerHTML = '<p class="hint">復習期限のカードはありません</p>';
    return;
  }
  el.innerHTML = '';
  dueDecks.forEach(({ deck, due }) => {
    const div = document.createElement('div');
    div.className = 'today-item';
    div.innerHTML = '<span class="today-text"></span>';
    const btn = document.createElement('button');
    btn.className = 'review-do-btn';
    btn.textContent = '▶ 学習';
    btn.addEventListener('click', () => {
      showTab('cards');
      startStudy(deck.id, 'due');
    });
    div.querySelector('.today-text').textContent = `${deck.name}（${due}枚）`;
    div.appendChild(btn);
    el.appendChild(div);
  });
}

// ---- フラッシュカードPWAのJSON取り込み ----
function importFlashcardsData(obj) {
  // 対応形式: {app:'offline-flashcards', decks:[...]} / {decks:[...]} / {cards:[...]} / [...]
  let decks = [];
  let settingsIn = null;
  if (Array.isArray(obj)) decks = [{ name: 'インポート', cards: obj }];
  else if (obj && Array.isArray(obj.decks)) { decks = obj.decks; settingsIn = obj.settings || null; }
  else if (obj && Array.isArray(obj.deck)) decks = [obj.deck];
  else if (obj && Array.isArray(obj.cards)) decks = [{ name: (obj.name || 'インポート'), cards: obj.cards }];

  if (decks.length === 0) { alert('デッキまたはカードが見つかりませんでした。'); return 0; }

  let imported = 0;
  const now = Date.now();
  decks.forEach((d) => {
    const name = (d && d.name) ? String(d.name) : 'インポート';
    const rawCards = (d && (d.cards || d.items)) || [];
    if (!Array.isArray(rawCards) || rawCards.length === 0) return;
    let deck = flashcards.decks.find((x) => x.name === name);
    if (!deck) {
      deck = { id: fcUid(), name, createdAt: now, cards: [] };
      flashcards.decks.push(deck);
      if (settings.deckSubjectSync) fcSyncDeckToSubject(name);
    }
    rawCards.forEach((rc) => {
      if (!rc || typeof rc !== 'object') return;
      const front = rc.front !== undefined ? rc.front : (rc.q !== undefined ? rc.q : (rc.question || rc.term || rc.word || ''));
      const back = rc.back !== undefined ? rc.back : (rc.a !== undefined ? rc.a : (rc.answer || rc.definition || rc.meaning || ''));
      const note = rc.note || rc.memo || '';
      const card = {
        id: rc.id || fcUid(),
        front: String(front || ''), back: String(back || ''), note: String(note || ''),
        createdAt: Number(rc.createdAt) || now,
        srs: (rc.srs && typeof rc.srs === 'object') ? rc.srs : fcNewSrs(now),
        history: Array.isArray(rc.history) ? rc.history : [],
      };
      fcEnsure(card);
      deck.cards.push(card);
      imported++;
    });
  });

  // 設定（theme など）の一部を取り込む（任意）
  if (settingsIn && typeof settingsIn === 'object') {
    if (settingsIn.theme === 'light' || settingsIn.theme === 'dark') settings.theme = settingsIn.theme;
    saveSettings();
    applySettings();
  }

  saveFlashcards();
  renderDecks();
  renderTodaySchedule();
  return imported;
}

/* ---- ファイル読み込み（PDF / CSV / JSON / テキスト） ---- */
// 「表」と「裏」を分ける区切り記号（タブ・縦棒・カンマ・読点・コロン・ダッシュ）
const FC_SEP_RE = /\t|\||｜|¦|,|、|，|：|:| - | – | — /;

function fcCsvEscape(v) {
  const t = String(v == null ? '' : v);
  if (/[",\n\r]/.test(t)) return '"' + t.replace(/"/g, '""') + '"';
  return t;
}

// 区切り文字でCSV/TSVを解析（引用符対応）
function fcParseDelimited(text, delim) {
  const s = String(text == null ? '' : text);
  const rows = [];
  let row = [], field = '', inQ = false;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (inQ) {
      if (c === '"') {
        if (s[i + 1] === '"') { field += '"'; i++; }
        else inQ = false;
      } else field += c;
    } else if (c === '"') {
      inQ = true;
    } else if (c === delim) {
      row.push(field); field = '';
    } else if (c === '\n') {
      row.push(field); rows.push(row); row = []; field = '';
    } else if (c === '\r') {
      /* 無視 */
    } else {
      field += c;
    }
  }
  if (field !== '' || row.length > 0) { row.push(field); rows.push(row); }
  return rows;
}

// 区切り文字を推定（, / タブ / ; のうち最も多いもの）
function fcDetectDelim(text) {
  const lines = String(text || '').split(/\r?\n/).filter((l) => l.trim()).slice(0, 20);
  let best = ',', bestN = 0;
  [',', '\t', ';'].forEach((d) => {
    const n = lines.reduce((a, l) => a + (l.split(d).length - 1), 0);
    if (n > bestN) { bestN = n; best = d; }
  });
  return best;
}

// 自由テキスト（PDF・TXT）を行ごとに 表,裏 へ変換
function fcTextLinesToCsv(text) {
  const out = [];
  String(text || '').split(/\r?\n/).forEach((raw) => {
    const line = raw.trim();
    if (!line) return;
    const m = line.match(FC_SEP_RE);
    let front = line, back = '';
    if (m) {
      front = line.slice(0, m.index).trim();
      back = line.slice(m.index + m[0].length).trim();
    }
    if (!front && !back) return;
    out.push(fcCsvEscape(front) + ', ' + fcCsvEscape(back));
  });
  return out.join('\n');
}

// CSVの行配列を 表,裏,メモ のプレビュー文字列へ変換（ヘッダー自動判定）
function fcCsvRowsToPreview(rows) {
  const clean = rows.filter((r) => r.some((c) => String(c).trim() !== ''));
  if (clean.length === 0) return '';
  const head = clean[0].map((c) => String(c).trim().toLowerCase());
  const findIdx = (keys) => head.findIndex((h) => h && keys.some((k) => h === k || h.indexOf(k) !== -1));
  const fi = findIdx(['front', 'question', 'term', 'word', '表', '問題', '単語']);
  const bi = findIdx(['back', 'answer', 'meaning', 'definition', '裏', '答え', '意味']);
  const ni = findIdx(['note', 'memo', 'メモ', '備考']);
  const isHeader = fi >= 0 || bi >= 0;
  const frontIdx = isHeader && fi >= 0 ? fi : 0;
  const backIdx = isHeader && bi >= 0 ? bi : 1;
  const noteIdx = ni;
  const start = isHeader ? 1 : 0;
  const out = [];
  for (let i = start; i < clean.length; i++) {
    const r = clean[i];
    const front = (r[frontIdx] !== undefined ? r[frontIdx] : '').trim();
    const back = (backIdx >= 0 && r[backIdx] !== undefined ? r[backIdx] : '').trim();
    const note = (noteIdx >= 0 && r[noteIdx] !== undefined ? r[noteIdx] : '').trim();
    if (!front && !back) continue;
    out.push(fcCsvEscape(front) + ', ' + fcCsvEscape(back) + (note ? ', ' + fcCsvEscape(note) : ''));
  }
  return out.join('\n');
}

// プレビュー文字列を行ごとに {front, back, note} へ
function fcParsePreviewRows(text) {
  const out = [];
  String(text || '').split(/\r?\n/).forEach((raw) => {
    const line = raw.trim();
    if (!line) return;
    const hasCsv = line.indexOf(',') !== -1 || line.indexOf('"') !== -1;
    let front = '', back = '', note = '';
    const cells = hasCsv ? (fcParseDelimited(line, ',')[0] || []) : null;
    if (cells && cells.length >= 2) {
      front = cells[0]; back = cells[1]; note = cells[2] || '';
    } else if (!hasCsv) {
      const m = line.match(FC_SEP_RE);
      if (m) { front = line.slice(0, m.index); back = line.slice(m.index + m[0].length); }
      else { front = line; }
    } else {
      front = (cells && cells[0]) || line;
    }
    front = String(front).trim(); back = String(back).trim(); note = String(note).trim();
    if (!front && !back) return;
    out.push({ front, back, note });
  });
  return out;
}

/* ---- PDF（pdf.js をローカルから遅延読み込み） ---- */
let fcPdfJsPromise = null;

// 古いブラウザ向け structuredClone の簡易ポリフィル（pdf.js が使用）
function fcEnsureStructuredClone() {
  if (typeof window.structuredClone === 'function') return;
  const clone = (obj) => {
    if (obj === null || typeof obj !== 'object') return obj;
    if (obj instanceof Date) return new Date(obj.getTime());
    if (obj instanceof RegExp) return new RegExp(obj.source, obj.flags);
    if (typeof ArrayBuffer !== 'undefined') {
      if (obj instanceof ArrayBuffer) return obj.slice(0);
      if (ArrayBuffer.isView(obj)) {
        if (typeof DataView !== 'undefined' && obj instanceof DataView) return new DataView(clone(obj.buffer));
        return new obj.constructor(clone(obj.buffer), obj.byteOffset, obj.length);
      }
    }
    if (Array.isArray(obj)) return obj.map(clone);
    if (typeof Map !== 'undefined' && obj instanceof Map) {
      const m = new Map(); obj.forEach((v, k) => m.set(clone(k), clone(v))); return m;
    }
    if (typeof Set !== 'undefined' && obj instanceof Set) {
      const s = new Set(); obj.forEach((v) => s.add(clone(v))); return s;
    }
    const out = {};
    Object.keys(obj).forEach((k) => { out[k] = clone(obj[k]); });
    return out;
  };
  window.structuredClone = clone;
}

function fcLoadScript(src) {
  return new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = src;
    s.onload = () => resolve();
    s.onerror = () => reject(new Error('ライブラリを読み込めませんでした（' + src + '）'));
    document.head.appendChild(s);
  });
}

function fcLoadPdfJs() {
  if (window.pdfjsLib) return Promise.resolve(window.pdfjsLib);
  if (fcPdfJsPromise) return fcPdfJsPromise;
  fcEnsureStructuredClone();
  fcPdfJsPromise = fcLoadScript('js/pdf.min.js')
    .then(() => fcLoadScript('js/pdf.worker.min.js'))
    .then(() => {
      const lib = window.pdfjsLib;
      if (lib && lib.GlobalWorkerOptions && !lib.GlobalWorkerOptions.workerSrc) {
        lib.GlobalWorkerOptions.workerSrc = 'js/pdf.worker.min.js';
      }
      return lib;
    })
    .catch((e) => { fcPdfJsPromise = null; throw e; });
  return fcPdfJsPromise;
}

async function fcExtractPdfText(file) {
  fcEnsureStructuredClone();
  const pdfjs = await fcLoadPdfJs();
  if (!pdfjs) throw new Error('PDFライブラリを読み込めませんでした。');
  const buf = await fcReadFileArrayBuffer(file);
  const retryBuf = buf.slice(0); // cMaps なし再試行用
  let doc;
  try {
    // 同梱の cMaps を利用（日本語などのCIDフォント対応）
    doc = await pdfjs.getDocument({ data: buf, cMapUrl: 'js/cmaps/', cMapPacked: true }).promise;
  } catch (e) {
    // cMaps を取得できない環境（file:// 等）では cMaps なしで再試行
    doc = await pdfjs.getDocument({ data: retryBuf }).promise;
  }
  const lines = [];
  for (let p = 1; p <= doc.numPages; p++) {
    const page = await doc.getPage(p);
    const tc = await page.getTextContent();
    let line = '';
    tc.items.forEach((it) => {
      if (typeof it.str === 'string') line += it.str;
      if (it.hasEOL) { lines.push(line); line = ''; }
    });
    if (line) lines.push(line);
  }
  try { doc.destroy(); } catch (e) { /* 無視 */ }
  return lines.join('\n');
}

function fcReadFileText(file) {
  if (file && typeof file.text === 'function') return file.text();
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result || ''));
    r.onerror = () => reject(r.error || new Error('読み込みに失敗しました'));
    r.readAsText(file);
  });
}

function fcReadFileArrayBuffer(file) {
  if (file && typeof file.arrayBuffer === 'function') return file.arrayBuffer();
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = () => reject(r.error || new Error('読み込みに失敗しました'));
    r.readAsArrayBuffer(file);
  });
}

/* ---- 読み込みモーダル ---- */
function fcPopulateImportDeckSelect() {
  const sel = $('#importDeckSelect');
  if (!sel) return;
  sel.innerHTML = '';
  flashcards.decks.forEach((d) => {
    const o = document.createElement('option');
    o.value = d.id; o.textContent = d.name;
    sel.appendChild(o);
  });
  const n = document.createElement('option');
  n.value = '__new__'; n.textContent = '＋ 新しいデッキ';
  sel.appendChild(n);
  if (fcOpenDeckId && fcGetDeck(fcOpenDeckId)) sel.value = fcOpenDeckId;
  else if (flashcards.decks.length === 0) sel.value = '__new__';
  fcUpdateImportNewNameVisibility();
}

function fcUpdateImportNewNameVisibility() {
  const sel = $('#importDeckSelect');
  const inp = $('#importNewDeckName');
  if (!sel || !inp) return;
  const isNew = sel.value === '__new__';
  inp.classList.toggle('hidden', !isNew);
}

function fcOpenImportModal(previewText, sourceLabel) {
  const modal = $('#importModal');
  if (!modal) return;
  fcPopulateImportDeckSelect();
  const ta = $('#importPreview');
  if (ta) ta.value = previewText || '';
  const info = $('#importSourceInfo');
  if (info) info.textContent = sourceLabel || '内容を確認して取り込んでください。';
  fcUpdateImportCount();
  modal.classList.remove('hidden');
}

function fcCloseImportModal() {
  const modal = $('#importModal');
  if (modal) modal.classList.add('hidden');
}

function fcUpdateImportCount() {
  const box = $('#importCountInfo');
  if (!box) return;
  const ta = $('#importPreview');
  const rows = fcParsePreviewRows(ta ? ta.value : '');
  box.innerHTML = `<span class="chip">取り込み予定 ${rows.length} 枚</span>`;
}

function fcConfirmImport() {
  const sel = $('#importDeckSelect');
  let deck = null;
  if (sel && sel.value === '__new__') {
    const nm = (($('#importNewDeckName') || {}).value || '').trim();
    if (!nm) { alert('新しいデッキ名を入力してください。'); return; }
    deck = fcGetOrCreateDeckByName(nm);
  } else if (sel) {
    deck = fcGetDeck(sel.value);
  } else {
    deck = fcGetOrCreateDeckByName('インポート');
  }
  if (!deck) { alert('取り込み先のデッキが見つかりません。'); return; }

  const rows = fcParsePreviewRows($('#importPreview') ? $('#importPreview').value : '');
  if (rows.length === 0) { alert('取り込むカードがありません。'); return; }

  const now = Date.now();
  rows.forEach((r) => {
    deck.cards.push({ id: fcUid(), front: r.front, back: r.back, note: r.note || '', createdAt: now, srs: fcNewSrs(now), history: [] });
  });
  if (settings.deckSubjectSync) fcSyncDeckToSubject(deck.name);
  saveFlashcards();
  fcCloseImportModal();
  renderDecks();
  renderTodaySchedule();
  renderFcStats();
  if (fcOpenDeckId === deck.id) { renderDeckSummary(); renderCardList(); }
  else { showTab('cards'); openDeck(deck.id); }
  alert(`${rows.length} 枚のカードを「${deck.name}」に取り込みました。`);
}

// 選択されたファイルを種類に応じて読み込む
async function fcHandleImportFiles(files) {
  const list = Array.from(files || []);
  if (list.length === 0) return;
  const chunks = [];
  const labels = [];
  let jsonCount = 0;

  for (const file of list) {
    const name = (file.name || '').toLowerCase();
    const type = file.type || '';
    try {
      if (name.endsWith('.json') || type === 'application/json') {
        const text = await fcReadFileText(file);
        const obj = JSON.parse(text);
        jsonCount += importFlashcardsData(obj);
        continue;
      }
      if (name.endsWith('.pdf') || type === 'application/pdf') {
        const text = await fcExtractPdfText(file);
        const preview = fcTextLinesToCsv(text);
        if (preview.trim()) chunks.push(preview);
        labels.push(`PDF「${file.name}」`);
        continue;
      }
      const text = await fcReadFileText(file);
      let preview;
      if (name.endsWith('.tsv')) {
        preview = fcCsvRowsToPreview(fcParseDelimited(text, '\t'));
      } else if (name.endsWith('.csv')) {
        preview = fcCsvRowsToPreview(fcParseDelimited(text, fcDetectDelim(text)));
      } else {
        preview = fcTextLinesToCsv(text);
      }
      if (!preview.trim() && text.trim()) preview = fcTextLinesToCsv(text);
      chunks.push(preview);
      labels.push(`「${file.name}」`);
    } catch (err) {
      alert(`「${file.name}」を読み込めませんでした: ${err && err.message ? err.message : err}`);
    }
  }

  if (jsonCount > 0 && chunks.filter((c) => c.trim()).length === 0) {
    alert(`${jsonCount} 枚のカードを取り込みました。`);
    return;
  }

  const previewAll = chunks.join('\n');
  if (previewAll.trim()) {
    const n = fcParsePreviewRows(previewAll).length;
    fcOpenImportModal(previewAll, `${labels.join(' / ')}から ${n} 枚を検出しました。内容を確認してください。`);
  }
}

function initFlashcards() {
  if (!$('#deckAdd')) return;

  // デッキ作成
  $('#deckAdd').addEventListener('click', () => {
    const inp = $('#deckNewName');
    const name = inp.value.trim();
    if (!name) return;
    if (flashcards.decks.some((d) => d.name === name)) { alert('同じ名前のデッキがあります。'); return; }
    flashcards.decks.push({ id: fcUid(), name, createdAt: Date.now(), cards: [] });
    if (settings.deckSubjectSync) fcSyncDeckToSubject(name);
    saveFlashcards();
    inp.value = '';
    renderDecks();
  });
  $('#deckNewName').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('#deckAdd').click(); });

  // 一覧へ戻る
  $('#deckBack').addEventListener('click', () => {
    $('#deckDetail').classList.add('hidden');
    $('#deckListCard').classList.remove('hidden');
    fcOpenDeckId = null;
    renderDecks();
  });

  // デッキ削除
  $('#deckDelete').addEventListener('click', () => {
    const deck = fcGetDeck(fcOpenDeckId);
    if (!deck) return;
    if (!confirm(`デッキ「${deck.name}」を削除しますか？`)) return;
    flashcards.decks = flashcards.decks.filter((d) => d.id !== deck.id);
    saveFlashcards();
    fcOpenDeckId = null;
    $('#deckDetail').classList.add('hidden');
    $('#deckListCard').classList.remove('hidden');
    renderDecks();
    renderTodaySchedule();
  });

  // デッキ名変更
  const renameBtn = $('#deckRename');
  if (renameBtn) {
    renameBtn.addEventListener('click', () => {
      const deck = fcGetDeck(fcOpenDeckId);
      if (!deck) return;
      const cur = deck.name;
      const nm = prompt('新しいデッキ名を入力してください。', cur);
      if (nm === null) return;
      const name = nm.trim();
      if (!name || name === cur) return;
      if (flashcards.decks.some((d) => d.id !== deck.id && d.name === name)) {
        alert('同じ名前のデッキがあります。'); return;
      }
      deck.name = name;
      if (settings.deckSubjectSync) fcSyncDeckToSubject(name);
      saveFlashcards();
      $('#deckDetailTitle').textContent = '🃏 ' + name;
      renderDecks();
      renderTodaySchedule();
    });
  }

  // Q&A（表と裏）を入れ替えて新しいデッキとして複製
  const swapBtn = $('#deckSwapQA');
  if (swapBtn) {
    swapBtn.addEventListener('click', () => {
      const src = fcGetDeck(fcOpenDeckId);
      if (!src) return;
      const newDeck = fcSwapQAToNewDeck(fcOpenDeckId);
      if (!newDeck) return; // キャンセル／対象なし
      renderDecks();
      renderTodaySchedule();
      renderFcStats();
      alert(
        `「${src.name}」のQ&Aを入れ替えて、新しいデッキ「${newDeck.name}」を作成しました（${newDeck.cards.length}枚）。\n` +
        `元のデッキ「${src.name}」はそのまま残っています。`
      );
      openDeck(newDeck.id);
    });
  }

  // カード追加（1枚）
  $('#cardAdd').addEventListener('click', () => {
    const front = $('#cardFront').value.trim();
    const back = $('#cardBack').value.trim();
    if (!front && !back) return;
    addCardToDeck(front, back, '');
    $('#cardFront').value = '';
    $('#cardBack').value = '';
    $('#cardFront').focus();
    renderDeckSummary();
    renderCardList();
    renderDecks();
    renderTodaySchedule();
  });
  $('#cardBack').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('#cardAdd').click(); });

  // カード追加（まとめて）
  $('#cardBulkAdd').addEventListener('click', () => {
    const text = $('#cardBulk').value;
    const lines = text.split('\n').map((l) => l.trim()).filter((l) => l);
    let n = 0;
    lines.forEach((line) => {
      const parts = line.split(/\t|,|\||、/);
      const front = (parts[0] || '').trim();
      const back = (parts.slice(1).join(' ') || '').trim();
      if (front || back) { addCardToDeck(front, back, ''); n++; }
    });
    $('#cardBulk').value = '';
    renderDeckSummary();
    renderCardList();
    renderDecks();
    renderTodaySchedule();
    alert(`${n} 枚のカードを追加しました。`);
  });

  // 学習開始
  $('#deckStudy').addEventListener('click', () => {
    startStudy(fcOpenDeckId, $('#deckStudyOrder').value);
  });

  // 「1回の枚数」入力（デッキ詳細）: 変更を保存
  const limitInp = $('#deckStudyLimit');
  if (limitInp) {
    limitInp.value = (typeof settings.fcSessionLimit === 'number' ? settings.fcSessionLimit : 20);
    limitInp.addEventListener('change', () => {
      let v = Math.floor(Number(limitInp.value));
      if (!isFinite(v) || v < 0) v = 0;
      settings.fcSessionLimit = v;
      limitInp.value = v;
      saveSettings();
      const m = $('#fcSessionLimit'); if (m) m.value = v;
    });
  }

  // 「1回の枚数」入力（設定モーダル）: 変更を保存
  const limitModal = $('#fcSessionLimit');
  if (limitModal) {
    limitModal.value = (typeof settings.fcSessionLimit === 'number' ? settings.fcSessionLimit : 20);
    limitModal.addEventListener('change', () => {
      let v = Math.floor(Number(limitModal.value));
      if (!isFinite(v) || v < 0) v = 0;
      settings.fcSessionLimit = v;
      limitModal.value = v;
      saveSettings();
      const li = $('#deckStudyLimit'); if (li) li.value = v;
    });
  }

  // 続けて学習
  const contBtn = $('#sessionContinue');
  if (contBtn) contBtn.addEventListener('click', continueStudy);

  // カードめくり・採点
  $('#flashcard').addEventListener('click', flipCard);
  $('#flashFlip').addEventListener('click', flipCard);
  $$('#gradeButtons .grade-btn').forEach((b) => {
    b.addEventListener('click', (e) => { e.stopPropagation(); gradeCard(b.dataset.grade); });
  });
  $('#studyExit').addEventListener('click', exitStudy);

  // メモ→カード
  if ($('#memoToCard')) $('#memoToCard').addEventListener('click', memoToCard);

  // カード読み込み（PDF / CSV / JSON / テキスト）
  $('#cardsImportBtn').addEventListener('click', () => $('#cardsImport').click());
  $('#cardsImport').addEventListener('change', (e) => {
    const files = Array.from(e.target.files || []);
    e.target.value = '';
    if (files.length) fcHandleImportFiles(files);
  });

  // 貼り付けて読み込み（プレビューから）
  if ($('#cardsPasteBtn')) {
    $('#cardsPasteBtn').addEventListener('click', () => {
      fcOpenImportModal('', 'テキストを貼り付けて「表, 裏」形式で入力してください。');
    });
  }

  // 読み込みモーダルの操作
  const impClose = $('#importClose');
  if (impClose) impClose.addEventListener('click', fcCloseImportModal);
  const impCancel = $('#importCancel');
  if (impCancel) impCancel.addEventListener('click', fcCloseImportModal);
  const impConfirm = $('#importConfirm');
  if (impConfirm) impConfirm.addEventListener('click', fcConfirmImport);
  const impSel = $('#importDeckSelect');
  if (impSel) impSel.addEventListener('change', () => {
    fcUpdateImportNewNameVisibility();
    if (impSel.value === '__new__') { const i = $('#importNewDeckName'); if (i) i.focus(); }
  });
  const impPrev = $('#importPreview');
  if (impPrev) impPrev.addEventListener('input', fcUpdateImportCount);

  // デッキ名→科目の同期トグル
  const syncTgl = $('#deckSubjectSync');
  if (syncTgl) {
    syncTgl.checked = !!settings.deckSubjectSync;
    syncTgl.addEventListener('change', (e) => {
      settings.deckSubjectSync = e.target.checked;
      saveSettings();
      if (e.target.checked) {
        flashcards.decks.forEach((d) => fcSyncDeckToSubject(d.name));
      }
    });
  }

  // メモからカード自動作成トグル
  const autoTgl = $('#memoAutoCard');
  if (autoTgl) {
    autoTgl.checked = !!settings.memoAutoCard;
    autoTgl.addEventListener('change', (e) => {
      settings.memoAutoCard = e.target.checked;
      saveSettings();
    });
  }

  // シャッフル（設定保存）
  const shufTgl = $('#deckShuffle');
  if (shufTgl) {
    shufTgl.checked = !!settings.fcShuffle;
    shufTgl.addEventListener('change', (e) => {
      settings.fcShuffle = e.target.checked;
      saveSettings();
      const m = $('#fcShuffleToggle'); if (m) m.checked = e.target.checked;
    });
  }

  // シャッフル（設定モーダル側）
  const shufModal = $('#fcShuffleToggle');
  if (shufModal) {
    shufModal.checked = !!settings.fcShuffle;
    shufModal.addEventListener('change', (e) => {
      settings.fcShuffle = e.target.checked;
      saveSettings();
      const d = $('#deckShuffle'); if (d) d.checked = e.target.checked;
    });
  }

  // 統計（対象デッキ・期間）
  const scopeSel = $('#fcStatsScope');
  const rangeSel = $('#fcStatsRange');
  if (scopeSel) scopeSel.addEventListener('change', renderFcStats);
  if (rangeSel) rangeSel.addEventListener('change', renderFcStats);
  window.addEventListener('resize', () => {
    const panel = $('#tab-cards');
    if (panel && panel.classList.contains('active')) renderFcStats();
  });

  renderDecks();
  renderFcStats();
}

/* ============================================================
   タブ表示ヘルパー
   ============================================================ */
function showTab(name) {
  $$('.tab-btn').forEach((b) => b.classList.remove('active'));
  $$('.tab-panel').forEach((p) => p.classList.remove('active'));
  const btn = document.querySelector(`.tab-btn[data-tab="${name}"]`);
  const panel = $('#tab-' + name);
  if (btn) btn.classList.add('active');
  if (panel) panel.classList.add('active');
  if (name === 'clock' && typeof renderTodaySchedule === 'function') renderTodaySchedule();
  if (name === 'cards') {
    if (typeof renderDecks === 'function') renderDecks();
    if (typeof renderFcStats === 'function') renderFcStats();
  }
}

/* ============================================================
   起動処理
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {
  initTabs();
  updateClock();
  setInterval(updateClock, 1000);

  // 科目セレクトを最初に構築
  populateSubjectSelects();

  // カレンダー初期化＆年跨ぎでも現在月に戻せるようボタン設定
  renderCalendar();
  initEvents();
  $('#prevMonth').addEventListener('click', () => {
    calendarState.month--;
    if (calendarState.month < 0) { calendarState.month = 11; calendarState.year--; }
    renderCalendar();
  });
  $('#nextMonth').addEventListener('click', () => {
    calendarState.month++;
    if (calendarState.month > 11) { calendarState.month = 0; calendarState.year++; }
    renderCalendar();
  });

  initCustomize();
  initMusicPlayer();
  initAmbient();
  initTodo();
  initStudy();
  initGoals();
  initPomodoro();
  initReviews();
  initHabits();
  initReports();
  initFlashcards();
  initStats();
  initBackup();
  initShortcuts();
  initPWA();

  // 学習記録・予定の変化を各種表示へ反映
  setInterval(() => {
    renderTodaySchedule();
    renderGoals();
    renderPieChart();
  }, 30000);
});
