/* ============================================================
   features.js — 受験生向け拡張パック（app.js の後に読み込み）
   追加する機能:
     S1 Anki取込 / S2 穴埋め(Cloze)カード / S3 学習時間の手動入力・編集・削除
     S4 データ保護（バックアップ・Undo・容量警告）
     A1 模試・過去問の得点管理 / A2 試験日カウントダウン
     A3 4択・タイピング出題 / A4 復習負荷の予測
     B1 苦手カード(Leech) / B2 単元タグ分析 / B3 詰め込み(Cram)
     B4 数式ライト描画 / B5 画像カード(IndexedDB) / B6 時間割＋ToDo連動
     B7 科目別目標配分 / B8 毎日のリマインダー通知
   外部ライブラリ・サーバーは使用しません（オフライン動作を維持）。
   ============================================================ */
'use strict';

/* ============================================================
   0. ユーティリティ / ストレージ
   ============================================================ */
const PRO_KEYS = {
  examDates: 'dashboard_exam_dates',
  examScores: 'dashboard_exam_scores',
  subjectGoals: 'dashboard_subject_goals',
  timetable: 'dashboard_timetable',
  reminder: 'dashboard_reminder',
  lastBackup: 'dashboard_last_backup',
  schema: 'dashboard_schema_version',
};

function proUid() {
  return (typeof fcUid === 'function')
    ? fcUid()
    : (Date.now().toString(36) + Math.random().toString(36).slice(2, 8));
}

function proLoadJSON(key, def) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : def;
  } catch (e) { return def; }
}

function proSaveJSON(key, val) {
  try { localStorage.setItem(key, JSON.stringify(val)); return true; }
  catch (e) { return false; }
}

let proExamDates = proLoadJSON(PRO_KEYS.examDates, []);       // [{id,label,date}]
let proExamScores = proLoadJSON(PRO_KEYS.examScores, []);     // [{id,name,date,subject,score,max,dev}]
let proSubjectGoals = proLoadJSON(PRO_KEYS.subjectGoals, {}); // { 科目: 週あたり分 }
let proTimetable = proLoadJSON(PRO_KEYS.timetable, []);       // [{id,day,start,end,subject,label}]
let proReminder = proLoadJSON(PRO_KEYS.reminder, { enabled: false, time: '20:00', lastFired: null });

/* ---- スキーマ版管理（将来の形式変更に備える） ---- */
try {
  if (!localStorage.getItem(PRO_KEYS.schema)) localStorage.setItem(PRO_KEYS.schema, '2');
} catch (e) { /* 無視 */ }

/* ============================================================
   1. トースト / Undo（元に戻す） / 容量警告
   ============================================================ */
function proToast(msg, actionLabel, actionFn, ms) {
  const area = document.getElementById('toastArea');
  if (!area) return;
  const el = document.createElement('div');
  el.className = 'toast';
  const span = document.createElement('span');
  span.textContent = msg;
  el.appendChild(span);
  if (actionLabel && typeof actionFn === 'function') {
    const b = document.createElement('button');
    b.className = 'toast-action';
    b.textContent = actionLabel;
    b.addEventListener('click', () => { actionFn(); el.remove(); });
    el.appendChild(b);
  }
  area.appendChild(el);
  setTimeout(() => { el.classList.add('fade'); }, Math.max(1500, (ms || 4000) - 500));
  setTimeout(() => { el.remove(); }, ms || 4000);
}

const PRO_SNAPSHOT_KEYS = [
  'dashboard_events', 'dashboard_settings', 'dashboard_subjects', 'dashboard_todos',
  'dashboard_study', 'dashboard_goals', 'dashboard_streak', 'dashboard_reviews',
  'dashboard_habits', 'dashboard_flashcards',
  PRO_KEYS.examDates, PRO_KEYS.examScores, PRO_KEYS.subjectGoals, PRO_KEYS.timetable,
];

const proUndo = { stack: [], max: 8 };

function proSnapshot() {
  const o = {};
  PRO_SNAPSHOT_KEYS.forEach((k) => { o[k] = localStorage.getItem(k); });
  return o;
}

function proPushUndo(label) {
  try {
    proUndo.stack.push({ label: label || '操作', data: proSnapshot(), at: Date.now() });
    if (proUndo.stack.length > proUndo.max) proUndo.stack.shift();
  } catch (e) { /* 無視 */ }
}

function proRestore(snap) {
  PRO_SNAPSHOT_KEYS.forEach((k) => {
    try {
      if (snap[k] === null || snap[k] === undefined) localStorage.removeItem(k);
      else localStorage.setItem(k, snap[k]);
    } catch (e) { /* 無視 */ }
  });
}

function proUndoLast() {
  const s = proUndo.stack.pop();
  if (!s) { proToast('元に戻せる操作がありません。'); return; }
  proRestore(s.data);
  proToast(`「${s.label}」を元に戻しました。再読み込みします。`);
  setTimeout(() => location.reload(), 600);
}

/* 破壊的操作の直前にスナップショットを取る（キャプチャ段階で先に実行）
   ※ デッキ削除は「科目（タグ）の後始末」も行うため、専用ハンドラで扱う */
const PRO_DESTRUCTIVE = [
  '#todoClearDone', '#reviewClearDone', '#settingsResetAll',
  '.todo-delete', '.event-delete', '.habit-edit-btn', '.pro-del', '.session-del',
];

function proLabelFor(el) {
  if (!el) return '削除';
  if (el.id === 'todoClearDone') return '完了ToDoの削除';
  if (el.id === 'reviewClearDone') return '完了済み復習の削除';
  if (el.id === 'settingsResetAll') return '設定リセット';
  if (el.classList.contains('session-del')) return '学習記録の削除';
  return '削除';
}

document.addEventListener('click', (e) => {
  const t = e.target.closest(PRO_DESTRUCTIVE.join(','));
  if (!t) return;
  // カードの「✏️ 編集」は削除ではないので対象外
  if (t.classList.contains('card-edit-btn')) return;
  const label = proLabelFor(t);
  proPushUndo(label);
  const explicit = ['todoClearDone', 'reviewClearDone', 'settingsResetAll'].includes(t.id);
  setTimeout(() => {
    // 実際に消えた（再描画でDOMから外れた）か、明示的な破壊操作のときだけ通知
    if (explicit || !t.isConnected) {
      proToast(`${label}を実行しました。`, '元に戻す', proUndoLast, 6000);
    }
  }, 60);
}, true);

document.addEventListener('keydown', (e) => {
  const tag = (e.target.tagName || '').toLowerCase();
  if (tag === 'input' || tag === 'textarea' || tag === 'select' || e.target.isContentEditable) return;
  if ((e.ctrlKey || e.metaKey) && (e.key === 'z' || e.key === 'Z')) {
    e.preventDefault();
    proUndoLast();
  }
});

/* ストレージ容量超過（画像カード等）を検知して警告 */
let proQuotaWarned = false;
(function patchStorage() {
  try {
    const orig = Storage.prototype.setItem;
    Storage.prototype.setItem = function (k, v) {
      try {
        return orig.call(this, k, v);
      } catch (err) {
        if (!proQuotaWarned) {
          proQuotaWarned = true;
          proToast('⚠️ 保存に失敗しました。ストレージの空きが不足しています（画像を減らす／バックアップ後に整理してください）。', null, null, 9000);
        }
        throw err;
      }
    };
  } catch (e) { /* 無視 */ }
})();

/* ============================================================
   2. S3 学習時間の手動入力・編集・削除
   ============================================================ */
function proEnsureSessionIds() {
  let changed = false;
  study.sessions.forEach((s) => { if (!s.id) { s.id = proUid(); changed = true; } });
  if (changed) saveStudy();
}

function proAfterStudyChange() {
  try { renderStudy(); } catch (e) {}
  try { updateStreak(); } catch (e) {}
  try { renderHeatmap(); } catch (e) {}
  try { renderReports(); } catch (e) {}
  try { renderStats(); } catch (e) {}
  try { renderPieChart(); } catch (e) {}
  try { renderGoals(); } catch (e) {}
  proRenderSessionList();
}

function proApplySessionDelta(date, subject, sec) {
  if (sec === 0) return;
  study.byDate[date] = Math.max(0, (study.byDate[date] || 0) + sec);
  if (!study.byDate[date]) delete study.byDate[date];
  const sj = subject || '未分類';
  study.bySubject[sj] = Math.max(0, (study.bySubject[sj] || 0) + sec);
  if (!study.bySubject[sj]) delete study.bySubject[sj];
}

function proAddManualStudy(dateKey, subject, minutes, memo) {
  const sec = Math.round((Number(minutes) || 0) * 60);
  if (sec <= 0) return false;
  proApplySessionDelta(dateKey, subject, sec);
  study.sessions.push({ id: proUid(), date: dateKey, sec, at: Date.now(), subject: subject || '未分類', memo: memo || '', src: 'manual-edit' });
  saveStudy();
  return true;
}

function proEditStudySession(id, dateKey, subject, minutes, memo) {
  const s = study.sessions.find((x) => x.id === id);
  if (!s) return false;
  const sec = Math.round((Number(minutes) || 0) * 60);
  if (sec <= 0) return false;
  proApplySessionDelta(s.date, s.subject, -s.sec); // 旧分を戻す
  proApplySessionDelta(dateKey, subject, sec);       // 新分を適用
  s.date = dateKey; s.subject = subject || '未分類'; s.sec = sec; s.memo = memo || '';
  saveStudy();
  return true;
}

function proDeleteStudySession(id) {
  const i = study.sessions.findIndex((x) => x.id === id);
  if (i < 0) return;
  const s = study.sessions[i];
  proApplySessionDelta(s.date, s.subject, -s.sec);
  study.sessions.splice(i, 1);
  saveStudy();
  proAfterStudyChange();
}

function proSrcIcon(src) {
  return { pomodoro: '🍅', flashcard: '🃏', 'manual-edit': '✍️', manual: '📖' }[src] || '📖';
}

function proRenderSessionList() {
  const box = document.getElementById('studySessionList');
  if (!box) return;
  proEnsureSessionIds();
  const list = study.sessions.slice().sort((a, b) => (b.at || 0) - (a.at || 0)).slice(0, 150);
  if (list.length === 0) { box.innerHTML = '<p class="hint">記録がありません。</p>'; return; }
  box.innerHTML = '';
  list.forEach((s) => {
    const row = document.createElement('div');
    row.className = 'session-item';
    const info = document.createElement('div');
    info.className = 'session-info';
    const when = `${s.date.replace(/-/g, '/')} ${(s.at ? new Date(s.at) : new Date()).toTimeString().slice(0, 5)}`;
    info.innerHTML =
      `<span class="session-time">${proSrcIcon(s.src)} ${fmtHMS(s.sec)}</span>` +
      `<span class="review-subject-tag">${proEsc(s.subject || '未分類')}</span>` +
      `<span class="session-when">${when}</span>`;
    if (s.memo) {
      const m = document.createElement('span');
      m.className = 'session-memo';
      m.textContent = s.memo;
      info.appendChild(m);
    }
    const edit = document.createElement('button');
    edit.className = 'review-do-btn';
    edit.textContent = '✏️';
    edit.title = '編集';
    edit.addEventListener('click', () => proOpenManualModal(s.id));
    const del = document.createElement('button');
    del.className = 'todo-delete session-del';
    del.textContent = '✕';
    del.title = '削除';
    del.addEventListener('click', () => {
      if (confirm('この学習記録を削除しますか？')) proDeleteStudySession(s.id);
    });
    row.appendChild(info);
    row.appendChild(edit);
    row.appendChild(del);
    box.appendChild(row);
  });
}

let proManualEditingId = null;

function proOpenManualModal(editId) {
  const modal = document.getElementById('manualStudyModal');
  if (!modal) return;
  proManualEditingId = editId || null;
  const title = document.getElementById('manualStudyTitle');
  const dEl = document.getElementById('manualDate');
  const sEl = document.getElementById('manualSubject');
  const mEl = document.getElementById('manualMinutes');
  const memoEl = document.getElementById('manualMemo');
  if (editId) {
    const s = study.sessions.find((x) => x.id === editId);
    if (title) title.textContent = '✏️ 学習記録を編集';
    if (s) {
      dEl.value = s.date;
      sEl.value = s.subject || '未分類';
      mEl.value = Math.max(1, Math.round(s.sec / 60));
      memoEl.value = s.memo || '';
    }
  } else {
    if (title) title.textContent = '➕ 学習を手動で記録';
    dEl.value = todayKey();
    mEl.value = 30;
    memoEl.value = '';
  }
  modal.classList.remove('hidden');
}

function proCloseManualModal() {
  const modal = document.getElementById('manualStudyModal');
  if (modal) modal.classList.add('hidden');
  proManualEditingId = null;
}

function proSaveManualModal() {
  const dateKey = document.getElementById('manualDate').value || todayKey();
  const subject = document.getElementById('manualSubject').value || '未分類';
  const minutes = Number(document.getElementById('manualMinutes').value) || 0;
  const memo = document.getElementById('manualMemo').value.trim();
  if (minutes <= 0) { alert('学習時間（分）を1以上で入力してください。'); return; }
  const ok = proManualEditingId
    ? proEditStudySession(proManualEditingId, dateKey, subject, minutes, memo)
    : proAddManualStudy(dateKey, subject, minutes, memo);
  if (!ok) { alert('記録できませんでした。'); return; }
  proCloseManualModal();
  proAfterStudyChange();
  proToast(`${dateKey.replace(/-/g, '/')} に ${minutes}分 を記録しました。`);
}

/* ============================================================
   3. S1 Anki（テキスト書き出し）取り込み
   ============================================================ */
function proStripHtml(s) {
  return String(s == null ? '' : s)
    .replace(/<br\s*\/?>/gi, ' / ')
    .replace(/<\/(p|div|li|tr)>/gi, ' / ')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

function proParseAnkiToPreview(text) {
  const src = String(text == null ? '' : text);
  let sep = '\t';
  const meta = [];
  src.split(/\r?\n/).forEach((ln) => { if (/^#/.test(ln)) meta.push(ln); });
  meta.forEach((ln) => {
    const m = ln.match(/^#separator:(.*)$/i);
    if (m) {
      const v = (m[1] || '').trim().toLowerCase();
      if (v.indexOf('tab') >= 0) sep = '\t';
      else if (v.indexOf('comma') >= 0) sep = ',';
      else if (v.indexOf('semicolon') >= 0) sep = ';';
      else if (v.length) sep = v;
    }
  });
  const body = src.split(/\r?\n/).filter((ln) => !/^#/.test(ln)).join('\n');
  const rows = fcParseDelimited(body, sep);
  const out = [];
  rows.forEach((r) => {
    if (!r || r.length === 0) return;
    const cells = r.map((c) => proStripHtml(c));
    if (cells.every((c) => !c)) return;
    const front = cells[0] || '';
    let back = cells[1] || '';
    let note = cells[2] || '';
    if (cells.length > 3) note = note || cells.slice(1, -1).join(' ');
    if (!front && !back) return;
    out.push(fcCsvEscape(front) + ', ' + fcCsvEscape(back) + (note ? ', ' + fcCsvEscape(note) : ''));
  });
  return out.join('\n');
}

/* ============================================================
   4. S2 穴埋め(Cloze) & B4 数式ライト描画
   ============================================================ */
function proMathToHTML(expr) {
  let s = String(expr == null ? '' : expr);
  const sym = {
    '\\times': '×', '\\div': '÷', '\\cdot': '·', '\\pm': '±', '\\mp': '∓',
    '\\leq': '≤', '\\le': '≤', '\\geq': '≥', '\\ge': '≥', '\\neq': '≠', '\\ne': '≠',
    '\\approx': '≈', '\\equiv': '≡', '\\infty': '∞', '\\rightarrow': '→', '\\to': '→',
    '\\leftarrow': '←', '\\Rightarrow': '⇒', '\\sum': 'Σ', '\\prod': '∏',
    '\\int': '∫', '\\partial': '∂', '\\nabla': '∇', '\\angle': '∠', '\\perp': '⊥',
    '\\parallel': '∥', '\\in': '∈', '\\notin': '∉', '\\subset': '⊂', '\\cup': '∪',
    '\\cap': '∩', '\\therefore': '∴', '\\because': '∵',
  };
  const greek = {
    alpha: 'α', beta: 'β', gamma: 'γ', delta: 'δ', epsilon: 'ε', zeta: 'ζ', eta: 'η',
    theta: 'θ', iota: 'ι', kappa: 'κ', lambda: 'λ', mu: 'μ', nu: 'ν', xi: 'ξ', pi: 'π',
    rho: 'ρ', sigma: 'σ', tau: 'τ', upsilon: 'υ', phi: 'φ', chi: 'χ', psi: 'ψ', omega: 'ω',
    Gamma: 'Γ', Delta: 'Δ', Theta: 'Θ', Lambda: 'Λ', Xi: 'Ξ', Pi: 'Π', Sigma: 'Σ',
    Phi: 'Φ', Psi: 'Ψ', Omega: 'Ω',
  };
  s = s.replace(/\\left|\\right/g, '').replace(/\\!|\\,|\\;|\\:/g, ' ');
  s = s.replace(/\\frac\s*\{([^{}]*)\}\s*\{([^{}]*)\}/g, '<span class="frac"><span class="frac-num">$1</span><span class="frac-den">$2</span></span>');
  s = s.replace(/\\sqrt\s*\{([^{}]*)\}/g, '<span class="sqrtsym">√<span class="sqrt-in">$1</span></span>');
  s = s.replace(/\\text\s*\{([^{}]*)\}/g, '$1').replace(/\\mathrm\s*\{([^{}]*)\}/g, '$1');
  Object.keys(sym).sort((a, b) => b.length - a.length).forEach((k) => { s = s.split(k).join(sym[k]); });
  s = s.replace(/\\([A-Za-z]+)/g, (m, name) => (greek[name] !== undefined ? greek[name] : name));
  s = s.replace(/\^\{([^{}]*)\}/g, '<sup>$1</sup>').replace(/\^(\S)/g, '<sup>$1</sup>');
  s = s.replace(/_\{([^{}]*)\}/g, '<sub>$1</sub>').replace(/_(\S)/g, '<sub>$1</sub>');
  s = s.replace(/[{}]/g, '');
  return s;
}

function proEsc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function proRichHTML(text) {
  let s = proEsc(String(text == null ? '' : text));
  s = s.replace(/\$\$([^$]+?)\$\$/g, (m, e) => '<span class="math-block">' + proMathToHTML(e) + '</span>');
  s = s.replace(/\$([^$\n]+?)\$/g, (m, e) => '<span class="math-inline">' + proMathToHTML(e) + '</span>');
  s = s.replace(/\n/g, '<br>');
  return s;
}

function proClozeHTML(text, reveal) {
  let s = proEsc(String(text == null ? '' : text));
  s = s.replace(/\{\{c\d+::([^{}]*)\}\}/g, (m, ans) =>
    reveal ? '<span class="cloze-ans">' + ans + '</span>' : '<span class="cloze-blank">[ …… ]</span>');
  s = s.replace(/\$\$([^$]+?)\$\$/g, (m, e) => '<span class="math-block">' + proMathToHTML(e) + '</span>');
  s = s.replace(/\$([^$\n]+?)\$/g, (m, e) => '<span class="math-inline">' + proMathToHTML(e) + '</span>');
  s = s.replace(/\n/g, '<br>');
  return s;
}

function proIsCloze(card) {
  return !!(card && (card.type === 'cloze') && /\{\{c\d+::/.test(String(card.front || '')));
}

function proNorm(s) {
  return String(s == null ? '' : s).toLowerCase()
    .replace(/\s+/g, '')
    .replace(/[。、．，,.!?！？・「」『』（）()\[\]{}'"“”‘’]/g, '');
}

function proAnswerList(card) {
  if (!card) return [];
  if (proIsCloze(card)) {
    const m = [...String(card.front || '').matchAll(/\{\{c\d+::([^{}]*)\}\}/g)].map((x) => x[1]);
    return m.length ? m : [card.back || ''];
  }
  return [card.back || ''];
}

function proCardAnswer(card) {
  return proAnswerList(card).join(' / ');
}

/* ============================================================
   5. B5 画像カード（IndexedDB / Blob保存）
   ============================================================ */
const proIdb = { db: null };

function proOpenIdb() {
  return new Promise((resolve, reject) => {
    if (proIdb.db) return resolve(proIdb.db);
    if (!('indexedDB' in window)) return reject(new Error('IndexedDB未対応'));
    const req = indexedDB.open('study_dashboard_files', 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains('images')) db.createObjectStore('images', { keyPath: 'id' });
    };
    req.onsuccess = () => { proIdb.db = req.result; resolve(proIdb.db); };
    req.onerror = () => reject(req.error);
  });
}

async function proPutImage(file) {
  const db = await proOpenIdb();
  const id = proUid();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('images', 'readwrite');
    tx.objectStore('images').put({ id, blob: file, name: file.name, type: file.type });
    tx.oncomplete = () => resolve(id);
    tx.onerror = () => reject(tx.error);
  });
}

const proImgCache = {};

async function proGetImageURL(id) {
  if (!id) return null;
  if (proImgCache[id]) return proImgCache[id];
  try {
    const db = await proOpenIdb();
    const url = await new Promise((resolve, reject) => {
      const tx = db.transaction('images', 'readonly');
      const rq = tx.objectStore('images').get(id);
      rq.onsuccess = () => {
        const v = rq.result;
        resolve(v && v.blob ? URL.createObjectURL(v.blob) : null);
      };
      rq.onerror = () => reject(rq.error);
    });
    if (url) proImgCache[id] = url;
    return url;
  } catch (e) { return null; }
}

async function proDeleteImage(id) {
  if (!id) return;
  try {
    const db = await proOpenIdb();
    const tx = db.transaction('images', 'readwrite');
    tx.objectStore('images').delete(id);
  } catch (e) { /* 無視 */ }
  if (proImgCache[id]) { try { URL.revokeObjectURL(proImgCache[id]); } catch (e) {} delete proImgCache[id]; }
}

/* ============================================================
   6. 学習セッション拡張（出題形式 / Cloze / 画像 / Cram / Leech）
   ============================================================ */
let proQuizBusy = false;
let proPendingImageId = null; // カード追加時に添付する画像ID

/* --- 出題カードのフィルタ（Cram・一時停止を考慮） --- */
fcFilteredCards = function () {
  const deck = fcGetDeck(fcStudy.deckId);
  if (!deck) return [];
  const now = Date.now();
  let cards = deck.cards.filter((c) => !c.suspended && !fcStudy.studied.has(c.id));
  if (fcStudy.cram) {
    // 全カード対象（SRSの期限を無視）
  } else if (fcStudy.order === 'due') {
    cards = cards.filter((c) => fcIsDue(c, now));
  } else if (fcStudy.order === 'weak') {
    cards = cards.filter((c) => fcState(c) === 'leech');
  } else if (fcStudy.order === 'new') {
    cards = cards.filter((c) => fcState(c) === 'new');
  }
  return cards;
};

/* --- セッション開始（出題形式・Cram） --- */
const proOrigStartStudy = startStudy;
startStudy = function (deckId, order, proMode) {
  fcStudy.cram = (order === '__cram__');
  if (proMode === undefined) {
    const sel = document.getElementById('deckStudyMode');
    proMode = sel ? sel.value : 'standard';
  }
  fcStudy.proMode = proMode || 'standard';
  proQuizBusy = false;
  const realOrder = fcStudy.cram ? 'all' : (order || 'due');
  proOrigStartStudy(deckId, realOrder);
};

/* --- カード画像の表示 --- */
function proShowCardImage(card) {
  const wrap = document.getElementById('flashImgWrap');
  const img = document.getElementById('flashImg');
  if (!wrap || !img) return;
  wrap.classList.add('hidden');
  img.removeAttribute('src');
  if (!card || !card.img) return;
  const wantId = card.img;
  proGetImageURL(wantId).then((url) => {
    if (!url) return;
    const cur = fcStudy.queue[fcStudy.index];
    if (cur !== card.id) return; // すでに次のカードへ
    img.src = url;
    wrap.classList.remove('hidden');
  }).catch(() => {});
}

function proClearQuizUI() {
  const c = document.getElementById('choiceButtons');
  if (c) { c.classList.add('hidden'); c.innerHTML = ''; }
  const t = document.getElementById('typingArea');
  if (t) t.classList.add('hidden');
  const f = document.getElementById('quizFeedback');
  if (f) { f.classList.add('hidden'); f.textContent = ''; }
  const card = document.getElementById('flashcard');
  if (card) card.classList.remove('no-flip');
  const thumb = document.getElementById('flashImgWrap');
  if (thumb) thumb.classList.remove('hidden');
}

function proBuildChoices(card, deck) {
  const correct = proCardAnswer(card);
  const pool = [];
  deck.cards.forEach((c) => {
    if (c.id === card.id) return;
    const a = proCardAnswer(c);
    if (a && proNorm(a) !== proNorm(correct) && !pool.some((x) => proNorm(x) === proNorm(a))) pool.push(a);
  });
  shuffleArray(pool);
  const opts = [correct].concat(pool.slice(0, 3));
  shuffleArray(opts);
  return opts;
}

function proAnswerQuiz(grade, correctText) {
  proQuizBusy = true;
  const f = document.getElementById('quizFeedback');
  if (f) {
    f.classList.remove('hidden');
    f.className = 'quiz-feedback ' + (grade === 'good' ? 'ok' : 'bad');
    f.textContent = (grade === 'good' ? '⭕ 正解' : '❌ 不正解') + '：' + (correctText || '');
  }
  const card = document.getElementById('flashcard');
  if (card) card.classList.add('flipped');
  fcStudy.flipped = true;
  setTimeout(() => {
    proQuizBusy = false;
    gradeCard(grade);
  }, 900);
}

function proSetupChoice(card, deck) {
  const box = document.getElementById('choiceButtons');
  if (!box) return;
  const opts = proBuildChoices(card, deck);
  box.classList.remove('hidden');
  box.innerHTML = '';
  const correct = proCardAnswer(card);
  opts.forEach((o) => {
    const b = document.createElement('button');
    b.className = 'choice-btn';
    b.textContent = o;
    b.addEventListener('click', () => {
      const ok = proNorm(o) === proNorm(correct);
      [...box.children].forEach((x) => {
        x.disabled = true;
        if (proNorm(x.textContent) === proNorm(correct)) x.classList.add('correct');
      });
      if (!ok) b.classList.add('wrong');
      proAnswerQuiz(ok ? 'good' : 'again', correct);
    });
    box.appendChild(b);
  });
  const hint = document.getElementById('flashHint');
  if (hint) { hint.textContent = '正しい答えを選んでください'; hint.classList.remove('hidden'); }
  const flip = document.getElementById('flashFlip');
  if (flip) flip.classList.add('hidden');
  const cardEl = document.getElementById('flashcard');
  if (cardEl) cardEl.classList.add('no-flip');
}

function proSetupTyping(card) {
  const area = document.getElementById('typingArea');
  if (!area) return;
  area.classList.remove('hidden');
  const inp = document.getElementById('typingInput');
  if (inp) { inp.value = ''; setTimeout(() => inp.focus(), 0); }
  const hint = document.getElementById('flashHint');
  if (hint) { hint.textContent = '答えを入力して Enter（判定）'; hint.classList.remove('hidden'); }
  const flip = document.getElementById('flashFlip');
  if (flip) flip.classList.add('hidden');
  const cardEl = document.getElementById('flashcard');
  if (cardEl) cardEl.classList.add('no-flip');
}

function proCheckTyping() {
  if (proQuizBusy) return;
  const deck = fcGetDeck(fcStudy.deckId);
  const card = deck ? deck.cards.find((c) => c.id === fcStudy.queue[fcStudy.index]) : null;
  if (!card) return;
  const inp = document.getElementById('typingInput');
  const val = inp ? inp.value : '';
  if (!val.trim()) return;
  const answers = proAnswerList(card).filter((a) => a);
  const ok = answers.some((a) => proNorm(a) === proNorm(val)) || proNorm(proCardAnswer(card)).indexOf(proNorm(val)) !== -1;
  proAnswerQuiz(ok ? 'good' : 'again', answers.join(' / '));
}

/* --- 学習カードの描画（Cloze・数式・画像・出題形式） --- */
renderStudyCard = function () {
  const deck = fcGetDeck(fcStudy.deckId);
  if (!deck) { exitStudy(); return; }
  const cardId = fcStudy.queue[fcStudy.index];
  const card = deck.cards.find((c) => c.id === cardId);
  if (!card) { finishStudy(); return; }

  const mode = fcStudy.proMode || 'standard';
  const front = document.getElementById('flashFront');
  const back = document.getElementById('flashBack');
  const cardEl = document.getElementById('flashcard');

  if (cardEl) cardEl.classList.remove('flipped');
  document.getElementById('gradeButtons').classList.add('hidden');
  const flipBtn = document.getElementById('flashFlip');
  if (flipBtn) flipBtn.classList.remove('hidden');
  const hintEl = document.getElementById('flashHint');
  if (hintEl) { hintEl.classList.remove('hidden'); hintEl.textContent = 'クリックまたは スペース で答えを表示'; }
  fcStudy.flipped = false;
  proClearQuizUI();

  if (proIsCloze(card)) {
    front.innerHTML = proClozeHTML(card.front, false);
    back.innerHTML = proClozeHTML(card.front, true) + (card.back ? '<br>' + proRichHTML(card.back) : '');
  } else {
    front.innerHTML = proRichHTML(card.front || '(表なし)');
    back.innerHTML = proRichHTML(card.back || '(裏なし)');
  }
  proShowCardImage(card);

  document.getElementById('studyProgress').textContent = `${fcStudy.index + 1} / ${fcStudy.queue.length}`;
  const gl = document.getElementById('gradeGoodLabel');
  const el = document.getElementById('gradeEasyLabel');
  if (gl) gl.textContent = fcNextIntervalLabel(card, 'good');
  if (el) el.textContent = fcNextIntervalLabel(card, 'easy');

  if (mode === 'choice') proSetupChoice(card, deck);
  else if (mode === 'typing') proSetupTyping(card);
};

/* --- めくり（クイズ形式では無効） --- */
const proOrigFlipCard = flipCard;
flipCard = function () {
  if (fcStudy.proMode && fcStudy.proMode !== 'standard') return;
  proOrigFlipCard();
};

/* --- 採点（Cramでは次回予定を変更しない／クイズ中はロック） --- */
const proOrigGradeCard = gradeCard;
gradeCard = function (g) {
  if (proQuizBusy) return;
  const deck = fcGetDeck(fcStudy.deckId);
  const card = deck ? deck.cards.find((c) => c.id === fcStudy.queue[fcStudy.index]) : null;
  const snap = (card && fcStudy.cram) ? JSON.parse(JSON.stringify(card.srs || {})) : null;
  proClearQuizUI();
  proOrigGradeCard(g);
  if (card && fcStudy.cram) { card.srs = snap; saveFlashcards(); }
};

/* ============================================================
   7. カード一覧・編集（種類 / 単元 / 画像）
   ============================================================ */
buildCardEditRow = function (deck, card) {
  const li = document.createElement('li');
  li.className = 'card-row card-edit-row';

  const fIn = document.createElement('input');
  fIn.type = 'text'; fIn.className = 'memo-input card-edit-input';
  fIn.value = card.front || ''; fIn.placeholder = '表（問題） / 穴埋めは {{c1::答え}}'; fIn.maxLength = 500;

  const bIn = document.createElement('input');
  bIn.type = 'text'; bIn.className = 'memo-input card-edit-input';
  bIn.value = card.back || ''; bIn.placeholder = '裏（答え）'; bIn.maxLength = 500;

  const nIn = document.createElement('input');
  nIn.type = 'text'; nIn.className = 'memo-input card-edit-note';
  nIn.value = card.note || ''; nIn.placeholder = 'メモ（任意）'; nIn.maxLength = 200;

  const uIn = document.createElement('input');
  uIn.type = 'text'; uIn.className = 'memo-input card-edit-unit';
  uIn.value = card.unit || ''; uIn.placeholder = '単元タグ（任意）'; uIn.maxLength = 24;

  const tSel = document.createElement('select');
  tSel.className = 'select-input card-edit-type';
  [['normal', '通常'], ['cloze', '穴埋め']].forEach(([v, label]) => {
    const o = document.createElement('option');
    o.value = v; o.textContent = label;
    if ((card.type || 'normal') === v) o.selected = true;
    tSel.appendChild(o);
  });

  const imgBtn = document.createElement('label');
  imgBtn.className = 'btn btn-small file-btn';
  imgBtn.textContent = card.img ? '🖼 画像変更' : '🖼 画像';
  const imgInput = document.createElement('input');
  imgInput.type = 'file'; imgInput.accept = 'image/*'; imgInput.style.display = 'none';
  imgBtn.appendChild(imgInput);
  let newImgId = card.img || null;
  let clearImg = false;
  imgInput.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    try { newImgId = await proPutImage(file); clearImg = false; imgBtn.textContent = '🖼 画像を設定済み'; }
    catch (err) { alert('画像を保存できませんでした（ストレージ不足の可能性）。'); }
    e.target.value = '';
  });
  const imgClear = document.createElement('button');
  imgClear.className = 'btn btn-small';
  imgClear.textContent = '画像を削除';
  imgClear.addEventListener('click', () => { clearImg = true; newImgId = null; imgBtn.textContent = '🖼 画像'; });

  const save = document.createElement('button');
  save.className = 'btn btn-small btn-primary';
  save.textContent = '💾 保存';
  const cancel = document.createElement('button');
  cancel.className = 'btn btn-small';
  cancel.textContent = 'キャンセル';

  const commit = () => {
    const prevImg = card.img;
    card.front = fIn.value.trim();
    card.back = bIn.value.trim();
    card.note = nIn.value.trim();
    card.unit = uIn.value.trim();
    card.type = tSel.value;
    if (clearImg) card.img = null;
    else if (newImgId) card.img = newImgId;
    if (prevImg && prevImg !== card.img) proDeleteImage(prevImg);
    saveFlashcards();
    fcEditingId = null;
    renderCardList();
    renderDeckSummary();
    renderTodaySchedule();
  };
  save.addEventListener('click', commit);
  cancel.addEventListener('click', () => { fcEditingId = null; renderCardList(); });
  [fIn, bIn, nIn, uIn].forEach((inp) => {
    inp.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); commit(); }
      else if (e.key === 'Escape') { fcEditingId = null; renderCardList(); }
    });
  });

  const actions = document.createElement('div');
  actions.className = 'card-edit-actions';
  actions.appendChild(save);
  actions.appendChild(cancel);

  li.appendChild(fIn);
  li.appendChild(bIn);
  li.appendChild(nIn);
  li.appendChild(uIn);
  li.appendChild(tSel);
  li.appendChild(imgBtn);
  li.appendChild(imgClear);
  li.appendChild(actions);

  setTimeout(() => fIn.focus(), 0);
  return li;
};

renderCardList = function () {
  const deck = fcGetDeck(fcOpenDeckId);
  const ul = document.getElementById('cardList');
  if (!deck || !ul) return;
  ul.innerHTML = '';
  if (deck.cards.length === 0) {
    ul.innerHTML = '<li class="hint" style="padding:8px 4px;">カードがありません</li>';
    return;
  }
  const now = Date.now();
  deck.cards.forEach((card) => {
    if (card.id === fcEditingId) { ul.appendChild(buildCardEditRow(deck, card)); return; }
    const st = fcState(card);
    const li = document.createElement('li');
    li.className = 'card-row';

    if (card.type === 'cloze') {
      const t = document.createElement('span');
      t.className = 'card-type-badge';
      t.textContent = '穴埋め';
      li.appendChild(t);
    }
    if (card.unit) {
      const u = document.createElement('span');
      u.className = 'card-unit';
      u.textContent = card.unit;
      li.appendChild(u);
    }
    if (card.img) {
      const im = document.createElement('span');
      im.className = 'card-img-badge';
      im.textContent = '🖼';
      im.title = '画像あり';
      li.appendChild(im);
    }
    if (card.suspended) {
      const sp = document.createElement('span');
      sp.className = 'card-suspended-badge';
      sp.textContent = '⏸';
      sp.title = '一時停止中';
      li.appendChild(sp);
    }

    const front = document.createElement('span');
    front.className = 'card-front';
    front.innerHTML = proIsCloze(card) ? proClozeHTML(card.front, false) : proRichHTML(card.front || '(表なし)');

    const back = document.createElement('span');
    back.className = 'card-back';
    back.innerHTML = proRichHTML(card.back || '');

    const badge = document.createElement('span');
    badge.className = 'card-state ' + st;
    badge.textContent = FC_STATE_LABEL[st];

    const dueLbl = document.createElement('span');
    dueLbl.className = 'card-due';
    dueLbl.textContent = fcIsDue(card, now) ? '復習期限' : (card.srs && card.srs.due ? '次回 ' + todayKey(new Date(card.srs.due)) : '');

    const edit = document.createElement('button');
    edit.className = 'todo-delete card-edit-btn';
    edit.textContent = '✏️';
    edit.title = '編集';
    edit.addEventListener('click', () => { fcEditingId = card.id; renderCardList(); });

    const del = document.createElement('button');
    del.className = 'todo-delete';
    del.textContent = '✕';
    del.title = '削除';
    del.addEventListener('click', () => {
      deck.cards = deck.cards.filter((c) => c.id !== card.id);
      if (card.img) proDeleteImage(card.img);
      saveFlashcards();
      renderDeckSummary();
      renderCardList();
      renderDecks();
      renderTodaySchedule();
    });

    li.appendChild(front);
    li.appendChild(back);
    li.appendChild(badge);
    li.appendChild(dueLbl);
    li.appendChild(edit);
    li.appendChild(del);
    li.addEventListener('click', (e) => {
      if (e.target.closest('button')) return;
      fcEditingId = card.id;
      renderCardList();
    });
    ul.appendChild(li);
  });
};

/* ============================================================
   7.5 デッキ削除・名前変更に伴う「科目（タグ）」の後始末
   - デッキ名から自動登録された科目は、デッキを消しても残ってしまうため
     「同名のデッキが他に無い」「既定の科目でない」「科目が1つだけにならない」
     ときだけ自動で取り除く（学習記録の履歴・この操作は Undo で戻せます）。
   - ついでに、デッキ移動時に残りがちな「単元タグ入力」をクリアする。
   ============================================================ */
function proIsDefaultSubject(name) {
  return (typeof DEFAULT_SUBJECTS !== 'undefined') && DEFAULT_SUBJECTS.indexOf(name) !== -1;
}

function proCleanupSubjectForDeckName(name) {
  if (!name) return false;
  if (proIsDefaultSubject(name)) return false;             // 既定科目は消さない
  if (subjects.indexOf(name) === -1) return false;         // そもそも科目でない
  if (flashcards.decks.some((d) => d.name === name)) return false; // 他に同じ名前のデッキが残っていれば保持
  if (subjects.length <= 1) return false;                  // 最低1科目は維持
  subjects.splice(subjects.indexOf(name), 1);
  saveSubjects();
  if (proSubjectGoals[name] !== undefined) {
    delete proSubjectGoals[name];
    proSaveJSON(PRO_KEYS.subjectGoals, proSubjectGoals);
  }
  try { renderSubjectManage(); } catch (e) {}
  try { populateSubjectSelects(); } catch (e) {}
  try { proRenderSubjectGoals(); } catch (e) {}
  return true;
}

/* デッキ詳細で使う「カード追加」の入力（単元タグ・画像）をクリア */
function proClearCardAddInputs() {
  proPendingImageId = null;
  const u = document.getElementById('cardUnit'); if (u) u.value = '';
  const nm = document.getElementById('cardImageName'); if (nm) nm.textContent = '';
  const t = document.getElementById('cardType'); if (t) t.value = 'normal';
}

/* デッキを開くたびに前回の入力を持ち越さない */
const proOrigOpenDeck = openDeck;
openDeck = function (id) {
  proClearCardAddInputs();
  proOrigOpenDeck(id);
};

/* デッキ削除 → 孤児になった科目（タグ）と科目別目標を片付ける */
document.addEventListener('click', (e) => {
  const btn = e.target.closest('#deckDelete');
  if (!btn) return;
  const deck = (typeof fcGetDeck === 'function' && fcOpenDeckId) ? fcGetDeck(fcOpenDeckId) : null;
  if (!deck) return;
  const name = deck.name;
  proPushUndo('デッキ削除');
  setTimeout(() => {
    // 削除が実際に行われたか（デッキが消えたか）を確認
    const removed = !flashcards.decks.some((d) => d.id === deck.id);
    if (!removed) return; // キャンセルされた
    const cleaned = proCleanupSubjectForDeckName(name);
    // 受験タブを開いていたら予測・苦手カードなども更新
    const examPanel = document.getElementById('tab-exam');
    if (examPanel && examPanel.classList.contains('active')) {
      try { proRenderForecast(); proRenderLeech(); proRenderUnitAnalysis(); } catch (e) {}
    }
    proToast(
      cleaned ? `デッキと科目「${name}」を削除しました。`
              : 'デッキを削除しました。',
      '元に戻す', proUndoLast, 6000
    );
  }, 80);
}, true);

/* デッキ名変更 → 旧名の科目（タグ）が孤児なら片付ける */
document.addEventListener('click', (e) => {
  const btn = e.target.closest('#deckRename');
  if (!btn) return;
  const deck = fcOpenDeckId ? fcGetDeck(fcOpenDeckId) : null;
  if (!deck) return;
  const oldName = deck.name;
  setTimeout(() => {
    const d = fcGetDeck(fcOpenDeckId);
    if (d && d.name !== oldName) proCleanupSubjectForDeckName(oldName);
  }, 300);
}, true);

/* ============================================================
   8. A2 試験日カウントダウン
   ============================================================ */
function proDaysUntil(dateStr) {
  const target = new Date(dateStr + 'T00:00:00');
  const today = new Date(todayKey() + 'T00:00:00');
  return Math.round((target - today) / 86400000);
}

function proRenderCountdownBanner() {
  const el = document.getElementById('countdownBanner');
  if (!el) return;
  const upcoming = proExamDates
    .map((d) => ({ ...d, days: proDaysUntil(d.date) }))
    .filter((d) => d.days >= 0)
    .sort((a, b) => a.days - b.days);
  if (upcoming.length === 0) { el.classList.add('hidden'); return; }
  el.classList.remove('hidden');
  const main = upcoming[0];
  el.innerHTML =
    `<div class="countdown-main"><span class="countdown-label">${proEsc(main.label)}</span>` +
    `<span class="countdown-days">あと <b>${main.days}</b> 日</span></div>` +
    (upcoming.length > 1
      ? `<div class="countdown-sub">${upcoming.slice(1, 4).map((d) => `${proEsc(d.label)} あと${d.days}日`).join(' ・ ')}</div>`
      : '');
}

function proRenderExamDates() {
  const box = document.getElementById('examCountdownList');
  if (!box) return;
  const list = proExamDates.slice().sort((a, b) => (a.date < b.date ? -1 : 1));
  if (list.length === 0) { box.innerHTML = '<p class="hint">試験日が登録されていません。</p>'; return; }
  box.innerHTML = '';
  list.forEach((d) => {
    const days = proDaysUntil(d.date);
    const row = document.createElement('div');
    row.className = 'countdown-item' + (days < 0 ? ' past' : (days <= 30 ? ' soon' : ''));
    const info = document.createElement('div');
    info.className = 'session-info';
    info.innerHTML = `<span class="countdown-item-label">${proEsc(d.label)}</span>` +
      `<span class="session-when">${d.date.replace(/-/g, '/')}</span>`;
    const tag = document.createElement('span');
    tag.className = 'review-subject-tag';
    tag.textContent = days >= 0 ? `あと ${days} 日` : '終了';
    const del = document.createElement('button');
    del.className = 'todo-delete pro-del';
    del.textContent = '✕';
    del.addEventListener('click', () => {
      proExamDates = proExamDates.filter((x) => x.id !== d.id);
      proSaveJSON(PRO_KEYS.examDates, proExamDates);
      proRenderExamDates(); proRenderCountdownBanner();
    });
    row.appendChild(info);
    row.appendChild(tag);
    row.appendChild(del);
    box.appendChild(row);
  });
}

function proAddExamDate() {
  const label = document.getElementById('examDateLabel').value.trim();
  const date = document.getElementById('examDateInput').value;
  if (!label || !date) { alert('名称と日付を入力してください。'); return; }
  proExamDates.push({ id: proUid(), label, date });
  proSaveJSON(PRO_KEYS.examDates, proExamDates);
  document.getElementById('examDateLabel').value = '';
  document.getElementById('examDateInput').value = '';
  proRenderExamDates(); proRenderCountdownBanner();
}

/* ============================================================
   9. A1 模試・過去問の得点管理
   ============================================================ */
function proRenderExamScoreList() {
  const box = document.getElementById('examScoreList');
  if (!box) return;
  if (proExamScores.length === 0) { box.innerHTML = '<p class="hint">記録がありません。模試や過去問の得点を記録しましょう。</p>'; return; }
  const list = proExamScores.slice().sort((a, b) => (a.date < b.date ? 1 : -1));
  box.innerHTML = '';
  list.forEach((r) => {
    const pct = r.max > 0 ? Math.round((r.score / r.max) * 100) : null;
    const row = document.createElement('div');
    row.className = 'session-item';
    const info = document.createElement('div');
    info.className = 'session-info';
    info.innerHTML = `<span class="review-subject-tag">${proEsc(r.subject || '未分類')}</span>` +
      `<span class="session-when">${(r.date || '').replace(/-/g, '/')}</span>` +
      `<span class="session-memo">${proEsc(r.name || '')}</span>`;
    const val = document.createElement('span');
    val.className = 'exam-score-val';
    val.textContent = `${r.score}${r.max ? ' / ' + r.max : ''}${pct !== null ? '（' + pct + '%）' : ''}${r.dev ? ' 偏差' + r.dev : ''}`;
    const del = document.createElement('button');
    del.className = 'todo-delete pro-del';
    del.textContent = '✕';
    del.addEventListener('click', () => {
      proExamScores = proExamScores.filter((x) => x.id !== r.id);
      proSaveJSON(PRO_KEYS.examScores, proExamScores);
      proRenderExamScoresSection();
    });
    row.appendChild(info);
    row.appendChild(val);
    row.appendChild(del);
    box.appendChild(row);
  });
}

function proAddExamScore() {
  const name = document.getElementById('examName').value.trim();
  const date = document.getElementById('examDate2').value || todayKey();
  const subject = document.getElementById('examScoreSubject').value || '未分類';
  const score = Number(document.getElementById('examScoreValue').value);
  const max = Number(document.getElementById('examScoreMax').value) || 0;
  const dev = Number(document.getElementById('examDev').value) || null;
  if (!name) { alert('模試名を入力してください。'); return; }
  if (!isFinite(score)) { alert('得点を入力してください。'); return; }
  proExamScores.push({ id: proUid(), name, date, subject, score, max, dev });
  proSaveJSON(PRO_KEYS.examScores, proExamScores);
  ['examName', 'examScoreValue', 'examScoreMax', 'examDev'].forEach((id) => { const el = document.getElementById(id); if (el) el.value = ''; });
  proRenderExamScoresSection();
}

function proDrawExamChart() {
  const canvas = document.getElementById('examScoreCanvas');
  if (!canvas) return;
  const ctx = fitCanvas(canvas);
  if (!ctx) return;
  const W = canvas.clientWidth, H = canvas.clientHeight;
  const padL = 36, padR = 14, padT = 14, padB = 26;
  const plotW = W - padL - padR, plotH = H - padT - padB;
  ctx.clearRect(0, 0, W, H);
  const css = getComputedStyle(document.body);
  const textDim = css.getPropertyValue('--text-dim').trim() || '#999';
  const accent = css.getPropertyValue('--accent').trim() || '#6c8cff';

  ctx.strokeStyle = 'rgba(128,128,128,0.25)';
  ctx.fillStyle = textDim;
  ctx.font = '10px sans-serif';
  [0, 0.5, 1].forEach((v) => {
    const y = padT + plotH * (1 - v);
    ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(W - padR, y); ctx.stroke();
    ctx.fillText(Math.round(v * 100) + '%', 6, y + 3);
  });

  const sel = document.getElementById('examChartSubject');
  const scope = sel ? sel.value : 'all';
  let pts = [];
  if (scope === 'all') {
    const byDate = {};
    proExamScores.forEach((r) => {
      if (!(r.max > 0)) return;
      if (!byDate[r.date]) byDate[r.date] = { sum: 0, n: 0 };
      byDate[r.date].sum += r.score / r.max; byDate[r.date].n++;
    });
    pts = Object.keys(byDate).map((k) => ({ x: k, y: byDate[k].sum / byDate[k].n })).sort((a, b) => a.x < b.x ? -1 : 1);
  } else {
    pts = proExamScores.filter((r) => r.subject === scope && r.max > 0)
      .map((r) => ({ x: r.date, y: r.score / r.max })).sort((a, b) => a.x < b.x ? -1 : 1);
  }

  if (pts.length === 0) {
    ctx.fillStyle = textDim;
    ctx.fillText('データがありません', padL, padT + plotH / 2);
    return;
  }

  const n = pts.length;
  const xAt = (i) => padL + (n <= 1 ? plotW / 2 : (plotW * i) / (n - 1));
  const yAt = (v) => padT + plotH * (1 - Math.max(0, Math.min(1, v)));

  ctx.strokeStyle = accent; ctx.lineWidth = 2;
  ctx.beginPath();
  pts.forEach((p, i) => { const px = xAt(i), py = yAt(p.y); if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py); });
  ctx.stroke();
  pts.forEach((p, i) => {
    ctx.fillStyle = accent;
    ctx.beginPath(); ctx.arc(xAt(i), yAt(p.y), 3, 0, Math.PI * 2); ctx.fill();
    if (n <= 8) { ctx.fillStyle = textDim; ctx.fillText(Math.round(p.y * 100) + '%', xAt(i) - 10, yAt(p.y) - 6); }
  });
  ctx.fillStyle = textDim;
  [0, Math.floor((n - 1) / 2), n - 1].forEach((i) => {
    if (i < 0) return;
    const k = (pts[i].x || '').slice(5).replace('-', '/');
    ctx.fillText(k, Math.max(2, Math.min(W - 30, xAt(i) - 12)), H - 8);
  });
}

function proRenderExamScoresSection() {
  const sel = document.getElementById('examChartSubject');
  if (sel) {
    const prev = sel.value;
    sel.innerHTML = '';
    const allOpt = document.createElement('option');
    allOpt.value = 'all'; allOpt.textContent = '全科目（平均）';
    sel.appendChild(allOpt);
    const used = [...new Set(proExamScores.map((r) => r.subject))];
    (used.length ? used : subjects).forEach((s) => {
      const o = document.createElement('option'); o.value = s; o.textContent = s; sel.appendChild(o);
    });
    if (prev && [...sel.options].some((o) => o.value === prev)) sel.value = prev;
  }
  proRenderExamScoreList();
  proDrawExamChart();
}

/* ============================================================
   10. A4 復習負荷の予測
   ============================================================ */
function proRenderForecast() {
  const canvas = document.getElementById('forecastCanvas');
  if (!canvas) return;
  const ctx = fitCanvas(canvas);
  if (!ctx) return;
  const W = canvas.clientWidth, H = canvas.clientHeight;
  const padL = 30, padR = 12, padT = 14, padB = 26;
  const plotW = W - padL - padR, plotH = H - padT - padB;
  ctx.clearRect(0, 0, W, H);
  const css = getComputedStyle(document.body);
  const textDim = css.getPropertyValue('--text-dim').trim() || '#999';

  const days = 14;
  const counts = new Array(days).fill(0);
  const todayStart = new Date(todayKey() + 'T00:00:00').getTime();
  flashcards.decks.forEach((deck) => {
    deck.cards.forEach((c) => {
      if (c.suspended) return;
      const due = (c.srs && c.srs.due) || 0;
      let idx = Math.floor((due - todayStart) / 86400000);
      if (idx < 0) idx = 0;
      if (idx < days) counts[idx]++;
    });
  });
  const maxN = Math.max(1, ...counts);

  ctx.strokeStyle = 'rgba(128,128,128,0.25)';
  ctx.fillStyle = textDim;
  ctx.font = '10px sans-serif';
  ctx.beginPath(); ctx.moveTo(padL, padT); ctx.lineTo(padL, padT + plotH); ctx.lineTo(W - padR, padT + plotH); ctx.stroke();
  ctx.fillText(String(maxN), 4, padT + 8);
  ctx.fillText('0', 4, padT + plotH);

  const slot = plotW / days;
  const bw = Math.max(4, slot * 0.7);
  counts.forEach((n, i) => {
    const h = (n / maxN) * plotH;
    const x = padL + slot * i + (slot - bw) / 2;
    ctx.fillStyle = i === 0 ? '#ffb86c' : '#6c8cff';
    ctx.fillRect(x, padT + plotH - h, bw, h);
    if (n > 0) { ctx.fillStyle = textDim; ctx.fillText(String(n), x + bw / 2 - 3, padT + plotH - h - 3); }
  });
  ctx.fillStyle = textDim;
  [0, 6, 13].forEach((i) => {
    const d = new Date(todayStart + i * 86400000);
    const lbl = `${d.getMonth() + 1}/${d.getDate()}`;
    ctx.fillText(lbl, Math.min(W - 26, padL + slot * i + 2), H - 8);
  });
}

/* ============================================================
   11. B1 苦手カード（Leech）
   ============================================================ */
function proLeechCards() {
  const out = [];
  flashcards.decks.forEach((deck) => {
    deck.cards.forEach((c) => {
      if (fcState(c) === 'leech') out.push({ deck, card: c });
    });
  });
  return out;
}

function proRenderLeech() {
  const box = document.getElementById('leechList');
  if (!box) return;
  const items = proLeechCards();
  if (items.length === 0) { box.innerHTML = '<p class="hint">苦手カードはありません。順調です！</p>'; return; }
  box.innerHTML = '';
  items.forEach(({ deck, card }) => {
    const lapses = (card.srs && card.srs.lapses) || 0;
    const row = document.createElement('div');
    row.className = 'session-item';
    const info = document.createElement('div');
    info.className = 'session-info';
    info.innerHTML = `<span class="card-front">${proEsc(String(card.front || '(表なし)')).slice(0, 60)}</span>` +
      `<span class="review-subject-tag">${proEsc(deck.name)}</span>` +
      `<span class="session-when">失敗 ${lapses} 回</span>`;
    const btn = document.createElement('button');
    btn.className = 'review-do-btn';
    btn.textContent = card.suspended ? '▶ 再開' : '⏸ 一時停止';
    btn.title = '一時停止すると出題対象から外れます';
    btn.addEventListener('click', () => {
      card.suspended = !card.suspended;
      saveFlashcards();
      proRenderLeech();
      renderDecks();
    });
    const open = document.createElement('button');
    open.className = 'review-do-btn';
    open.textContent = '開く';
    open.addEventListener('click', () => { showTab('cards'); openDeck(deck.id); });
    row.appendChild(info);
    row.appendChild(btn);
    row.appendChild(open);
    box.appendChild(row);
  });
}

/* ============================================================
   12. B2 単元タグ別の分析
   ============================================================ */
function proRenderUnitAnalysis() {
  const box = document.getElementById('unitAnalysis');
  if (!box) return;
  const map = {};
  flashcards.decks.forEach((deck) => {
    deck.cards.forEach((c) => {
      const u = (c.unit || '').trim() || '（未設定）';
      if (!map[u]) map[u] = { cards: 0, attempts: 0, ok: 0 };
      map[u].cards++;
      (c.history || []).forEach((h) => { map[u].attempts++; if (h.ok) map[u].ok++; });
    });
  });
  const rows = Object.keys(map).map((u) => {
    const m = map[u];
    return { unit: u, cards: m.cards, attempts: m.attempts, rate: m.attempts > 0 ? m.ok / m.attempts : null };
  }).sort((a, b) => {
    const ra = a.rate === null ? 2 : a.rate, rb = b.rate === null ? 2 : b.rate;
    return ra - rb;
  });
  if (rows.length === 0) { box.innerHTML = '<p class="hint">カードがありません。</p>'; return; }
  box.innerHTML = '';
  rows.slice(0, 40).forEach((r) => {
    const row = document.createElement('div');
    row.className = 'session-item';
    const info = document.createElement('div');
    info.className = 'session-info';
    info.innerHTML = `<span class="unit-name">${proEsc(r.unit)}</span>` +
      `<span class="session-when">${r.cards}枚・${r.attempts}回</span>`;
    const val = document.createElement('span');
    const ratePct = r.rate === null ? '—' : Math.round(r.rate * 100) + '%';
    val.className = 'unit-rate' + (r.rate !== null && r.rate < 0.7 ? ' low' : (r.rate !== null && r.rate >= 0.9 ? ' high' : ''));
    val.textContent = '正答率 ' + ratePct;
    row.appendChild(info);
    row.appendChild(val);
    box.appendChild(row);
  });
}

/* ============================================================
   13. B7 科目別の目標配分（計画 vs 実績）
   ============================================================ */
function proRenderSubjectGoals() {
  const box = document.getElementById('subjectGoalList');
  if (!box) return;
  const actualSec = (typeof aggregateBySubject === 'function') ? aggregateBySubject('7') : {};
  box.innerHTML = '';
  subjects.forEach((s) => {
    const goal = Number(proSubjectGoals[s]) || 0;
    const actMin = Math.round((actualSec[s] || 0) / 60);
    const row = document.createElement('div');
    row.className = 'subject-goal-row';
    const name = document.createElement('span');
    name.className = 'subject-goal-name';
    name.textContent = s;
    const inp = document.createElement('input');
    inp.type = 'number'; inp.min = '0'; inp.step = '10';
    inp.className = 'num-input';
    inp.value = goal || '';
    inp.placeholder = '目標(分/週)';
    inp.addEventListener('change', () => {
      const v = Math.max(0, Number(inp.value) || 0);
      if (v > 0) proSubjectGoals[s] = v; else delete proSubjectGoals[s];
      proSaveJSON(PRO_KEYS.subjectGoals, proSubjectGoals);
      proRenderSubjectGoals();
    });
    const stat = document.createElement('span');
    stat.className = 'subject-goal-stat';
    if (goal > 0) {
      const diff = actMin - goal;
      const pct = Math.round((actMin / goal) * 100);
      if (diff < -goal * 0.3) { stat.classList.add('low'); stat.textContent = `実績 ${actMin}分（${pct}%）⚠ 不足`; }
      else if (diff > goal * 0.3) { stat.classList.add('high'); stat.textContent = `実績 ${actMin}分（${pct}%）多め`; }
      else { stat.textContent = `実績 ${actMin}分（${pct}%）OK`; }
    } else {
      stat.textContent = `実績 ${actMin}分`;
    }
    row.appendChild(name);
    row.appendChild(inp);
    row.appendChild(stat);
    box.appendChild(row);
  });
  if (subjects.length === 0) box.innerHTML = '<p class="hint">科目が登録されていません（設定 → 科目の管理）。</p>';
}

/* ============================================================
   14. B6 週間時間割 ＋ ポモドーロ・ToDo連動
   ============================================================ */
const PRO_WEEK = ['日', '月', '火', '水', '木', '金', '土'];

function proRenderTimetable() {
  const box = document.getElementById('timetableList');
  if (!box) return;
  if (proTimetable.length === 0) { box.innerHTML = '<p class="hint">時間割が登録されていません。学校・塾・自習の型を登録しましょう。</p>'; return; }
  const todayDow = new Date().getDay();
  box.innerHTML = '';
  for (let d = 0; d < 7; d++) {
    const items = proTimetable.filter((t) => Number(t.day) === d).sort((a, b) => (a.start < b.start ? -1 : 1));
    if (items.length === 0) continue;
    const wrap = document.createElement('div');
    wrap.className = 'tt-day' + (d === todayDow ? ' today' : '');
    const h = document.createElement('div');
    h.className = 'tt-day-head';
    h.textContent = `${PRO_WEEK[d]}曜日${d === todayDow ? '（今日）' : ''}`;
    wrap.appendChild(h);
    items.forEach((t) => {
      const row = document.createElement('div');
      row.className = 'tt-item';
      const time = document.createElement('span');
      time.className = 'tt-time';
      time.textContent = `${t.start} - ${t.end}`;
      const body = document.createElement('span');
      body.className = 'tt-body';
      const tag = document.createElement('span');
      tag.className = 'review-subject-tag';
      tag.textContent = t.subject || '未分類';
      body.appendChild(tag);
      if (t.label) {
        const lb = document.createElement('span');
        lb.className = 'tt-label';
        lb.textContent = t.label;
        body.appendChild(lb);
      }
      const del = document.createElement('button');
      del.className = 'todo-delete pro-del';
      del.textContent = '✕';
      del.addEventListener('click', () => {
        proTimetable = proTimetable.filter((x) => x.id !== t.id);
        proSaveJSON(PRO_KEYS.timetable, proTimetable);
        proRenderTimetable();
      });
      row.appendChild(time);
      row.appendChild(body);
      row.appendChild(del);
      wrap.appendChild(row);
    });
    box.appendChild(wrap);
  }
}

function proAddTimetable() {
  const day = document.getElementById('ttDay').value;
  const start = document.getElementById('ttStart').value;
  const end = document.getElementById('ttEnd').value;
  const subject = document.getElementById('ttSubject').value || '未分類';
  const label = document.getElementById('ttLabel').value.trim();
  if (!start || !end) { alert('開始・終了時刻を入力してください。'); return; }
  proTimetable.push({ id: proUid(), day: Number(day), start, end, subject, label });
  proSaveJSON(PRO_KEYS.timetable, proTimetable);
  document.getElementById('ttLabel').value = '';
  proRenderTimetable();
}

/* ポモドーロで選んだタスクへ学習時間を加算 */
const proOrigAddPomodoroStudySeconds = addPomodoroStudySeconds;
addPomodoroStudySeconds = function (sec) {
  proOrigAddPomodoroStudySeconds(sec);
  try {
    const sel = document.getElementById('pomoTask');
    if (!sel || !sel.value) return;
    const t = todos.find((x) => String(x.id) === String(sel.value));
    if (!t) return;
    t.spentMs = (t.spentMs || 0) + sec * 1000;
    saveTodos();
    renderTodos();
  } catch (e) { /* 無視 */ }
};

function proPopulatePomodoroTasks() {
  const sel = document.getElementById('pomoTask');
  if (!sel) return;
  const prev = sel.value;
  const open = todos.filter((t) => !t.done);
  sel.innerHTML = '<option value="">（なし）</option>';
  open.forEach((t, i) => {
    const o = document.createElement('option');
    o.value = String(t.id === undefined ? 'idx' + i : t.id);
    o.textContent = t.text;
    sel.appendChild(o);
  });
  if (prev && [...sel.options].some((o) => o.value === prev)) sel.value = prev;
}

/* ToDo に学習時間（累計）を表示 */
const proOrigRenderTodos = renderTodos;
renderTodos = function () {
  proOrigRenderTodos();
  try {
    const list = document.getElementById('todoList');
    if (!list) return;
    [...list.children].forEach((li) => {
      const idx = li.dataset.index;
      if (idx === undefined) return;
      const t = todos[Number(idx)];
      if (!t || !t.spentMs) return;
      const badge = document.createElement('span');
      badge.className = 'todo-spent';
      badge.textContent = '⏱ ' + fmtHMS(Math.round(t.spentMs / 1000));
      badge.title = 'この ToDo に紐づく学習時間';
      const del = li.querySelector('.todo-delete');
      if (del) li.insertBefore(badge, del); else li.appendChild(badge);
    });
  } catch (e) { /* 無視 */ }
};

/* ============================================================
   15. B8 毎日のリマインダー通知
   ============================================================ */
function proDueSummary() {
  const today = todayKey();
  const rev = reviews.filter((r) => !r.done && r.nextDate && r.nextDate <= today).length;
  let cardDue = 0;
  flashcards.decks.forEach((d) => { cardDue += fcDeckDueCount(d); });
  const min = Math.floor((study.byDate[today] || 0) / 60);
  return { min, rev, cardDue };
}

function proCheckReminder(force) {
  if (!proReminder.enabled) return;
  if (!settings.notifEnabled) return;
  const now = new Date();
  const cur = `${pad2(now.getHours())}:${pad2(now.getMinutes())}`;
  const today = todayKey();
  if (!force) {
    if (proReminder.lastFired === today) return;
    if (cur < (proReminder.time || '20:00')) return;
  }
  const sum = proDueSummary();
  if (sum.rev === 0 && sum.cardDue === 0 && sum.min >= 30) {
    proReminder.lastFired = today;
    proSaveJSON(PRO_KEYS.reminder, proReminder);
    return;
  }
  const parts = [`今日の学習: ${sum.min}分`];
  if (sum.rev > 0) parts.push(`復習 ${sum.rev}件`);
  if (sum.cardDue > 0) parts.push(`カード ${sum.cardDue}枚`);
  notify('⏰ 今日の学習チェック', parts.join(' / '));
  proReminder.lastFired = today;
  proSaveJSON(PRO_KEYS.reminder, proReminder);
}

function proApplyReminderUI() {
  const t = document.getElementById('reminderToggle');
  const time = document.getElementById('reminderTime');
  if (t) t.checked = !!proReminder.enabled;
  if (time) time.value = proReminder.time || '20:00';
}

/* ============================================================
   16. バックアップ連携 / 科目セレクト拡張 / タブ連携
   ============================================================ */
const proOrigCollectAllData = collectAllData;
collectAllData = function () {
  const d = proOrigCollectAllData();
  d.schemaVersion = 2;
  d.examDates = proExamDates;
  d.examScores = proExamScores;
  d.subjectGoals = proSubjectGoals;
  d.timetable = proTimetable;
  d.reminder = proReminder;
  return d;
};

const proOrigApplyBackupData = applyBackupData;
applyBackupData = function (data) {
  proOrigApplyBackupData(data);
  if (Array.isArray(data.examDates)) { proExamDates = data.examDates; proSaveJSON(PRO_KEYS.examDates, proExamDates); }
  if (Array.isArray(data.examScores)) { proExamScores = data.examScores; proSaveJSON(PRO_KEYS.examScores, proExamScores); }
  if (data.subjectGoals && typeof data.subjectGoals === 'object') { proSubjectGoals = data.subjectGoals; proSaveJSON(PRO_KEYS.subjectGoals, proSubjectGoals); }
  if (Array.isArray(data.timetable)) { proTimetable = data.timetable; proSaveJSON(PRO_KEYS.timetable, proTimetable); }
  if (data.reminder && typeof data.reminder === 'object') { proReminder = { enabled: false, time: '20:00', lastFired: null, ...data.reminder }; proSaveJSON(PRO_KEYS.reminder, proReminder); }
};

const proOrigPopulateSubjectSelects = populateSubjectSelects;
populateSubjectSelects = function () {
  proOrigPopulateSubjectSelects();
  ['#manualSubject', '#examScoreSubject', '#ttSubject'].forEach((sel) => {
    const el = document.querySelector(sel);
    if (!el) return;
    const prev = el.value;
    el.innerHTML = '';
    subjects.forEach((s) => {
      const o = document.createElement('option');
      o.value = s; o.textContent = s;
      el.appendChild(o);
    });
    if (subjects.includes(prev)) el.value = prev;
  });
};

const proOrigShowTab = showTab;
showTab = function (name) {
  proOrigShowTab(name);
  if (name === 'exam') proRenderExam();
  if (name === 'todo') proPopulatePomodoroTasks();
};

/* ============================================================
   17. 受験タブ全体の描画
   ============================================================ */
function proRenderExam() {
  proRenderExamDates();
  proRenderExamScoresSection();
  proRenderForecast();
  proRenderLeech();
  proRenderUnitAnalysis();
  proRenderSubjectGoals();
  proRenderTimetable();
}

/* ============================================================
   18. 初期化
   ============================================================ */
function proUpdateBackupLabel() {
  const lbl = document.getElementById('lastBackupLabel');
  if (!lbl) return;
  const iso = localStorage.getItem(PRO_KEYS.lastBackup);
  if (!iso) { lbl.textContent = 'まだバックアップしていません。「エクスポート」で保存しておきましょう。'; return; }
  const d = new Date(iso);
  const days = Math.floor((Date.now() - d.getTime()) / 86400000);
  lbl.textContent = `最終バックアップ: ${d.toLocaleDateString()}（${days}日前）`;
  if (days >= 7) proToast('💾 バックアップの時期です。設定 → データのバックアップ からエクスポートしましょう。', null, null, 9000);
}

function proInitFeatures() {
  // 科目セレクト（手動記録・模試・時間割）を構築
  try { populateSubjectSelects(); } catch (e) {}

  // --- S3 手動記録 ---
  const msBtn = document.getElementById('manualStudyBtn');
  if (msBtn) msBtn.addEventListener('click', () => proOpenManualModal(null));
  const msClose = document.getElementById('manualStudyClose');
  if (msClose) msClose.addEventListener('click', proCloseManualModal);
  const msModal = document.getElementById('manualStudyModal');
  if (msModal) msModal.addEventListener('click', (e) => { if (e.target === msModal) proCloseManualModal(); });
  const msSave = document.getElementById('manualStudySave');
  if (msSave) msSave.addEventListener('click', proSaveManualModal);
  proRenderSessionList();

  // --- S1 Anki取込 ---
  const ankiBtn = document.getElementById('cardsAnkiBtn');
  const ankiInput = document.getElementById('cardsAnki');
  if (ankiBtn && ankiInput) {
    ankiBtn.addEventListener('click', () => ankiInput.click());
    ankiInput.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      e.target.value = '';
      if (!file) return;
      try {
        const text = await fcReadFileText(file);
        const preview = proParseAnkiToPreview(text);
        const n = fcParsePreviewRows(preview).length;
        if (n === 0) { alert('カードを検出できませんでした。Ankiのテキスト書き出し（.txt/.csv）を使用してください。'); return; }
        fcOpenImportModal(preview, `Anki「${file.name}」から ${n} 枚を検出しました。内容を確認して取り込んでください。`);
      } catch (err) {
        alert('読み込めませんでした: ' + (err && err.message ? err.message : err));
      }
    });
  }

  // --- カード追加の拡張（種類・単元・画像） ---
  const imgInput = document.getElementById('cardImageInput');
  if (imgInput) {
    imgInput.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      e.target.value = '';
      if (!file) return;
      try {
        proPendingImageId = await proPutImage(file);
        const nm = document.getElementById('cardImageName');
        if (nm) nm.textContent = '画像: ' + file.name;
      } catch (err) { alert('画像を保存できませんでした（ストレージ不足の可能性）。'); }
    });
  }
  const cardAddBtn = document.getElementById('cardAdd');
  if (cardAddBtn) {
    cardAddBtn.addEventListener('click', () => {
      const deck = fcGetDeck(fcOpenDeckId);
      if (!deck || deck.cards.length === 0) { proPendingImageId = null; return; }
      const card = deck.cards[deck.cards.length - 1];
      // 直前に追加されたカードのみ対象（空入力で追加されなかった場合を除外）
      if (!card.createdAt || Date.now() - card.createdAt > 3000) return;
      const typeSel = document.getElementById('cardType');
      const unitIn = document.getElementById('cardUnit');
      card.type = typeSel ? typeSel.value : 'normal';
      card.unit = unitIn ? unitIn.value.trim() : '';
      if (proPendingImageId) { card.img = proPendingImageId; proPendingImageId = null; }
      const nm = document.getElementById('cardImageName'); if (nm) nm.textContent = '';
      if (unitIn) unitIn.value = '';
      saveFlashcards();
      renderCardList();
      renderDeckSummary();
    });
  }

  // --- 出題形式 / Cram ---
  const cramBtn = document.getElementById('deckCramBtn');
  if (cramBtn) cramBtn.addEventListener('click', () => { if (fcOpenDeckId) startStudy(fcOpenDeckId, '__cram__'); });
  const typingBtn = document.getElementById('typingCheck');
  if (typingBtn) typingBtn.addEventListener('click', proCheckTyping);
  const typingInp = document.getElementById('typingInput');
  if (typingInp) typingInp.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); proCheckTyping(); } });

  // --- A2 カウントダウン ---
  const edAdd = document.getElementById('examDateAdd');
  if (edAdd) edAdd.addEventListener('click', proAddExamDate);
  const edInp = document.getElementById('examDateLabel');
  if (edInp) edInp.addEventListener('keydown', (e) => { if (e.key === 'Enter') proAddExamDate(); });
  proRenderCountdownBanner();

  // --- A1 模試得点 ---
  const esAdd = document.getElementById('examScoreAdd');
  if (esAdd) esAdd.addEventListener('click', proAddExamScore);
  const esSel = document.getElementById('examChartSubject');
  if (esSel) esSel.addEventListener('change', proDrawExamChart);

  // --- B6 時間割 ---
  const ttAdd = document.getElementById('ttAdd');
  if (ttAdd) ttAdd.addEventListener('click', proAddTimetable);

  // --- B8 リマインダー ---
  proApplyReminderUI();
  const rToggle = document.getElementById('reminderToggle');
  if (rToggle) {
    rToggle.addEventListener('change', (e) => {
      if (e.target.checked && !settings.notifEnabled) {
        alert('先に「🔔 ブラウザ通知」を有効にしてください。');
        e.target.checked = false;
        return;
      }
      proReminder.enabled = e.target.checked;
      proSaveJSON(PRO_KEYS.reminder, proReminder);
    });
  }
  const rTime = document.getElementById('reminderTime');
  if (rTime) rTime.addEventListener('change', () => {
    proReminder.time = rTime.value || '20:00';
    proSaveJSON(PRO_KEYS.reminder, proReminder);
  });

  // --- S4 バックアップの記録 ---
  const expBtn = document.getElementById('backupExport');
  if (expBtn) expBtn.addEventListener('click', () => {
    try { localStorage.setItem(PRO_KEYS.lastBackup, new Date().toISOString()); } catch (e) {}
    proUpdateBackupLabel();
  });
  proUpdateBackupLabel();

  // --- タブクリックで受験タブを描画（app.js のタブ処理の後に実行） ---
  document.querySelectorAll('.tab-btn[data-tab="exam"]').forEach((b) => {
    b.addEventListener('click', () => proRenderExam());
  });

  // --- ポモドーロ連動タスク ---
  proPopulatePomodoroTasks();

  // --- 定期処理 ---
  setInterval(() => {
    proRenderCountdownBanner();
    proCheckReminder(false);
    const panel = document.getElementById('tab-exam');
    if (panel && panel.classList.contains('active')) {
      proRenderForecast();
      proRenderLeech();
      proRenderUnitAnalysis();
    }
  }, 60000);

  // 起動時に一度チェック（当日すでに時刻を過ぎていれば通知）
  setTimeout(() => proCheckReminder(true), 5000);
}

/* app.js の初期化（DOMContentLoaded）より後に実行する */
window.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => {
    try { proInitFeatures(); } catch (e) { console.error('features init error', e); }
  }, 0);
});
